# -*- coding: utf-8 -*-
"""
Created on Sat Feb 17 16:08:40 2024

@author: TANMAY
"""

import pandas as pd
from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

scaler = StandardScaler()


prkd=pd.read_csv('C:/Users/TANMAY/Desktop/TANMAY/python/parkinsons.data',sep=',')
prkd.isna().sum()

X=prkd.drop(['status','name'],axis=1)
y=prkd['status']
X = scaler.fit_transform(X)

P=PCA()
Xt=P.fit_transform(X)
gnb= GaussianNB()



df=pd.DataFrame(columns=['No of Features','Corresponding Accuracy'])
for i in range(Xt.shape[1]):
    X_train, X_test, y_train, y_test = train_test_split(Xt[:,:i+1], y, test_size=0.2,stratify=y)
    model = gnb.fit(X_train,y_train)
    y_pred = model.predict(X_test)
    df.loc[len(df.index)]=[i+1,accuracy_score(y_test, y_pred)]
    
    
df.to_excel('C:/Users/TANMAY/Desktop/TANMAY/python/pca_tanmay_excel.xlsx',index=False,engine='xlsxwriter')

# Xt[:,:2]
