# -*- coding: utf-8 -*-
"""
Created on Thu Mar 21 14:26:06 2024

@author: kripl
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

data = pd.read_csv('output.csv')
le =LabelEncoder()
data['Target'] = le.fit_transform(data['Target'])
A = data[data['Target']==0]
B = data[data['Target']==1]
C = data[data['Target']==2]

AB = [A,B]
AC =[A,C]
BC = [B,C]

data_AB = pd.concat(AB)
data_AC = pd.concat(AC)
data_BC = pd.concat(BC)

y = data['Target']
X = data.drop(['Marital status', 'Application mode', 'Application order', 'Course',
       'Daytime/evening attendance\t', 'Previous qualification',
       'Previous qualification (grade)', 'Nacionality',
       "Mother's qualification", "Father's qualification",
       "Mother's occupation", "Father's occupation",'Admission grade','Displaced',
       'Educational special needs','Debtor','Tuition fees up to date','Target'] , axis=1)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
       
yAB = data_AB['Target']

X_AB = X_new = data_AB.drop(['Marital status', 'Application mode', 'Application order', 'Course',
       'Daytime/evening attendance\t', 'Previous qualification',
       'Previous qualification (grade)', 'Nacionality',
       "Mother's qualification", "Father's qualification",
       "Mother's occupation", "Father's occupation",'Admission grade','Displaced',
       'Educational special needs','Debtor','Tuition fees up to date','Target'] , axis=1)

yAC = data_AC['Target']

X_AC = X_new = data_AC.drop(['Marital status', 'Application mode', 'Application order', 'Course',
       'Daytime/evening attendance\t', 'Previous qualification',
       'Previous qualification (grade)', 'Nacionality',
       "Mother's qualification", "Father's qualification",
       "Mother's occupation", "Father's occupation",'Admission grade',
       'Displaced', 'Educational special needs','Debtor','Tuition fees up to date','Target'] , axis=1)

yBC = data_BC['Target']

X_BC = X_new = data_BC.drop(['Marital status', 'Application mode', 'Application order', 'Course',
       'Daytime/evening attendance\t', 'Previous qualification',
       'Previous qualification (grade)', 'Nacionality',
       "Mother's qualification", "Father's qualification",
       "Mother's occupation", "Father's occupation",'Admission grade',
       'Displaced', 'Educational special needs','Debtor','Tuition fees up to date','Target'] , axis=1)

X_AB = np.array(X_AB)
yAB = np.array(yAB)

X_train, X_test, y_train, y_test = train_test_split(X_AB, yAB, test_size=0.2, random_state=42)
Logistic_Reg = LogisticRegression()
Logistic_Reg.fit(X_train,y_train)
predictions = Logistic_Reg.predict(X_test)



score = Logistic_Reg.score(X_test,y_test)
print(score)


X_AC = np.array(X_AC)
yAC = np.array(yAC)

XAC_train, XAC_test, yAC_train, yAC_test = train_test_split(X_AC, yAC, test_size=0.2, random_state=42)
Logistic_Reg = LogisticRegression()
Logistic_Reg.fit(XAC_train,yAC_train)
predictions0 = Logistic_Reg.predict(XAC_test)



score_AC = Logistic_Reg.score(XAC_test,yAC_test)
print(score_AC)

X_BC = np.array(X_BC)
yBC = np.array(yBC)

XBC_train, XBC_test, yBC_train, yBC_test = train_test_split(X_BC, yBC, test_size=0.2, random_state=42)
Logistic_Reg = LogisticRegression()
Logistic_Reg.fit(XBC_train,yBC_train)
predictions1 = Logistic_Reg.predict(XAC_test)

score_BC = Logistic_Reg.score(XBC_test,yBC_test)
print(score_AC)


score_BC = Logistic_Reg.score(XBC_test,yBC_test)
print(score_BC)