#include <iostream>
using namespace std;

template <class T>
class Node {
public:
    T data;
    int priority;
    Node* next;
    Node(T d, int p) : data(d), priority(p), next(nullptr) {}
};

template <class T>
class PriorityQueue {
private:
    Node<T>* front;

public:
    PriorityQueue() : front(nullptr) {}

    void enqueue(T value, int priority) {
        Node<T>* newNode = new Node<T>(value, priority);
        if (!front || priority > front->priority) {
            newNode->next = front;
            front = newNode;
        } else {
            Node<T>* temp = front;
            while (temp->next && temp->next->priority >= priority) {
                temp = temp->next;
            }
            newNode->next = temp->next;
            temp->next = newNode;
        }
    }

    void dequeue() {
        if (!front) {
            cout << "Queue is empty!" << endl;
            return;
        }
        Node<T>* temp = front;
        front = front->next;
        delete temp;
    }

    T peek() {
        if (!front) {
            cout << "Queue is empty!" << endl;
            return T();
        }
        return front->data;
    }

    bool isEmpty() {
        return front == nullptr;
    }

    void printQueue() {
        Node<T>* temp = front;
        while (temp) {
            cout << "(" << temp->data << ", " << temp->priority << ") ";
            temp = temp->next;
        }
        cout << endl;
    }
};

int main() {
    PriorityQueue<int> pq;
    pq.enqueue(10, 2);
    pq.enqueue(20, 1);
    pq.enqueue(30, 3);
    pq.printQueue();
    pq.dequeue();
    pq.printQueue();
    cout << "Front element: " << pq.peek() << endl;
    return 0;
}
