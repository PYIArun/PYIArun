writeList([H|T]):-
    write(H),nl,
    writeList(T).
star(N):- N=<0.
star(H):-H>0,write("*"),H1 is H-1,star(H1).
bars([]).
bars([H|T]):-star(H),nl,bars(T).
f(X,normal):-X<3.
f(X,alert1):-3=<X,X<6.
f(X,alert2):-X>6.

add( X, L, L) :- member( X, L), !,write("h").
add( X, L, [X|L] ).
