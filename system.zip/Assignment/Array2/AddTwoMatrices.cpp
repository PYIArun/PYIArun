#include <iostream>

using namespace std;

// Function to add two matrices
// To: Add two matrices and store the result in a third matrix
// Input:
//   - int mat1[][]: First matrix
//   - int mat2[][]: Second matrix
//   - int result[][]: Matrix to store the result
//   - int rows: Number of rows in the matrices
//   - int cols: Number of columns in the matrices
// Output:
//   - None
// Approach:
//   - Iterate through each element of the matrices.
//   - Add corresponding elements and store the result in the result matrix.
void add_matrices(int mat1[][100], int mat2[][100], int result[][100], int rows, int cols) {
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            result[i][j] = mat1[i][j] + mat2[i][j];
        }
    }
}

int main() {
    int rows, cols;

    cout << "Enter the number of rows and columns: ";
    cin >> rows >> cols;

    int mat1[100][100], mat2[100][100], result[100][100];

    cout << "Enter elements of the first matrix:" << endl;
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            cin >> mat1[i][j];
        }
    }

    cout << "Enter elements of the second matrix:" << endl;
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            cin >> mat2[i][j];
        }
    }

    add_matrices(mat1, mat2, result, rows, cols);

    cout << "Resultant matrix after addition:" << endl;
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            cout << result[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}
