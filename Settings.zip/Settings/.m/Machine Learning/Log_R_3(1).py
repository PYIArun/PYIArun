# -*- coding: utf-8 -*-
"""
Created on Tue Mar 19 10:44:11 2024

@author: kripl
"""
import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.decomposition import TruncatedSVD
from sklearn.metrics import accuracy_score
from sklearn.naive_bayes import GaussianNB

data = pd.read_csv('output.csv')
data.columns
data.head()
le = LabelEncoder()
data['Target'] = le.fit_transform(data['Target'])
y = data['Target']
X = data.drop(['Target'] , axis=1)

data.columns
features = []
accuracies = []

corre = data.corr()
c = data.corr()['Target'].abs()
c = c.sort_values(ascending =False)
c
import seaborn as sns
sns.heatmap(corre)
#corr_features = data.corr()['company_size'].abs()

required_features = c.index[1:]

List =[]


for i in range(1, len(required_features)+1):
    sel = required_features[:i]
    sample = data[sel]
    
    X_train,X_test, y_train, y_test = train_test_split(X, y, test_size=0.2,   random_state =2)
    LR = LogisticRegression()
    model= LR.fit(X_train, y_train)
    y_pred=model.predict(X_test)
    accuracy = accuracy_score(y_test,y_pred)
    print("Accuracy of per class:", accuracy)
    List.append(accuracy*100)
    
#svd = TruncatedSVD()

# for i in range(X.shape[1]):
#     svd = TruncatedSVD(i+1)
#     svd.fit(X)
#     value = svd.transform(X)
#     x_train, x_test, y_train, y_test = train_test_split(value, y, test_size=0.2, random_state=0)
#     gnb = LogisticRegression()

#     model = gnb.fit(x_train, y_train)
#     y_pred = model.predict(x_test)
#     accuracy = accuracy_score(y_test, y_pred)*100
#     features.append(i)
#     accuracies.append(accuracy)
    

  
# result_df = pd.DataFrame({
#     "No. of features: " : features,
#     "Accuracy": accuracies
#     })

# print(result_df)


X_new = data.drop(['Marital status', 'Application mode', 'Application order', 'Course',
       'Daytime/evening attendance\t', 'Previous qualification',
       'Previous qualification (grade)', 'Nacionality',
       "Mother's qualification", "Father's qualification",
       "Mother's occupation", "Father's occupation",'Admission grade',
       'Displaced', 'Educational special needs','Debtor','Tuition fees up to date'] , axis=1)

model = LogisticRegression(multi_class='ovr')
model.fit(X_new, y)
yhat = model.predict(X_new)

from sklearn.svm import SVC
from sklearn.multiclass import OneVsOneClassifier
model = SVC()
ovo = OneVsOneClassifier(model)
ovo.fit(X_new, y)
yhat = ovo.predict(X_new)

X_train, X_test, y_train, y_test = train_test_split(X_new, y, test_size=0.2, random_state=42)

model = LogisticRegression(multi_class='ovr')
model.fit(X_train,y_train)
yhat = model.predict(X_test)

score = model.score(X_test,y_test)
print(score)

# model = LogisticRegression(multi_class='ovo')
# model.fit(X_train,y_train)
# yhat = model.predict(X_test)

model1 = SVC()
ovo = OneVsOneClassifier(model1)
ovo.fit(X_train, y_train)
yhat = ovo.predict(X_test)


