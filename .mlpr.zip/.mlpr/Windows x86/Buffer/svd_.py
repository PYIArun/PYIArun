# -*- coding: utf-8 -*-
"""
Created on Thu Feb 22 07:22:16 2024

@author: 
"""


import numpy as np
from numpy.linalg import svd

# define your matrix as a 2D numpy array
'''arr = np.array()
n = int(input("Enter the number of elements: "))
for i in range(n):
    element = int(input(f"Enter element {i+1}: "))
    arr.append(element)
print("Array:", arr)'''
n = int(input("Enter the number of elements: "))
# Take input as a string
input_string = input("Enter  the elements row wise separated by space: ")
# Convert the string to a NumPy array
arr = np.fromstring(input_string, dtype=int, sep=' ')
print("NumPy Array:", arr)
n1=int(n**0.5)
arr=arr.reshape(n1,n1)
U, S, VT = svd(arr)

print("Left Singular Vectors:")
print(U)
print("Singular Values:") 
print(np.diag(S))
print("Right Singular Vectors:") 
print(VT)

# check that this is an exact decomposition
# @ is used for matrix multiplication in Py3, use np.matmul with Py2
print(U @ np.diag(S) @ VT)

