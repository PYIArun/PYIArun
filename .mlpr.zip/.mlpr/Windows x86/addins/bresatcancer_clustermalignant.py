# -*- coding: utf-8 -*-
"""
Created on Thu Jul 23 21:14:29 2020

@author: BALJEET KAUR
"""

from sklearn import datasets
import matplotlib.pyplot as plt

bc= datasets.load_breast_cancer()
x=bc.data
y=bc.target

from sklearn.cluster import KMeans
kmeans=KMeans(n_clusters=2)
kmeans.fit(x)
#kmeans.cluster_centers_
ypred=kmeans.labels_

plt.scatter(x[:,0],x[:,2])
plt.scatter(x[:,0],x[:,2],c=ypred)




sx=x[y==1];

from sklearn.cluster import KMeans
kmeans=KMeans(n_clusters=2)
kmeans.fit(sx)
kmeans.cluster_centers_
ypred=kmeans.labels_



plt.scatter(sx[:,0],sx[:,2])
plt.scatter(sx[:,0],sx[:,2],c=ypred)
