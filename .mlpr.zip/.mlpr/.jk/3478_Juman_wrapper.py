import numpy as np
import pandas as pd
from sklearn.datasets import load_iris
from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

iris = load_iris()
X = iris.data
y = iris.target

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=5)

gnb = GaussianNB()

selected_features = []

detailed_results_df = pd.DataFrame(columns=['Iteration', 'Features', 'Accuracy'])

for i in range(X_train.shape[1]):

    best_accuracy = -1
    best_feature_index = -1
    
    accuracies = []
    
    for j in range(X_train.shape[1]):
        # If the feature is already selected, skip it
        if j in selected_features:
            continue
        
        current_features = selected_features + [j]
        X_train_selected = X_train[:, current_features]
        X_test_selected = X_test[:, current_features]
        
        gnb.fit(X_train_selected, y_train)
        
        y_pred = gnb.predict(X_test_selected)
        
        accuracy = accuracy_score(y_test, y_pred)
        
        accuracies.append({'Iteration': i + 1, 'Features': current_features, 'Accuracy': accuracy})
        

    best_feature = max(accuracies, key=lambda x: x['Accuracy'])
    best_accuracy = best_feature['Accuracy']
    
    selected_features = best_feature['Features']
    
    accuracies_df = pd.DataFrame(accuracies)
    
    detailed_results_df = pd.concat([detailed_results_df, accuracies_df], ignore_index=True)
    
    print(f"Iteration {i + 1}: Features = {best_feature['Features']}, Accuracy = {best_accuracy:.4f}")

detailed_results_df.to_excel("3478_Juman_wrapper.xlsx", index=False)

# Print DataFrame
print(detailed_results_df)
