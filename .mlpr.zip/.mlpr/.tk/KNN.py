import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, confusion_matrix, precision_score, recall_score, f1_score
class KNN:
    def __init__(self, k=3, p=2, weights = 'uniform'):
        self.k = k
        self.p = p
        self.weights = weights

    def fit(self, X_train, y_train):
        self.X_train = X_train
        self.y_train = y_train

    def predict(self, X_test):
        predictions = [self._predict(x) for x in X_test]
        return np.array(predictions)

    def _predict(self, x):
        if self.p==1:
            distances = [np.sum(np.abs(x - x_train)) for x_train in self.X_train]
        elif self.p==2:
            distances = [np.linalg.norm(x - x_train) for x_train in self.X_train]
        k_neighbors_indices = np.argsort(distances)[:self.k]
        if self.weights == 'uniform':
            k_neighbor_labels = [self.y_train[i] for i in k_neighbors_indices]
            most_common = np.bincount(k_neighbor_labels).argmax()
        elif self.weights == 'distance':
            inverse_distances = np.array([1 / d if d!=0 else float('inf') for d in distances])[k_neighbors_indices]
            sum_of_inverse_distances = np.sum(inverse_distances)
            inverse_fraction = inverse_distances / sum_of_inverse_distances
            labels = self.y_train[k_neighbors_indices]
            sum=[0]*4
            for i in range(len(inverse_fraction)):
                sum[labels[i]] += inverse_fraction[i]
            most_common = sum.index(max(sum))
        return most_common

def find_k(X_train, y_train, X_test, y_test,  k_values, test_size=0.2):
    best_k = None
    best_p = None
    best_weights = None
    best_accuracy = 0.0
    p_values = [1,2]
    weight = ['uniform', 'distance']
    for k in k_values:
        for p in p_values:
            for weights in weight:
                knn = KNN(k=k, p=p, weights = weights)
                knn.fit(X_train, y_train)
                y_predicted = []
                y_pred = knn.predict(X_test)
                accuracy = accuracy_score(y_test, y_pred)*100
                print(f'Accuracy for k={k} with p{p} and weight {weights}: {accuracy}')
                if accuracy > best_accuracy:
                    best_accuracy = accuracy
                    best_k = k
                    best_p = p
                    best_weights = weights
    return (best_k, best_p, best_weights)

if __name__ == "__main__":
    data = pd.read_csv("D:/Semester 6/jobs_in_data.csv")
    print(data.head)
    data.columns
    data.describe()
    le = LabelEncoder()
    data['job_title'] = le.fit_transform(data['job_title'])
    data['job_category'] = le.fit_transform(data['job_category'])
    data['employee_residence'] = le.fit_transform(data['employee_residence'])
    data['experience_level'] = le.fit_transform(data['experience_level'])
    data['employment_type'] = le.fit_transform(data['employment_type'])
    data['work_setting'] = le.fit_transform(data['work_setting'])
    data['company_location'] = le.fit_transform(data['company_location'])
    data['company_size'] = le.fit_transform(data['company_size'])
    data['salary_currency'] = le.fit_transform(data['salary_currency'])
        
        
    y = data['company_size']
    Features = data.drop(['company_size'], axis=1)


    scaler = StandardScaler()
    X = scaler.fit_transform(Features)
    k_values = range(1,11)  # Choose a range of k values to test
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 35, shuffle= True, stratify = y)
    best_k, best_p, best_weights = find_k(X_train, y_train, X_test, y_test,  k_values)
    
    print(f"\nBest k value: {best_k}")
    print(f"\nBest p value: {best_p}")
    print(f"\nBest weights values: {best_weights}")

    # Create the final model with the best k
    final_model = KNN(k= best_k, p= best_p, weights= best_weights)
    final_model.fit(X_train, y_train)
    y_pred = final_model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    print("Accuracy of the Model: ", accuracy*100)
    from sklearn.metrics import confusion_matrix, precision_score, recall_score, f1_score
    conf_matrix = confusion_matrix(y_test, y_pred)
    print(conf_matrix)
    precision = precision_score(y_test, y_pred, average ='macro')
    print(precision)
    recall = recall_score(y_test, y_pred, average = 'macro')
    print(recall)
    f1score = f1_score(y_test, y_pred, average = 'macro')
    print(f1score)