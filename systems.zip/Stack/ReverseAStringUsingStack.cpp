#include <iostream>
#include <stack>
#include <string>

using namespace std;

string reverseString(const string &s) {
    stack<char> charStack;

    // Push all characters of the string onto the stack
    for (char ch : s) {
        charStack.push(ch);
    }

    // Pop characters from the stack to form the reversed string
    string reversed;
    while (!charStack.empty()) {
        reversed += charStack.top();
        charStack.pop();
    }

    return reversed;
}

int main() {
    string input = "hello";
    string reversed = reverseString(input);
    cout << "Input string: " << input << endl;

    cout << "Reversed string: " << reversed << endl;

    return 0;
}