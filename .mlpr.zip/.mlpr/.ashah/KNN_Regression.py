# Regression Problem
import numpy as np
import pandas as pd
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.neighbors import KNeighborsRegressor
from sklearn.metrics import mean_squared_error
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

df = pd.read_csv('C:/Users/HP/Desktop/Machine Learning/insurance.csv')
print(df)
df.info()
print('Shape: ', df.shape)
print('Null Values Count: ')
print(df.isnull().sum())
print(df.duplicated().sum())
df.drop_duplicates(keep='first', inplace = True)
print(df.duplicated().sum())
print(df.shape)

df[['sex', 'smoker', 'region']] = df[['sex', 'smoker', 'region']].astype('category')
print(df.dtypes)

from sklearn.preprocessing import LabelEncoder
label = LabelEncoder()
label.fit(df.sex.drop_duplicates())
df.sex = label.transform(df.sex)
label.fit(df.smoker.drop_duplicates())
df.smoker = label.transform(df.smoker)
label.fit(df.region.drop_duplicates())
df.region = label.transform(df.region)
print(df.dtypes)
print(df)

X = df.drop('charges', axis=1)
y = df['charges']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0,  shuffle= True, stratify = y)

pipe = Pipeline(steps=[('scaler', StandardScaler()), ('knn', KNeighborsRegressor())])

# Define the parameter grid including the number of neighbors, weights, and p
param_grid = {
    'knn__n_neighbors': list(range(1, 11)),
    'knn__weights': ['uniform', 'distance'],
    'knn__p': [1, 2]
}

grid = GridSearchCV(pipe, param_grid, cv=10, scoring='neg_mean_squared_error')

# fitting the model for grid search
grid_search = grid.fit(X_train, y_train)
print('Best Hyperparameters: ', grid_search.best_params_)

best_model = grid_search.best_estimator_
y_pred= best_model.predict(X_test) 

mse = mean_squared_error(y_test, y_pred)
print("Mean Squared Error: ", mse)
rmse = np.sqrt(mse)
print("Root Mean Squared Error: ", rmse)