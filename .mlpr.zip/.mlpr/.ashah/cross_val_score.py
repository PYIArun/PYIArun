import numpy as np
import pandas as pd
from sklearn.model_selection import cross_val_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import precision_score, make_scorer, recall_score, f1_score

df = pd.read_csv('C:/Users/HP/Desktop/Machine Learning/Mobile.csv')
X = df.drop('price_range',axis=1)
y = df['price_range']
df.drop('price_range',axis=1, inplace= True)
knn = KNeighborsClassifier(n_neighbors=10, p= 2, weights = 'distance')
print('Using Accuracy Score: ')
cv_folds = 10
cv_scr=cross_val_score(knn, X, y, cv=cv_folds)
print('Cross Val Score: ', cv_scr)
print('Mean: ', np.mean(cv_scr))
print('Standard Deviation: ', np.std(cv_scr))

print('Using Precision Score: ')
precision_scorer = make_scorer(precision_score, average = 'macro')
cv_folds = 10
cv_scr=cross_val_score(knn, X, y, cv=cv_folds, scoring = precision_scorer)
print('Cross Val Score: ', cv_scr)
print('Mean: ', np.mean(cv_scr))
print('Standard Deviation: ', np.std(cv_scr))

print('Using Recall Score: ')
recall_scorer = make_scorer(recall_score, average = 'macro')
cv_folds = 10
cv_scr=cross_val_score(knn, X, y, cv=cv_folds, scoring = recall_scorer)
print('Cross Val Score: ', cv_scr)
print('Mean: ', np.mean(cv_scr))
print('Standard Deviation: ', np.std(cv_scr))

print('Using F1 Score: ')
f1_scorer = make_scorer(f1_score, average = 'macro')
cv_folds = 10
cv_scr=cross_val_score(knn, X, y, cv=cv_folds, scoring = f1_scorer)
print('Cross Val Score: ', cv_scr)
print('Mean: ', np.mean(cv_scr))
print('Standard Deviation: ', np.std(cv_scr))