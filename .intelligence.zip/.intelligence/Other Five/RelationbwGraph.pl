% Define the edges of the graph
edge(a, b).
edge(b, c).
edge(c, d).
edge(d, e).
edge(e, f).
edge(f, g).
edge(g, h).
edge(h, i).
edge(i, j).
edge(j, k).
edge(k, l).
edge(l, m).
edge(m, n).
edge(n, o).
edge(o, p).

% Define the relation 'connected' using recursion
connected(X, Y) :- edge(X, Y).          % Directly connected
connected(X, Y) :- edge(X, Z), connected(Z, Y).  % Indirectly connected through Z

% Test cases
% Query: connected(a, b).
% Output: true
% Query: connected(a, c).
% Output: true
% Query: connected(a, d).
% Output: true
% Query: connected(a, e).
% Output: true
% Query: connected(a, f).
% Output: true
% Query: connected(a, g).
% Output: true
% Query: connected(a, h).
% Output: true
% Query: connected(a, i).
% Output: true
% Query: connected(a, j).
% Output: true
% Query: connected(a, k).
% Output: true
% Query: connected(a, l).
% Output: true
% Query: connected(a, m).
% Output: true
% Query: connected(a, n).
% Output: true
% Query: connected(a, o).
% Output: true
% Query: connected(a, p).
% Output: false
