# -*- coding: utf-8 -*-
"""
Created on Mon Apr  1 23:42:17 2024

@author: Arun
"""

#LOGISTIC REGRESSION


import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import pandas as pd
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn import metrics
import numpy as np
import pandas as pd

df = pd.read_csv("C:/Users/arunc/Desktop/Programs/HRanalytics.csv")
df['left'].value_counts() # Ratio is 70 (not left) and 30 (left)
print(df.head())

label_encoder = LabelEncoder()
df['Department'] = label_encoder.fit_transform(df['Department'])
df['salary'] = df['salary'].replace({'low': 1, 'medium': 2, 'high':3})

y = df['left']
X_prev = df.drop(['left'], axis=1)

scaler = StandardScaler()
X = scaler.fit_transform(X_prev)


X.shape
y.shape 
# Add bias term
X= np.c_[np.ones(len(X)), X]
X.shape
X= X.T
X.shape


#Compute Hypothesis

def compute_hypothesis(params, X):
    z = np.matmul(params.T, X)
    predictions = 1/(1+np.exp(-z))
    return predictions

#Predict classes
def predict_classes(predictions):
    predicted_classes = np.zeros(len(predictions))
    predicted_classes[np.where(predictions>=0.5)] = 1
    return predicted_classes

#Compute cost
def compute_cost(predictions, actual):
    m = len(actual)
    log_of_predictions = np.log(predictions)
    log_of_oneMinusPredictions = np.log(1-predictions)
    cost = -(1/m)*np.sum(((actual*log_of_predictions) + ((1-actual)*(log_of_oneMinusPredictions))))
    return cost

#Calculate accuracy
def calculate_accuracy(class_predictions, actual):
    accuracy = (sum(class_predictions==actual)/len(actual))*100
    return accuracy


#Gradient Descent implementation
def gradient_descent(X, Y, learning_rate, iterations):
    actual = Y
    costs = []
    accuracies = []
    params = np.zeros(X.shape[0])
    m = len(actual)
    
    for i in range(iterations):
        predictions = compute_hypothesis(params, X)
        class_predictions = predict_classes(predictions)
        
        accuracies.append(calculate_accuracy(class_predictions, actual))
        costs.append(compute_cost(predictions, actual))
        
        errors = predictions - actual
        gradients = (1/m)*np.matmul(X,errors)
        params = params - (learning_rate*gradients)
    
    return params, costs, accuracies


learning_rate = 0.0001
iterations = 10
params, costs, accuracies = gradient_descent(X, y, learning_rate, iterations)

# print(params)
# print(costs)
# print(accuracies)
# Plot cost and accuracy
plt.figure(figsize=(10, 5))

plt.subplot(1, 2, 1)
plt.plot(np.arange(iterations), costs, label='Cost')
plt.xlabel('Iterations')
plt.ylabel('Cost')
plt.title('Cost over iterations')
plt.legend()

plt.subplot(1, 2, 2)
plt.plot(np.arange(iterations), accuracies, label='Accuracy')
plt.xlabel('Iterations')
plt.ylabel('Accuracy')
plt.title('Accuracy over iterations')
plt.legend()

plt.tight_layout()
plt.show()

