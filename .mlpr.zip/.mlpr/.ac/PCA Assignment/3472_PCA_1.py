# -*- coding: utf-8 -*-
"""
Created on Sat Feb 16 17:04:48 2024

@author: Arun
"""

from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score
from sklearn.decomposition import PCA
import pandas as pd
from sklearn.preprocessing import StandardScaler


df = pd.read_csv("C:/Users/arunc/Desktop/Programs/HRanalytics.csv")

print(df.head())

scaler = StandardScaler()

#Encoding two categorical attributes
label_encoder = LabelEncoder()
df['Department'] = label_encoder.fit_transform(df['Department'])
df['salary'] = df['salary'].replace({'low': 1, 'medium': 2, 'high':3})

y = df['left']
X_prev = df.drop(['left'], axis=1)


scaler = StandardScaler()
X = scaler.fit_transform(X_prev)

gnb = GaussianNB()
Pca = PCA()
P = Pca.fit_transform(X)


features = []
accuracies = []

for i in range(1, P.shape[1]+1):
    X_train, X_test, y_train, y_test = train_test_split(P[:,:i+1], y, test_size=0.2, statify=y, random_state=0)
    model= gnb.fit(X_train, y_train)
    y_pred=model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred) * 100
    features.append(i)
    accuracies.append(accuracy)
    
result_df = pd.DataFrame({
    "No. of features: " : features,
    "Accuracy": accuracies
    })

print(result_df)
result_df.to_excel("C:/Users/arunc/Desktop/Programs/3472_PCA_results", index=False)

   
