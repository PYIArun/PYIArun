#include <iostream>
#include <algorithm>

using namespace std;

// Function to find and remove duplicate elements from an array
// To: Remove duplicate elements and keep only unique elements in the array
// Input:
//   - int arr[]: Array from which duplicates need to be removed
//   - int& size: Reference to an integer representing the size of the array
// Output:
//   - None
// Approach:
//   - First, sort the array to bring duplicates together.
//   - Use a single pass to copy unique elements to the beginning of the array.
void remove_duplicates(int arr[], int &size) {
    if (size == 0) return;

    sort(arr, arr + size);

    int unique_index = 0;

    for (int i = 0; i < size; ++i) {
        if (i == 0 || arr[i] != arr[i - 1]) {
            arr[unique_index++] = arr[i];
        }
    }

    size = unique_index;
}

int main() {
    int size;

    cout << "Enter the number of elements in the array: ";
    cin >> size;

    int* arr = new int[size];

    cout << "Enter the elements of the array: ";
    for (int i = 0; i < size; ++i) {
        cin >> arr[i];
    }

    remove_duplicates(arr, size);

    cout << "Array after removing duplicates: ";
    for (int i = 0; i < size; ++i) {
        cout << arr[i] << " ";
    }
    cout << endl;

    delete[] arr;

    return 0;
}
