sum(X,Y,Result):-
    Result is X+Y.
