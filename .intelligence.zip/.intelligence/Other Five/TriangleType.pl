% Predicate to determine the type of triangle
triangle_type(A, B, C, Type) :-
    % Check if it's a valid triangle
    valid_triangle(A, B, C),
    % Check if it's an equilateral triangle
    A =:= B, B =:= C,
    Type = equilateral.

triangle_type(A, B, C, Type) :-
    % Check if it's a valid triangle
    valid_triangle(A, B, C),
    % Check if it's an isosceles triangle Two sides are congruent to each other
    (A =:= B ; B =:= C ; A =:= C),
    Type = isosceles.

triangle_type(A, B, C, Type) :-
    % Check if it's a valid triangle
    valid_triangle(A, B, C),
    % Check if it's a scalene triangle   It has three sides of different lengths
    A =\= B, B =\= C, A =\= C,
    Type = scalene.

% Predicate to check if it's a valid triangle
valid_triangle(A, B, C) :-
    A + B > C,
    A + C > B,
    B + C > A.

% Example usage:
% triangle_type(3, 3, 3, Type).
% triangle_type(3, 4, 5, Type).
