# -*- coding: utf-8 -*-
"""
Created on Sun Feb 18 11:58:30 2024

@author: DEV RATAN
"""
import pandas as pd
import numpy as np
from sklearn.metrics import accuracy_score
from sklearn import datasets
from sklearn.preprocessing import MinMaxScaler
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB

from sklearn import metrics
from sklearn.model_selection import train_test_split
from sklearn.decomposition import PCA
from sklearn.datasets import load_diabetes
diabetes=load_diabetes()

X, y = diabetes.data, diabetes.target
scaler = MinMaxScaler((0,1))
X=scaler.fit_transform(X)


from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import f_classif


x_train, x_test, y_train, y_test = train_test_split(X, y, test_size = y, random_state = 0)
'''gnb = GaussianNB()

gnb.fit(x_train, y_train)

y_test_hat=gnb.predict(x_test) '''

model=LogisticRegression()
model.fit(x_train,y_train)
model.score(x_test, y_test)
test_accuracy=metrics.accuracy_score(y_test,model)*100

print("Accuracy for our testing dataset with tuning is : {:.2f}%".format(test_accuracy) )

pca = PCA()
Xt = pca.fit_transform(X)
gnb = GaussianNB()
pca.explained_variance_ratio_
X_train, X_test, y_train, y_test = train_test_split(Xt, y, test_size=0.2,random_state=0)
gnb = GaussianNB()
model= gnb.fit(X_train, y_train)
y_pred=model.predict(X_test)
test_accuracy = metrics.accuracy_score(y_test, y_pred) * 100

print("Accuracy : {:.2f}%".format(test_accuracy))
#info_sum = sum(pca.explained_variance_ratio_[0:i+1]) *  100
#print(f'Information amount till k{i} : {info_sum}')
#print(f'Accuracy with k{i} : {test_accuracy}')
#result.append({'Features Count': i+1, 'Information_Amount ': info_sum, 'Accuracy': '{:.2f}'.format(test_accuracy)})
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import mutual_info_classif
test = SelectKBest(score_func=mutual_info_classif, k=2)
X_small = test.fit_transform(X,y)
selected_mask=(test._get_support_mask())
print(diabetes.feature_names[selected_mask])

x_train, x_test, y_train, y_test = train_test_split(X_small, y, test_size = 0.2, random_state = 0)
gnb = GaussianNB()
gnb.fit(x_train, y_train)

y_test_hat=gnb.predict(x_test) 

test_accuracy=metrics.accuracy_score(y_test,y_test_hat)*100

print("Accuracy for our testing dataset with tuning is : {:.2f}%".format(test_accuracy) )
    