from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score
from sklearn.decomposition import PCA
import pandas as pd
from sklearn.preprocessing import StandardScaler
from xlsxwriter import workbook


df = pd.read_csv("C:/Users/Mayank/Desktop/Sem6/MachineLearning/Programs/WineQT.csv")

print(df.head())

y = df['quality']
X = df.drop(['quality'], axis=1)

# Standardize features
scaler = StandardScaler()
X = scaler.fit_transform(X)

# Initialize Gaussian Naive Bayes classifier
gnb = GaussianNB()

# Initialize lists to store results
number_of_features = []
accuracies = []

# Iterate through different number of principal components
for num_features in range(1, X.shape[1]+1):
    # Apply PCA transformation
    pca = PCA(num_features)
    X_transformed = pca.fit_transform(X)
    
  
    X_train, X_test, y_train, y_test = train_test_split(X_transformed, y, test_size=0.25, stratify=y, random_state=0)
    
    # Train Gaussian Naive Bayes model
    model = gnb.fit(X_train, y_train)
    
    # Predict on test set and calculate accuracy
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred) * 100
    
    # Append results to lists
    number_of_features.append(num_features)
    accuracies.append(accuracy)
    
# Create DataFrame to store results
result = pd.DataFrame({
    "Number of Features": number_of_features,
    "Accuracy": accuracies
})

print(result)


result.to_excel("C:/Users/Desktop/PCA_results.xlsx", index=False, engine='xlsxwriter')
