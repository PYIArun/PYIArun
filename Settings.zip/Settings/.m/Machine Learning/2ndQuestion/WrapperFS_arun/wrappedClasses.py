 # -*- coding: utf-8 -*-
"""
Created on Fri Feb  2 02:15:35 2024

@author: Arun Chandra
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.naive_bayes import GaussianNB

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix

from sklearn.datasets import load_iris

X, y = load_iris(return_X_y=True)

df=pd.DataFrame(X)
df.info()
rows, columns= df.shape
df.describe()
print(df.isnull().sum())


X_train, X_test, y_train, y_test= train_test_split(X, y, stratify=y, random_state=6)
gnb= GaussianNB()
model= gnb.fit(X_train, y_train)


y_pred=model.predict(X_test)
print("Number of mislabeled points out of a total %d points : %d"
      % (X_test.shape[0], (y_test != y_pred).sum()))


print(accuracy_score(y_test, y_pred))
print(confusion_matrix(y_test, y_pred))



num_splits = 10
accuracies = []


starting_features= df.columns.tolist()
print("HELLO", starting_features)
best_features= []
best_accuracy= 0.0

round_results = []

while(len(starting_features)>0):
    features_remained = list(set(starting_features)-set(best_features))
    
    
    for new_col in features_remained:
        gnb = GaussianNB()
        selected_features = best_features + [new_col]
        
        X_selected = df[selected_features]
        
        X_train, X_test, y_train, y_test = train_test_split(X_selected, y, stratify=y, random_state=6)
        gnb.fit(X_train, y_train)
        
        y_pred = gnb.predict(X_test)
        accuracy = accuracy_score(y_test, y_pred)
        
        if accuracy > best_accuracy:
            best_accuracy = accuracy
            best_features.append(new_col)
    
    # Update starting_features for the next iteration
    starting_features = list(set(starting_features) - set(best_features))
        

    round_results.append({
            'Round': len(best_features),
            'Selected Features': best_features.copy(),
            'Accuracy': best_accuracy
    })

    
    if best_accuracy == 1.0:
        break
        
print("Selected Features:", best_features)
print("Best Accuracy:", best_accuracy)


selected_features_table = pd.DataFrame(round_results)

print(selected_features_table)