# -*- coding: utf-8 -*-

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.svm import SVC
from sklearn.metrics import r2_score, accuracy_score
from sklearn.preprocessing import StandardScaler, LabelEncoder

scaler = StandardScaler()
prkd=pd.read_csv('parkinsons.data',sep=',')
prkd.isna().sum()

X=prkd.drop(['status','name'],axis=1)
y=prkd['status']
X = scaler.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

param_grid = {
    'kernel': ['linear', 'poly', 'rbf', 'sigmoid'],
    'C': [0.1, 1, 10, 100],
    'gamma': [0.1, 1, 10]
}

svm = SVC()

grid_search = GridSearchCV(estimator=svm, param_grid=param_grid, cv=5, scoring='accuracy')
grid_search.fit(X_train, y_train)

best_params = grid_search.best_params_
best_score = grid_search.best_score_
print("Best Parameters:", best_params)
print("Best Score:", best_score)

best_svm = SVC(**best_params)
best_svm.fit(X_train, y_train)


y_pred = best_svm.predict(X_test)


r2 = r2_score(y_test, y_pred)
accuracy = accuracy_score(y_test, y_pred)
print("R^2 Score:", r2)
print("Accuracy:", accuracy)





