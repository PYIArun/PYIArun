% Base case: Sum of an empty list is 0
sumlist([], 0).

% Recursive rule: Sum of a non-empty list is the sum of its head and the sum of its tail
sumlist([Head|Tail], Sum) :-
    sumlist(Tail, TailSum),
    Sum is Head + TailSum.
% Example usage:
% Querying sumlist([1, 2, 3, 4], Result).
