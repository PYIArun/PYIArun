% Q15. Maximum of list
maxList([], -1).
maxList([X], X).

maxList([X | T], M) :-
    maxList(T, M1),
    (
	X > M1 ->  M is X ;
	M is M1
    ).

maximumOfList :-
    read_num("Enter the list: ", L),
    maxList(L, M),
    write("The maximum of the list is: "),
    write(M).
