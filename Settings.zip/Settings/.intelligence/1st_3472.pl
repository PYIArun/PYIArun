link(a,b).
link(b,p).
link(b,c).

link(c,d).
link(d,q).
link(d,r).

alink(A,B):-
    link(A,B).

alink(A,B):-
    link(B,A).

path(A,A).
path(A,B) :-
    alink(A,X),
    path(X,B).
