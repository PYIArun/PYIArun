# -*- coding: utf-8 -*-

# 4. Take a regression problem with sufficient (8-20) attributes. 
# a. Fit regression models of varying complexity (polynomial degree) and observe 
# the training and test error 
# b. Plot the training and the test error (as shown in the class)
# c. Discuss the best model to be used for the data


"""
Created on Tue Mar 12 09:01:36 2024

@author: hp
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.metrics import mean_squared_error, r2_score

from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import f_regression

from sklearn.preprocessing import StandardScaler

data = pd.read_csv('C:/Users/arunc/Desktop/kjdklasfj/Realestate.csv')
df = pd.DataFrame(data)

X = df.drop(columns=["Y house price of unit area"])
y = df["Y house price of unit area"]

y = y.values.reshape(-1, 1)
y = df["Y house price of unit area"].values.reshape(-1, 1)

selector = SelectKBest(score_func = f_regression, k=4)
X_selected = selector.fit_transform(X, y)

scaler = StandardScaler()

X_scaled = scaler.fit_transform(X_selected)
y_scaled = scaler.fit_transform(y)

X_train, X_test, y_train, y_test = train_test_split(X_scaled, y_scaled, test_size=0.2, random_state=1)

degrees = range(1,6)

train_errors = []
test_errors = []
training_r2scores = []
testing_r2scores = []



for degree in degrees:
    
    polynomial_features = PolynomialFeatures(degree=degree)
    
    
    X_train_poly = polynomial_features.fit_transform(X_train)
    X_test_poly = polynomial_features.transform(X_test)
    

    model = LinearRegression()
    model.fit(X_train_poly, y_train)
    
    
    # Calculate training error
    train_pred = model.predict(X_train_poly)
    train_error = mean_squared_error(y_train, train_pred)
    train_r2 = r2_score(y_train, train_pred)
    train_errors.append(train_error)
    training_r2scores.append(train_r2)
    
    
    # Calculate testing error
    test_pred = model.predict(X_test_poly)
    test_error = mean_squared_error(y_test, test_pred)
    test_r2 = r2_score(y_test, test_pred)
    test_errors.append(test_error)
    testing_r2scores.append(test_r2)


    
# Plot the training and testing error
plt.plot(degrees, train_errors, label='Training Error', color='blue')
plt.plot(degrees, test_errors, label='Testing Error', color='red')
plt.xlabel('Polynomial Degree')
plt.ylabel('Mean Squared Error')
plt.title('Training and Testing Error vs Polynomial Degree')
plt.legend()
plt.show()                  

best_degree = degrees[np.argmax(testing_r2scores)]
print("Best Model have the best degree : ", best_degree)


# Create a new DataFrame for training and testing errors along with polynomial degrees
error_df = pd.DataFrame({
    'Polynomial Degree': degrees,
    'Training Error': train_errors,
    'Training R2 Score' : training_r2scores,
    'Testing Error': test_errors,
    'Testing R2 Score' : testing_r2scores
})

# Export DataFrame to Excel
error_df.to_excel('polynomial_errors.xlsx', index=False)

# Print DataFrame
print("\nTraining and Testing Errors for Different Polynomial Degrees:")
print(error_df)