import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from sklearn.naive_bayes import GaussianNB
from sklearn import metrics
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

apple_quality= pd.read_csv('apple_quality.csv')
num= LabelEncoder()

apple_quality.info()
rows, columns= apple_quality.shape
apple_quality.drop('A_id', axis=1, inplace=True)
print(apple_quality.isnull().sum())

apple_quality.dropna(inplace=True)
print(apple_quality.isnull().sum())

apple_quality['Quality'] = num.fit_transform(apple_quality['Quality'])

features = ['Size', 'Weight', 'Sweetness', 'Crunchiness', 'Juiciness', 'Ripeness', 'Acidity']
target = "Quality"

x=apple_quality[features]
y=apple_quality[target]

scaler = MinMaxScaler((0,1))
x=scaler.fit_transform(x)

x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 0.2, random_state = 0)
gnb = GaussianNB()

gnb.fit(x_train, y_train)

y_test_hat=gnb.predict(x_test) 

test_accuracy=metrics.accuracy_score(y_test,y_test_hat)*100

print("Accuracy for our testing dataset without tuning is : {:.2f}%".format(test_accuracy))

#Feature Scaling...

import seaborn as sns

df=pd.DataFrame(x)
#df=pd.DataFrame(x,columns=apple_quality.features)
df['class']=y
corr_data=df.corr()
sns.heatmap(corr_data)

sel_data=(abs(corr_data['class'])>0.01) & (abs(corr_data['class'])<1.0)  
x_small=x[:,sel_data[:7]];
#apple_quality[features][sel_data[:7]]



x_train, x_test, y_train, y_test = train_test_split(x_small, y, test_size = 0.2, random_state = 0)

gnb.fit(x_train, y_train)

y_test_hat=gnb.predict(x_test) 

test_accuracy=metrics.accuracy_score(y_test,y_test_hat)*100

print("Accuracy for our testing dataset with tuning is : {:.2f}%".format(test_accuracy) )


'''
from sklearn.metrics import accuracy_score
num_splits = 10
accuracies = []

for i in range(num_splits):
    features_train, features_test, target_train, target_test = train_test_split(apple_quality[features],apple_quality[target],test_size = 0.3, stratify=apple_quality[target])
    
    gnb = GaussianNB()
    model = gnb.fit(features_train, target_train)
    y_pred = model.predict(features_test)
    
    accuracy = accuracy_score(target_test, y_pred)
    accuracies.append(accuracy)
    
    print(f"Accuracy for split {i + 1}: {accuracy}")
    #print("Confusion Matrix:")
    #print(confusion_matrix(target_test, y_pred))
    print("-" * 40)

average_accuracy = np.mean(accuracies)
print(f"\nAverage Accuracy over {num_splits} splits: {average_accuracy}")

features_train, features_test, target_train, target_test = train_test_split(x_small,y,test_size = 0.3, stratify=y)
gnb = GaussianNB()
model = gnb.fit(features_train, target_train)
y_pred = model.predict(features_test)

y_pred=model.predict(features_test)
print("Number of wrong predictions out of a total %d points : %d"
      % (features_test.shape[0], (target_test != y_pred).sum()))


print( accuracy_score(target_test, y_pred))
#print(confusion_matrix(target_test, y_pred))

'''