% Q10. Reverse a list
reverse([], []).
reverse([X], [X]).

reverse([X | T], R) :-
    reverse(T, R1),
    append(R1, [X], R).

