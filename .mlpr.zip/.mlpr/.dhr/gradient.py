# -*- coding: utf-8 -*-
"""
Created on Thu Mar  7 12:18:15 2024

@author: hp
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import load_diabetes
from sklearn.metrics import mean_squared_error , r2_score

X, y = load_diabetes(return_X_y=True)
y = y.reshape(-1,1)
ones = np.ones((len(y),1))
X = np.hstack((ones, X))
m , n = X.shape[0], X.shape[1]

theta = np.zeros((n,1))

iterations = 20000
alpha = 0.1

def computeCost(X, y, theta):
    temp = np.dot(X, theta) - y
    return np.sum(np.power(temp, 2)) / (2*m)


def gradientDescent(X, y, theta, alpha, iterations):
    for _ in range(iterations):
        temp = np.dot(X, theta) - y
        temp = np.dot(X.T, temp)
        theta = theta - (alpha/m) * temp
        print(computeCost(X,y,theta))
    return theta

J = computeCost(X, y, theta)
theta = gradientDescent(X, y, theta, alpha, iterations)
y_pred = np.dot(X, theta)

mse = mean_squared_error(y,y_pred)
r2_score = r2_score(y,y_pred)
