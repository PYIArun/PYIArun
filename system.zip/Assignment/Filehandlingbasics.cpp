#include <iostream>
#include <fstream>

using namespace std;


int main(){

    char arr[100];
    cin.getline(arr, 100)
    return 0;
}