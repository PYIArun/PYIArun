
#include<iostream.h>
#include<conio.h>
#include<graphics.h>

void draw_circle(int Xc, int Yc, int radius) {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "C:\\Turboc3\\BGI");
    int x = 0;
    int y = radius;

    int p0 = 5/4 - radius;

    while (x <= y) {
	putpixel(Xc + x, Yc + y, 15);
	putpixel(Xc - x, Yc + y, 15);
	putpixel(Xc + x, Yc - y, 15);
	putpixel(Xc - x, Yc - y, 15);
	putpixel(Xc + y, Yc + x, 15);
	putpixel(Xc - y, Yc + x, 15);
	putpixel(Xc + y, Yc - x, 15);
	putpixel(Xc - y, Yc - x, 15);

	if (p0 < 0) {
	    x = x + 1;
	    p0 = p0 + 2 * x + 1;
	} else {
	    x = x + 1;
	    y = y - 1;
	    p0 = p0 + 2 * x - 2 * y + 1;
	}
    }

    getch();
    closegraph();
}

int main() {
    int Xc = getmaxx()/2, Yc = getmaxy()/2, radius = 50;
    draw_circle(0, 0, radius);

    return 0;
}`
