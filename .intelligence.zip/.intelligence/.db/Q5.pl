% Base case: GCD of any number and 0 is the number itself
gcd(X, 0, X) :- X > 0.
gcd(0, Y, Y) :- Y > 0.

% Recursive rule: GCD of X and Y is the same as GCD of Y and X mod Y
gcd(X, Y, G) :-
    X > 0,
    Y > 0,
    X >= Y,
    Z is X mod Y,
    gcd(Y, Z, G).

gcd(X, Y, G) :-
    X > 0,
    Y > 0,
    X < Y,
    gcd(Y, X, G).
% Example usage:
% gcd(48, 18, Result).
