from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB

from sklearn.preprocessing import LabelEncoder


import pandas as pd
import numpy as np


df = pd.read_csv('C:/Users/arunc/Desktop/Programs/Machine Learning/2ndQuestion/2nd Question/HRanalytics.csv')


label_encoder = LabelEncoder()


df['Department'] = label_encoder.fit_transform(df['Department'])
df['salary'] = label_encoder.fit_transform(df['salary'])

print(df.head())

print(df.corr())

columns = df.corr()['left'].abs().sort_values(ascending=False)

column_names = columns.index[1:]

y = df['left']
X = df.drop(['left'], axis=1)

accuracies = []
Selected_Features = []

for i in range(1, len(column_names)+1):

    selected_columns = column_names[:i]


    X_train, X_test, y_train, y_test = train_test_split(X[selected_columns], y, test_size=0.2, stratify=y, random_state=1)

    gnb = GaussianNB()
    model = gnb.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    print()
    print("Selected Features: ", selected_columns)
    print("Accuracy Score: ", accuracy_score(y_test, y_pred))
    accuracies.append(accuracy_score(y_test, y_pred))
    Selected_Features.append(selected_columns)

exporting_df = pd.DataFrame({
    "Features ": Selected_Features,
    "Accuracies": accuracies
})

exporting_df.to_excel('C:/Users/arunc/Desktop/Programs/Machine Learning/2ndQuestion/2nd Question/results.xlsx', engine='xlsxwriter')


