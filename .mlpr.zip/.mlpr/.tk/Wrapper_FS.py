# -*- coding: utf-8 -*-
"""
Created on Thu Feb  8 14:11:08 2024

@author: kripl
"""

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score
#from sklearn.preprocessing import LabelEncoder
import numpy as np
import pandas as pd


data = load_iris()
X, y = load_iris(return_X_y=True)


total_accuracies = []
Ft = data.feature_names
Features= pd.Series(data.feature_names)
Feature_index = Features.index[:]
Index= list(Feature_index)
selectedFeature = 0
Feature_name = []


while len(total_accuracies)<len(Feature_index ):
    accuracies = []
    for i in Index:
        selected = [selectedFeature] + [i]
        X_train, X_test, y_train, y_test = train_test_split(X[:,selected], y, test_size=0.4, stratify=y)
        gnb = GaussianNB()
        model= gnb.fit(X_train, y_train)
        y_pred=model.predict(X_test)
        accuracy=accuracy_score(y_test, y_pred)
        accuracies.append(accuracy)
        print(f"Accuracy for feature {i}: {accuracy}")

    max_value=np.argmax(accuracies)
    print(max_value)
    selectedFeature= Index[max_value]
    Feature_name.append(Ft[selectedFeature])
   
    Index.pop(max_value);
    print(Feature_index)
    
    total_accuracies.append(max(accuracies))
print(total_accuracies)

df = pd.DataFrame({
    "Round": Feature_index,
    "Selected Features": Feature_name,
    "Accuracy": total_accuracies
})
    
print(df)

df.to_csv("Tanisha_3422_wrapper.csv")
