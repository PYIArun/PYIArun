max(X,Y,Result):-
    X>=Y,
    Result is X.
max(X,Y,Result):-
    Y>X,
    Result is Y.
