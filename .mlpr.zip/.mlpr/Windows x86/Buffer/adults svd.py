# -*- coding: utf-8 -*-
"""
Created on Fri Feb 23 11:05:22 2024

@author: 
"""

from sklearn.decomposition import TruncatedSVD
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.naive_bayes import GaussianNB
import pandas as pd
import numpy as np
from scipy.linalg import svd
from sklearn.datasets import load_digits
from numpy.linalg import svd
digits = pd.read_csv("C:/Users/91931/Downloads/adult_mod.csv")
digits.keys()


x, y = digits, digits.income
scaler = StandardScaler()
x_scaled = scaler.fit_transform(x)
x_scaled
x_train, x_test, y_train, y_test = train_test_split(
    x_scaled, y, test_size=0.2, random_state=30)

gnb = GaussianNB()


svd_accuracy = []

for i in range(x.shape[1]):
    svd = TruncatedSVD(n_components=i+1)
    svd.fit(x)
    result = svd.transform(x)
    x_train, x_test, y_train, y_test = train_test_split(
        result, y, test_size=0.2, random_state=0)
    model = gnb.fit(x_train, y_train)
    y_pred = model.predict(x_test)
    accuracy = accuracy_score(y_test, y_pred)
    print(accuracy)
    svd_accuracy.append(accuracy)
    
    '''model.fit(x_train,y_train)
   Acc= model.score(x_test,y_test)'''
print(svd_accuracy)
print(accuracy)


df = pd.read_excel('3462_devratan.xlsx')

# Create a new column with some data
Acc=svd_accuracy[:29]
df['svd_accuracy'] = Acc
print(df['svd_accuracy'])
# Save the updated DataFrame back to the Excel file
df.to_excel('3462_devratan.xlsx', index=False)
#df = pd.DataFrame({'Features' :pd.Series(Feat),'Information':pd.Series(Info), 'Accuracy':pd.Series(Accuracy)})
print(svd_accuracy)

df
print("SUCCESSFULLY EXPORTED")
