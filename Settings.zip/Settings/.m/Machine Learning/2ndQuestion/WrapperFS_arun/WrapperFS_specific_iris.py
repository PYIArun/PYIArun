# -*- coding: utf-8 -*-
"""
Created on Fri Feb  9 10:49:38 2024

@author: Arun
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.naive_bayes import GaussianNB

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix

from sklearn.datasets import load_iris

X, y = load_iris(return_X_y=True)

df=pd.DataFrame(X)
df.info()
rows, columns= df.shape
df.describe()
print(df.isnull().sum())

print(df.head())
X_train, X_test, y_train, y_test= train_test_split(X, y, stratify=y, random_state=6)
gnb= GaussianNB()
model= gnb.fit(X_train, y_train)


y_pred=model.predict(X_test)
print("Number of mislabeled points out of a total %d points : %d"
      % (X_test.shape[0], (y_test != y_pred).sum()))


print(accuracy_score(y_test, y_pred))
print(confusion_matrix(y_test, y_pred))



num_splits = 10
accuracies = []


starting_features= df.columns.tolist()


print("HELLO", starting_features)
best_features= []
best_accuracy= 0.0

round_results = []

I_accuracy = []


for columns in starting_features:
    X_subset = df[:, columns]
    gnb=GaussianNB()
    X_train, X_test, y_train, y_test = train_test_split(X_subset, y, stratify=y, test_size=0.3)    
    gnb.fit(X_train,y_train)
    y_pred=gnb.predict(X_test)
    
    accuracy = accuracy_score(y_test,y_pred)
    
    I_accuracy.append()


max_feature_1 = I_accuracy.index(max(I_accuracy))

starting_features = set(starting_features) - set(max_feature_1)




II_accuracy = []

for columns in starting_features:
    X_subset = df[:, [columns, max_feature_1]]
    gnb = GaussianNB()
    X_train, X_test, y_train, y_test = train_test_split(X_subset, y, stratify=y, test_size= 0.3)
    gnb.fit(X_train, y_train)
    y_pred = gnb.predict(X_test)

    accuracy = accuracy_score(y_test, y_pred)
    
    II_accuracy.append(accuracy)    
    
    
max_feature_2 = II_accuracy.index(max(II_accuracy))

starting_features = set(starting_features) - set(max_feature_2)

III_accuracy = []

for columns in starting_features:
    X_subset = df[:, [columns, max_feature_1, max_feature_2]]
    gnb = GaussianNB()
    X_train, X_test, y_train, y_test = train_test_split(X_subset, y, stratify=y, test_size= 0.3)
    gnb.fit(X_train, y_train)
    y_pred = gnb.predict(X_test)

    accuracy = accuracy_score(y_test, y_pred)
    
    III_accuracy.append(accuracy)    


max_feature_3 = III_accuracy.index(max(III_accuracy))
starting_features = set(starting_features) - set(max_feature_3)


IV_accuracy = []

for columns in starting_features:
    X_subset = df[:, [columns, max_feature_1, max_feature_2, max_feature_3]]
    gnb = GaussianNB()
    X_train, X_test, y_train, y_test = train_test_split(X_subset, y, stratify=y, test_size= 0.3)
    gnb.fit(X_train, y_train)
    y_pred = gnb.predict(X_test)

    accuracy = accuracy_score(y_test, y_pred)
    
    IV_accuracy.append(accuracy)    
    

max_feature_4 = IV_accuracy.index(max(IV_accuracy))


    round_results.append({
            'Round': len(best_features),
            'Selected Features': best_features.copy(),
            'Accuracy': best_accuracy
    })

    
    if best_accuracy == 1.0:
        break
        
print("Selected Features:", best_features)
print("Best Accuracy:", best_accuracy)


selected_features_table = pd.DataFrame(round_results)