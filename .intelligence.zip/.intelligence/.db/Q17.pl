% Base case: Deleting from the 1st position results in the tail of the list
delete_nth(1, [_|Tail], Tail).

% Recursive rule: Delete the Nth element from the list by keeping the head and deleting from the tail
delete_nth(N, [X|Tail], [X|R]) :-
    N > 1,
    N1 is N - 1,
    delete_nth(N1, Tail, R).
% Example usage:
% delete_nth(3, [1, 2, 3, 4, 5], Result).
