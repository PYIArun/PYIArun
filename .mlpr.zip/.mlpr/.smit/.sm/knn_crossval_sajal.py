import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, KFold, cross_val_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, make_scorer


winedata = pd.read_csv("C:/Users/Mayank/Desktop/Sem6/MachineLearning/Programs/WineQT.csv")

X = winedata.drop('quality', axis=1)
y = winedata['quality']

X_train, X_test, y_train, y_test =  train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

best_k = None
best_p = None
best_weight = None
best_acuracy = 0.0

k_values = [1,2,3,4,5,6,7,8,9,10]
p_values = [1,2]
weights = ['uniform','distance']

for k in k_values:
    for p in p_values:
        for weight in weights:
            
            knn = KNeighborsClassifier(n_neighbors=k, weights=weight, p=p)
            kf = KFold(n_splits=5, shuffle=True, random_state=42)

           
            cv_scores = cross_val_score(knn, X_train, y_train, cv=kf, scoring='accuracy')
            average_cv_accuracy = cv_scores.mean()
            
            print("accuracy for K=",k," with p=",p," and weight=",weight," is: ",average_cv_accuracy)
           
            if average_cv_accuracy > best_acuracy:
               best_acuracy = average_cv_accuracy
               best_k = k
               best_p = p
               best_weight = weight
    print("\n")
    
best_knn = KNeighborsClassifier(n_neighbors=best_k, weights=best_weight, p=best_p)
best_kf = KFold(n_splits=5, shuffle=True, random_state=42)
best_cv_scores = cross_val_score(best_knn, X_train, y_train, cv=best_kf, scoring='accuracy')
best_average_cv_accuracy = best_cv_scores.mean()
print(f"\ncross-validated accuracy: {best_average_cv_accuracy}")



print(f"best k = {best_k}")
print(f"best p = {best_p}")
print(f"best weight = {best_weight}")

best_knn.fit(X_train, y_train)
y_pred = best_knn.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print(f"accuracy: {accuracy}")


precision = precision_score(y_test, y_pred, average ='macro')
print("\n\nprecision:",precision)

recall = recall_score(y_test, y_pred, average='macro')
print(f"\nrecall: {recall}")

f1_score = f1_score(y_test, y_pred, average='macro')
print(f"\nf1_score: {f1_score}\n")

