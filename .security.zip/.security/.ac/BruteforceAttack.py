import time

flag = False
sentText = ""
sentKey = 0


def encrypt():
    str =   input("Enter the string you want to encrypt: ")
    key = int(input("Enter the key: "))  
    cipherText = ""
    for char in str:
        if char.isalpha():
            if char.isupper():
                cipherText += chr((ord(char) + key - ord('A')) %26 + ord('A'))
            else:
                cipherText += chr((ord(char) + key - ord('a')) %26 + ord('a'))
        else:
            cipherText += char
    print("The cipher text with key= ", key, " is : ", cipherText,"\n\n")
    return cipherText, key

def decrypt(sentText, key):
    str =   sentText
    plainText = ""

    for char in str:
        if char.isalpha():
            if char.isupper():
                plainText += chr((ord(char) - key - ord('A')) %26 + ord('A'))
            else:
                plainText += chr((ord(char) - key - ord('a')) %26 + ord('a'))
        else:
            plainText += char

    return plainText

def transmission():

    global sentText, sentKey, flag 

    sentText, sentKey = encrypt()

    print("Sending the encrypted text and key to Bob.")
    time.sleep(0.5)
    print('.')
    time.sleep(0.5)
    print('.')
    time.sleep(1)

    flag = True

    print("Message Sent!\n")

def bruteforceAttack(sentText):

    for i in range(0, 25):
        decrypted_text = decrypt(sentText, i)

        print("\nDo you consider ", decrypted_text, " the actual plain text? ")
        option = input("Enter 'yes' or 'no' : ")
        if option.lower() == 'yes':
            print('Done')
            break;
        else:
            continue

def main():

    global flag, sentText, sentKey


    print("Here is some description about people: \n")
    print("Alice : Sender")
    print("Bob : Receiver")
    print("Eve : Hacker")
        
    while True:       

        person = input("You are Alice or Bob or Eve?")
        person = person.lower()

        if(person=='alice'):
            while True:        
                print("What you want to perform? \n")
                
                print("**1. Encrypt a Message and Send it to Bob**")
                print("**2. Back***")
                print("************************")

                option = int(input("Enter the option, you want to perform: "))


                if option==1:
                    transmission()

                elif option==2:
                    break

                else:
                    print("Invalid Choice! Please Enter a valid option.")

        elif person=='bob':

            if flag==True:
                print("Receiving the Message from Alice ")
                time.sleep(0.3)
                print(".")
                time.sleep(0.3)
                print(".")
                time.sleep(0.3)

                decrypted_message = decrypt(sentText, sentKey)
                print("Decrypted Message:", decrypted_message)

            else:
                print(".")
                time.sleep(0.3)
                print(".")
                time.sleep(0.3)
                print(".")
                time.sleep(0.3)
                print("No Message Received from Alice.")

        else:
            while True:        
                print("What you want to perform? \n")
    
                print("**1. Interrupt the transmission of Message and Use Bruteforce Attack to decrypt**")
                print("**2. Back***")
                print("************************")

                option = int(input("Enter the option, you want to perform: "))

                if option==1:
                    bruteforceAttack(sentText)

                elif option==2:
                    break

                else:
                    print("Invalid Choice! Please Enter a valid option.")


main()