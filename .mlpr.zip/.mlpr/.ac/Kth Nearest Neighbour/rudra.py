# -*- coding: utf-8 -*-
"""
Created on Sun Mar  3 10:44:21 2024

@author: Arun
"""

# -- coding: utf-8 --
"""
Created on Sat Feb 24 21:21:58 2024

@author: DEV RATAN
"""

from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import precision_score, recall_score, f1_score

import pandas as pd
import numpy as np

from scipy.stats import mode

# Assuming classes is a list of classes of the k nearest neighbors


df = pd.read_csv("C:/Users/arunc/Desktop/Programs/HRanalytics.csv")
df['left'].value_counts()  # Ratio is 70 (not left) and 30 (left)
    
label_encoder = LabelEncoder()
df['Department'] = label_encoder.fit_transform(df['Department'])
df['salary'] = df['salary'].replace({'low': 1, 'medium': 2, 'high':3})
    
    
y = df['left']
X_prev = df.drop(['left'], axis=1)
    
scaler = StandardScaler()
x_scaled = scaler.fit_transform(X_prev) 
x_scaled

'''point=np.array([1,2,3])
point1=np.array([4,5,6])

euclidean_distance=np.linalg.norm(point-point1)'''
x_train, x_test, y_train, y_test = train_test_split(
    x_scaled, y, test_size=0.2, random_state=30)
from scipy.spatial.distance import cdist

weights_func = lambda distances: 1 / distances


distances = cdist(x_test, x_train, 'euclidean')
nearest_neighbors = np.argsort(distances, axis=1)
classes=y_train[nearest_neighbors]

print('FOR NORMAL DISTANCE WITH DIFFERENT VALUES OF K')

for k in range(1,6):
    kth_neighbours=nearest_neighbors[:,:k]
    nearest_neighbor_classes = y_train[kth_neighbours]
    mode_class = mode(nearest_neighbor_classes,axis=1)
    accuracy = accuracy_score(y_test, mode_class[0])

    precision = precision_score(y_test, mode_class[0], average='weighted')
    recall = recall_score(y_test,  mode_class[0], average='weighted')
    f1 = f1_score(y_test,mode_class[0], average='weighted')
    print("k is ",k)
    print("Accuracy:", accuracy)
    print("Precision:", precision)
    print("Recall:", recall)
    print("F1 Score:", f1)
  


def predict_class(x_train, y_train, x_test, k, weights_func):
    max_weighted_distance_class = np.zeros(len(x_test), dtype=int)
    
    for i in range(len(x_test)):
        # Calculate distances
        distances = np.sqrt(np.sum((x_train - x_test[i])**2, axis=1))
        
        # Get indices of k nearest neighbors
        indices = np.argsort(distances)[:k]
        
        # Calculate weights for each neighbor
        weights = weights_func(distances[indices])
        
        # Get class labels of the k nearest neighbors
        neighbor_classes = y_train[indices]
        
        # Calculate weighted distances for each neighbor
        weighted_distances = weights * distances[indices]
        
        # Find the index of the neighbor with the maximum weighted distance
        max_weighted_distance_idx = np.argmax(weighted_distances)
        
        # Get the class of the neighbor with the maximum weighted distance
        max_weighted_distance_class[i] = neighbor_classes[max_weighted_distance_idx]
    
    return max_weighted_distance_class

print(' \nFOR WEIGHTED DISTANCE WITH DIFFERENT VALUES OF K\n')
for k in range(1,6):
    predicted_classes = predict_class(x_train, y_train, x_test, k, weights_func)
    accuracy = accuracy_score(y_test, predicted_classes)
 
    # Calculate precision, recall, and F-score
    precision = precision_score(y_test, predicted_classes, average='weighted')
    recall = recall_score(y_test,  predicted_classes, average='weighted')
    f1 = f1_score(y_test,  predicted_classes, average='weighted')
    print("k is ",k)
    print("Accuracy:", accuracy)
    print("Precision:", precision)
    print("Recall:", recall)
    print("F1 Score:", f1)