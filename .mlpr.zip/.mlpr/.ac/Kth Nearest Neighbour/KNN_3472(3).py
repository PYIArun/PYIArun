# -*- coding: utf-8 -*-
"""
Created on Thu Feb 29 20:57:20 2024

@author: Arun
"""

'''Take a regression problem and build a regression model using sklearn, crossval, 
gridsearch, pipelines. Give performance in terms of RMSE
'''

'''
## diabetes KNN regression
from sklearn import datasets


diab= datasets.load_diabetes()
x=diab.data
diab.feature_names
y=diab.target
diab.data.shape

from sklearn.neighbors import KNeighborsRegressor
from sklearn import metrics

knn=KNeighborsRegressor(n_neighbors=2)
knn=KNeighborsRegressor(n_neighbors=5,weights='distance')

#knn=KNeighborsClassifier(n_neighbors=5)   #5 2 1
knn.fit(x,y)
y_predict=knn.predict(x)

score=metrics.mean_squared_error(y, y_predict)
print(score)

'''
from sklearn.neighbors import KNeighborsRegressor

from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import cross_val_score, cross_val_predict, GridSearchCV, train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score, mean_squared_error, r2_score
import pandas as pd
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn import metrics
import numpy as np
import pandas as pd

df = pd.read_csv('C:/Users/arunc/Desktop/Programs/Machine Learning/Kth Nearest Neighbour/Salary_dataset.csv')
df.head()
df.drop(['Unnamed: 0'], axis=1, inplace=True)
df.head()

X = df[['YearsExperience']]
y = df['Salary']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

pipeline = Pipeline([
    ('scaler', StandardScaler()),  # You can try other scalers if needed
    ('regressor', KNeighborsRegressor())
])

param_grid = {
    'regressor__n_neighbors': [3, 4, 5, 6, 7, 8, 9, 10],
    'regressor__weights': ['uniform', 'distance'],
    'regressor__p': [1, 2]
}

grid_search = GridSearchCV(pipeline, param_grid, cv=5, scoring='neg_mean_squared_error')
grid_search.fit(X_train, y_train)

print("Best Parameters:", grid_search.best_params_)
print("Best C-Val RMSE:", np.sqrt(-grid_search.best_score_))

best_model = grid_search.best_estimator_
y_pred = best_model.predict(X_test)

rmse = np.sqrt(mean_squared_error(y_test, y_pred))
print("RMSE on Test Set:", rmse)


r2 = r2_score(y_test, y_pred)
print("R2 Score on Test Set:", r2)