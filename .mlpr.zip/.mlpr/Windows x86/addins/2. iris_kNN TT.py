# -*- coding: utf-8 -*-
"""
Created on Mon Jul  6 18:04:26 2020

@author: BALJEET KAUR
"""


from sklearn import datasets
iris= datasets.load_iris()
x=iris.data
iris.feature_names
y=iris.target
iris.target_names
iris.data.shape

from sklearn.neighbors import KNeighborsClassifier
from sklearn import metrics
#knn=KNeighborsClassifier(n_neighbors=2,weights='distance')
#knn=KNeighborsClassifier(n_neighbors=2)


from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 0.2)

knn=KNeighborsClassifier(n_neighbors=2)
knn.fit(x_train,y_train)
y_predict=knn.predict(x_test)
score=metrics.accuracy_score(y_test, y_predict)
print(score)
print(metrics.confusion_matrix(y_test, y_predict))
