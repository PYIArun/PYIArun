# -*- coding: utf-8 -*-
"""
Created on Fri Feb  9 12:00:54 2024

@author: hp
"""

import pandas as pd
from sklearn.preprocessing import MinMaxScaler

from sklearn.naive_bayes import GaussianNB
from sklearn import metrics
from sklearn.model_selection import train_test_split

iris = load_iris()
X = iris.data
y = iris.target
scaler = MinMaxScaler((0,1))
X = scaler.fit_transform(X)
df = pd.DataFrame(X, columns = iris.feature_names)

scaler = MinMaxScaler((0,1))
X=scaler.fit_transform(X)

x_train, x_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 0, stratify=y, shuffle=True)
gnb = GaussianNB()

#Feaure Scaling

gnb.fit(x_train, y_train)

y_test_hat=gnb.predict(x_test) 

test_accuracy=metrics.accuracy_score(y_test,y_test_hat)*100

print("Accuracy for our testing dataset with tuning is : {:.2f}%".format(test_accuracy) )

#FEATURE Scaling and Feature RELEVANCE

import numpy as np

# scaler = MinMaxScaler((0,1))
# X=scaler.fit_transform(X)

df1 =pd.DataFrame(X)
df1['species']=y
corr_data=df1.corr()
import seaborn as sns
sns.heatmap(corr_data)
sel_data=corr_data.iloc[-1,:-1]
sel_D = abs(sel_data).sort_values(ascending = False)
result = []
for i in range(0,len(sel_D)):
    id=[]
    for j in range(0,i+1):
        id.append(sel_D.index[j])
    X_small = X[:,id]
    x_train, x_test, y_train, y_test = train_test_split(X_small, y, test_size = 0.2, random_state = 0, stratify=y, shuffle=True)
    gnb.fit(x_train, y_train)
    y_test_hat=gnb.predict(x_test) 
    test_accuracy=metrics.accuracy_score(y_test,y_test_hat)*100
    print("Using Columns {}".format(df.columns[id]))
    print("Accuracy for our testing dataset with columns {} is : {:.2f}%".format(id,test_accuracy))
    print()
    result.append({'Indices': id, 'Features': df.columns[id], 'Accuracy': '{:.2f}'.format(test_accuracy)})
df2 = pd.DataFrame(result)
print(df2) 
excel_fp = 'Iris_FilterFS.xlsx'
df2.to_excel(excel_fp, index=False)
print(f'Data Exported to {excel_fp}')