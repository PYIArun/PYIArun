# -*- coding: utf-8 -*-
"""
Created on Fri Jan 14 14:05:40 2022

@author: BALJEET KAUR
"""

from sklearn import datasets

from sklearn.model_selection import GridSearchCV
from sklearn.neighbors import KNeighborsClassifier
from sklearn import metrics
from sklearn.model_selection import train_test_split
breast_cancer = datasets.load_breast_cancer()

from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

X = breast_cancer.data
y = breast_cancer.target

x_train, x_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 0)


std_slc = StandardScaler()
knn = KNeighborsClassifier()

pipe = Pipeline(steps=[('std_slc', std_slc),
                          ('knn', knn)])
 #Sample 1

k_range = list(range(1, 6))
param_grid = dict(knn__n_neighbors=k_range)
grid = GridSearchCV(pipe, param_grid, cv=10, scoring='accuracy')

# fitting the model for grid search
grid_search=grid.fit(x_train, y_train)
print(grid_search.best_params_) 

knn = KNeighborsClassifier(n_neighbors=5)

knn.fit(x_train, y_train)

y_test_hat=knn.predict(x_test) 

test_accuracy=metrics.accuracy_score(y_test,y_test_hat)*100

print("Accuracy for our testing dataset with tuning is : {:.2f}%".format(test_accuracy) )
