# -*- coding: utf-8 -*-
"""
Created on Sun Mar 17 11:41:13 2024

@author: kripl
"""

import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

data = pd.read_csv('Bank Customer churn Prediction.csv')
data.columns
data.head()
le = LabelEncoder()
data['gender'] = le.fit_transform(data['gender'])
y = data['churn']
X= data.drop(['country','churn'], axis=1) 

X = np.array(X)
y = np.array(y)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
Logistic_Reg = LogisticRegression()
Logistic_Reg.fit(X_train,y_train)
predictions = Logistic_Reg.predict(X_test)



score = Logistic_Reg.score(X_test,y_test)
print(score)
