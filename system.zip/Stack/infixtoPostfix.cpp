#include <iostream>
#include <stack>
#include <cctype> // For isalpha and isdigit
using namespace std;

string infixToPostfix(string infix) {
    stack<char> aStack; // Stack to hold operators
    string postfixExpr = ""; // Resultant postfix expression

    for (char ch : infix) {
        if (isalnum(ch)) { // Case: Operand (alphanumeric character)
            postfixExpr += ch; // Append to postfix expression
        } 
        else if (ch == '(') { // Case: Opening parenthesis
            aStack.push(ch);
        } 
        else if (ch == ')') { // Case: Closing parenthesis
            // Pop and append until '(' is encountered
            while (!aStack.empty() && aStack.top() != '(') {
                postfixExpr += aStack.top();
                aStack.pop();
            }
            if (!aStack.empty()) { // Remove '(' from the stack
                aStack.pop();
            }
        } 
        else { // Case: Operator
            while (!aStack.empty() && aStack.top() != '(') {
                postfixExpr += aStack.top();
                aStack.pop();
            }
            aStack.push(ch); // Push current operator to stack
        }
    }

    // Append remaining operators in the stack to postfixExpr
    while (!aStack.empty()) {
        postfixExpr += aStack.top();
        aStack.pop();
    }

    return postfixExpr;
}

int main() {
    string infixExpr;
    cout << "Enter an infix expression: ";
    cin >> infixExpr;

    string postfixExpr = infixToPostfix(infixExpr);
    cout << "The postfix expression is: " << postfixExpr << endl;

    return 0;
}
