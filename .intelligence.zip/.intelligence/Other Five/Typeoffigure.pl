% Define predicates for each type of figure

% Rectangle
type_of_figure(rectangle, X, Y) :-
    X > 0,
    Y > 0,
    X \= Y.

% Square
type_of_figure(square, X, X) :-
    X > 0.

% Circle
type_of_figure(circle, Radius) :-
    Radius > 0.

% Triangle
type_of_figure(triangle, Side1, Side2, Side3) :-
    Side1 > 0,
    Side2 > 0,
    Side3 > 0,
    Side1 + Side2 > Side3,
    Side1 + Side3 > Side2,
    Side2 + Side3 > Side1.

% Example usage:
% ?- type_of_figure(rectangle, 5, 3).
% true.

% ?- type_of_figure(square, 4, 4).
% true.

% ?- type_of_figure(circle, 5).
% true.

% ?- type_of_figure(triangle, 3, 4, 5).
% true.
