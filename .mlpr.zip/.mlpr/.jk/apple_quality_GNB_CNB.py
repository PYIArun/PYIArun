# -*- coding: utf-8 -*-
"""
Created on Fri Feb  2 11:03:45 2024

@author: kaush
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.naive_bayes import GaussianNB
from sklearn.naive_bayes import CategoricalNB
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix

apple_quality= pd.read_csv('apple_quality.csv')
num= LabelEncoder()

apple_quality.info()
rows, columns= apple_quality.shape
print(apple_quality.isnull().sum())

apple_quality.dropna(inplace=True)
print(apple_quality.isnull().sum())

apple_quality['Quality'] = num.fit_transform(apple_quality['Quality'])

features = ['Size', 'Weight', 'Sweetness', 'Crunchiness', 'Juiciness', 'Ripeness', 'Acidity']
target = "Quality"

'''
cnb= CategoricalNB()
cnb.fit(apple_quality[features], apple_quality[target])

y_pred=cnb.predict(apple_quality[features])
print('Accuracy: ', accuracy_score(y_pred, apple_quality[target]))

'''


# gnb= GaussianNB()

# gnb.fit(features_train, target_train)


num_splits = 10
accuracies = []

for i in range(num_splits):
    features_train, features_test, target_train, target_test = train_test_split(apple_quality[features],apple_quality[target],test_size = 0.3, stratify=apple_quality[target])
    
    gnb = GaussianNB()
    model = gnb.fit(features_train, target_train)
    y_pred = model.predict(features_test)
    
    accuracy = accuracy_score(target_test, y_pred)
    accuracies.append(accuracy)
    
    print(f"Accuracy for split {i + 1}: {accuracy}")
    print("Confusion Matrix:")
    print(confusion_matrix(target_test, y_pred))
    print("-" * 40)

average_accuracy = np.mean(accuracies)
print(f"\nAverage Accuracy over {num_splits} splits: {average_accuracy}")

features_train, features_test, target_train, target_test = train_test_split(apple_quality[features],apple_quality[target],test_size = 0.3, stratify=apple_quality[target])
gnb = GaussianNB()
model = gnb.fit(features_train, target_train)
y_pred = model.predict(features_test)

y_pred=model.predict(features_test)
print("Number of wrong predictions out of a total %d points : %d"
      % (features_test.shape[0], (target_test != y_pred).sum()))


print(accuracy_score(target_test, y_pred))
print(confusion_matrix(target_test, y_pred))








'''

import seaborn as sns

# Assuming 'Quality' is the target column and other columns are features
features_with_target = features + ['Quality']

# Calculate the correlation matrix
correlation_matrix = apple_quality[features_with_target].corr()

# Plotting the heatmap
plt.figure(figsize=(10, 8))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt=".2f", linewidths=.5)
plt.title('Correlation Matrix')
plt.show()

'''

