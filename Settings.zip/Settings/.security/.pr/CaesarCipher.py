def encrypt(text, key):
    
    cipherText = ""

    for char in text : 
        if char.isalpha():
            if char.isupper():
                cipherText += chr((ord(char) + key - ord('A'))%26 + ord('A'))
            else: 
                cipherText += chr((ord(char) + key - ord('a'))%26 + ord('a'))
        
        else:
            cipherText += char

    print("The output Cipher Text is : ", cipherText)
    print("They key used is: ", key)


def decrypt(text, key):
    plainText = ""

    for char in text : 
        if char.isalpha():
            if char.isupper():
                plainText += chr((ord(char) - key - ord('A'))%26 + ord('A'))
            else: 
                plainText += chr((ord(char) - key - ord('a'))%26 + ord('a'))
            
        else:
                plainText += char

    print("The output Plain Text is : ", plainText)
    print("They key used is: ", key)

def bruteforce(text):

    for i in range(0, 30):
        decrypt(text, i)
        a = input("Is this correct? Y for yes and n for no: ")
        if a.lower()== 'y':
            break
        
while True: 
    a = int(input('You want to encrypt or decrypt: 1 For Encrypt & 2 For Decrypt & 3 For Exit & 4 for bruteforce: '))

    if (a ==1):
        text = input("Enter the plain text to encrypt: ")
        key = int(input("Enter the key: "))
        encrypt(text, key)

    elif (a == 2):
        text = input("Enter the text to decrypt: ")
        key = int(input("Enter the key: "))
        decrypt(text, key)
        
    elif (a==4):
        text = input("Enter the text to decrypt: ")
        bruteforce(text)

    else:
        break;


