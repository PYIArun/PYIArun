from PIL import Image
import numpy as np

image = Image.open('OIP.jpg')
image_array = np.array(image)
image_bits = np.unpackbits(image_array)

watermark_text = "HellO"  
watermarking_bits = ''.join(format(ord(char), '08b') for char in watermark_text)


total_watermark_bits = len(watermarking_bits)

num_parts = total_watermark_bits
image_parts = np.array_split(image_bits, num_parts)

watermark_index = 0
for i, part in enumerate(image_parts):
    start_index = i * len(part)
    end_index = start_index + len(part)
    for j in range(start_index, end_index):
        if watermark_index < total_watermark_bits:
            part[j] = (part[j] & 0b11111110) | int(watermarking_bits[watermark_index])
            watermark_index += 1

embedded_image_bits = np.concatenate(image_parts)
embedded_image_array = np.packbits(embedded_image_bits)
embedded_image = Image.fromarray(embedded_image_array.reshape(image_array.shape))
embedded_image.save('output_image_with_watermark.jpg')
