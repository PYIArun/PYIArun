# -*- coding: utf-8 -*-
"""
Created on Mon Feb 26 08:12:17 2024

@author:"""


from sklearn import datasets
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn import metrics
wine= datasets.load_wine()
x=wine.data
wine.feature_names
y=wine.target
wine.data.shape

from sklearn.neighbors import KNeighborsRegressor
from sklearn import metrics
scaler = StandardScaler()
x_scaled = scaler.fit_transform(x) 
x_scaled
x_train, x_test, y_train, y_test = train_test_split(x_scaled, y, test_size = 0.2)


#knn=KNeighborsRegressor(n_neighbors=2)
knn=KNeighborsRegressor(n_neighbors=5,weights='distance')

#knn=KNeighborsClassifier(n_neighbors=5)   #5 2 1
knn.fit(x_train,y_train)
y_predict=knn.predict(x_test)
test_accuracy=accuracy_score(y_test,y_predict)*100
score=metrics.mean_squared_error(y, y_predict)
print(score)





