#include<iostream>
#include <algorithm>
using namespace std;

void insertionSort(int arr[], int n){


    for(int i =0; i<n; i++){


        int j = i;

        while(j>0 && arr[j-1]>arr[j]){
            swap(arr[j-1], arr[j]);
            j--;
        }

    }
    return;
}

int main()
{
    int arr[] = {4, 5, 3, 2, 1};
    insertionSort(arr, 5);

    for(int i=0; i<5; i++){
        cout<< arr[i]<< " ";
    }
    
    return 0;
}