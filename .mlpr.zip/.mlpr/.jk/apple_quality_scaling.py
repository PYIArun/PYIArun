import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from sklearn.naive_bayes import GaussianNB
from sklearn import metrics
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import seaborn as sns

# Load the data
apple_quality = pd.read_csv('apple_quality.csv')

# Encode the target variable
num = LabelEncoder()
apple_quality['Quality'] = num.fit_transform(apple_quality['Quality'])

# Handle missing values
apple_quality.dropna(inplace=True)

# Define features and target
features = ['Size', 'Weight', 'Sweetness', 'Crunchiness', 'Juiciness', 'Ripeness', 'Acidity']
target = "Quality"

x = apple_quality[features]
y = apple_quality[target]


scaler = MinMaxScaler((0, 1))
x = scaler.fit_transform(x)

x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=0)

gnb = GaussianNB()

gnb.fit(x_train, y_train)

y_test_hat = gnb.predict(x_test)

test_accuracy = metrics.accuracy_score(y_test, y_test_hat) * 100
print("Accuracy for the testing dataset with tuning: {:.2f}%".format(test_accuracy))

df = pd.DataFrame(x, columns=features)

corr_data = df.corr()

# Sort correlations with respect to the target variable
corr_with_target = corr_data.abs().sum(axis=1).sort_values(ascending=False)

best_accuracy = 0
best_features = []
results = []

# Iterate over sorted correlations and evaluate model accuracy
for feature in corr_with_target.index:
    selected_features = list(corr_with_target[:corr_with_target.index.get_loc(feature) + 1].index)
    selected_x = df[selected_features]

    x_train_sel, x_test_sel, _, _ = train_test_split(selected_x, y, test_size=0.2, random_state=0)

    gnb.fit(x_train_sel, y_train)

    y_test_hat_sel = gnb.predict(x_test_sel)

    test_accuracy_sel = metrics.accuracy_score(y_test, y_test_hat_sel) * 100

    results.append((selected_features, test_accuracy_sel))

    if test_accuracy_sel > best_accuracy:
        best_accuracy = test_accuracy_sel
        best_features = selected_features

    #print("Features:", selected_features)
    #print("Accuracy: {:.2f}%".format(test_accuracy_sel))

print("\nBest Accuracy: {:.2f}%".format(best_accuracy))
print("Best Feature Combination:", best_features)

# Save results to Excel file
results_df = pd.DataFrame(results, columns=['Feature Combination', 'Accuracy'])
results_df.to_excel('feature_selection_results.xlsx', index=False)
print("Results saved to 'feature_selection_results.xlsx'")

# Plot correlation heatmap
sns.heatmap(corr_data)
plt.show()


