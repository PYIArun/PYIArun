# -*- coding: utf-8 -*-
"""
Created on Thu Feb  8 11:07:47 2024

@author: kripl
"""
#from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import LabelEncoder
import numpy as np
import pandas as pd

data = pd.read_csv("D:/Semester 6/jobs_in_data.csv")
print(data.head)
data.columns
data.describe()
le = LabelEncoder()

data['job_title'] = le.fit_transform(data['job_title'])
data['job_category'] = le.fit_transform(data['job_category'])
data['employee_residence'] = le.fit_transform(data['employee_residence'])
data['experience_level'] = le.fit_transform(data['experience_level'])
data['employment_type'] = le.fit_transform(data['employment_type'])
data['work_setting'] = le.fit_transform(data['work_setting'])
data['company_location'] = le.fit_transform(data['company_location'])
data['company_size'] = le.fit_transform(data['company_size'])
data['salary_currency'] = le.fit_transform(data['salary_currency'])

target = data['company_size']
features = ['work_year', 'job_title', 'job_category', 'salary_currency', 'salary','salary_in_usd', 'employee_residence', 'experience_level','employment_type', 'work_setting', 'company_location']
print(data)
data.isnull().sum()

corre = data.corr()
c = data.corr()['company_size'].abs()
c = c.sort_values(ascending =False)
c
import seaborn as sns
sns.heatmap(corre)
#corr_features = data.corr()['company_size'].abs()

required_features = c.index[1:]

List =[]


for i in range(1, len(required_features)+1):
    sel = required_features[:i]
    sample = data[sel]
    
    X_train,X_test, y_train, y_test = train_test_split(sample, target, test_size=0.2, stratify=target,  random_state =2)
    gnb = GaussianNB()
    model= gnb.fit(X_train, y_train)
    y_pred=model.predict(X_test)
    accuracy = accuracy_score(y_test,y_pred)
    print("Accuracy of per class:", accuracy)
    List.append(accuracy*100)
    print(List)
 
    
Result = pd.DataFrame(List)
Result.to_csv("Tanisha_3422.csv")




