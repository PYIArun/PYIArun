# -*- coding: utf-8 -*-
"""
Created on Thu Feb  1 12:07:06 2024

@author: kaush

Assignment Q.1 

"""

from sklearn.datasets import make_blobs
from sklearn.naive_bayes import GaussianNB
# generate 2d classification dataset
X, y = make_blobs(n_samples=100, centers=3, n_features=2, random_state=1,cluster_std=5)
# define the model
import matplotlib.pyplot as plt
import numpy as np

plt.scatter(X[:,0],X[:,1],c=y)

model= GaussianNB()

model.fit(X, y)
# select a single sample
'''
Xsample, ysample = [X[0]], y[0]   #scikit expects a 2 D array, hence note the difference

#Xsample.reshape(1,-1)
# make a probabilistic prediction
yhat_prob = model.predict_proba(Xsample)
print('Predicted Probabilities: ', yhat_prob)
# make a classification prediction
yhat_class = model.predict(Xsample)
print('Predicted Class: ', yhat_class)
print('Truth: y=%d' % ysample)

'''

# make a classification prediction
yhat_class = model.predict(X)
# print('Predicted Class: ', yhat_class)
from sklearn.metrics import accuracy_score
print('Accuracy: ', accuracy_score(yhat_class, y))

yhat_1 = 0
yhat_2 = 0
yhat_3 = 0

actual_1 = 0
actual_2 = 0
actual_3 = 0

correct_1 = 0
correct_2 = 0
correct_3 = 0

for i in range(len(X)):
    Xsample = np.reshape(X[i], (1, -1))  # Reshape to 2D array
    yhat_class = model.predict(Xsample)
    
    if yhat_class == 0: 
        yhat_1 += 1
        if y[i] == 0: #Basically agr yhat zero hota bhi hai but class 0 nhi hai toh correct count increment nhi hoga
            correct_1 += 1
    elif yhat_class == 1:
        yhat_2 += 1
        if y[i] == 1:
            correct_2 += 1
    else:
        yhat_3 += 1
        if y[i] == 2:
            correct_3 += 1
    
    if y[i] == 0:
        actual_1 += 1
    elif y[i] == 1:
        actual_2 += 1
    else:
        actual_3 += 1

print('Predicted Class 0 Count:', yhat_1)
print('Predicted Class 1 Count:', yhat_2)
print('Predicted Class 2 Count:', yhat_3)

print('Correct 1 predicted:',correct_1)

print('Actual Class 0 Count:', actual_1)
print('Actual Class 1 Count:', actual_2)
print('Actual Class 2 Count:', actual_3)

accuracy_1 = correct_1 / actual_1 if actual_1 > 0 else 0
accuracy_2 = correct_2 / actual_2 if actual_2 > 0 else 0
accuracy_3 = correct_3 / actual_3 if actual_3 > 0 else 0

print('Accuracy for Class 0:', accuracy_1)
print('Accuracy for Class 1:', accuracy_2)
print('Accuracy for Class 2:', accuracy_3)