# -*- coding: utf-8 -*-
"""
Created on Tue Feb 13 09:23:34 2024

@author: 
"""

from sklearn import datasets
from sklearn.preprocessing import MinMaxScaler

from sklearn.naive_bayes import GaussianNB

from sklearn import metrics
from sklearn.model_selection import train_test_split
from sklearn.datasets import load_iris
iris=load_iris()
 
X, y = iris.data, iris.target
scaler = MinMaxScaler((0,1))
X=scaler.fit_transform(X)


from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import f_classif

x_train, x_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 0)
gnb = GaussianNB()

gnb.fit(x_train, y_train)

y_test_hat=gnb.predict(x_test) 

test_accuracy=metrics.accuracy_score(y_test,y_test_hat)*100

print("Accuracy for our testing dataset with tuning is : {:.2f}%".format(test_accuracy) )


test = SelectKBest(score_func=f_classif, k=4)
X_small = test.fit_transform(X,y)
selected_mask=(test._get_support_mask())
print(iris.feature_names[selected_mask])

x_train, x_test, y_train, y_test = train_test_split(X_small, y, test_size = 0.2, random_state = 0)
gnb = GaussianNB()
gnb.fit(x_train, y_train)

y_test_hat=gnb.predict(x_test) 

test_accuracy=metrics.accuracy_score(y_test,y_test_hat)*100

print("Accuracy for our testing dataset with tuning is : {:.2f}%".format(test_accuracy) )


from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import mutual_info_classif


test = SelectKBest(score_func=mutual_info_classif, k=2)
X_small = test.fit_transform(X,y)
selected_mask=(test._get_support_mask())
print(iris.feature_names[selected_mask])

x_train, x_test, y_train, y_test = train_test_split(X_small, y, test_size = 0.2, random_state = 0)
gnb = GaussianNB()
gnb.fit(x_train, y_train)

y_test_hat=gnb.predict(x_test) 

test_accuracy=metrics.accuracy_score(y_test,y_test_hat)*100

print("Accuracy for our testing dataset with tuning is : {:.2f}%".format(test_accuracy) )
