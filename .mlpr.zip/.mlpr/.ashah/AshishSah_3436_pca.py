# -*- coding: utf-8 -*-
"""
Created on Fri Feb  9 01:01:23 2024

@author: HP
"""
from sklearn.decomposition import PCA
import pandas as pd
from sklearn.preprocessing import MinMaxScaler

df = pd.read_csv("C:/Users/ashis/OneDrive/Desktop/Machine Learning/Mobile.csv")
print(df)

X = df.drop('price_range',axis=1)
y = df['price_range']
scaler = MinMaxScaler((0,1))
X=scaler.fit_transform(X)


pca = PCA()
Xt = pca.fit_transform(X)

from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score
result = []
for i in range(0,Xt.shape[1]):
    X_train, X_test, y_train, y_test = train_test_split(Xt[:,:i+1], y, test_size=0.2,random_state=0)
    gnb = GaussianNB()
    model= gnb.fit(X_train, y_train)
    y_pred=model.predict(X_test)
    test_accuracy = accuracy_score(y_test, y_pred) * 100
    info_sum = sum(pca.explained_variance_ratio_[0:i+1]) *  100
    print(f'Information amount till k{i+1} : {info_sum}')
    print(f'Accuracy with k{i+1} : {test_accuracy}')
    result.append({'Features Count': i+1, 'Information_Amount ': info_sum, 'Accuracy': '{:.2f}'.format(test_accuracy)})
    
df2 = pd.DataFrame(result)
print(df2) 
print(df2[df2['Accuracy']==max(df2['Accuracy'])].iloc[0,[0,2]])
pca_bp = df2[df2['Accuracy']==max(df2['Accuracy'])].iloc[0,[0,2]]
excel_fp = 'AshishSah_3436.xlsx'
df2.to_excel(excel_fp, index=False)
print(f'Data Exported to {excel_fp}')