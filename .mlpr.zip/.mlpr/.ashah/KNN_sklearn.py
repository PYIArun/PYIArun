import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, precision_score,  recall_score, f1_score

df = pd.read_csv('C:/Users/HP/Desktop/Machine Learning/Mobile.csv')
X = df.drop('price_range',axis=1)
y = df['price_range']
df.drop('price_range',axis=1, inplace= True)
X = np.array(X)
X_train, x_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 42, shuffle= True, stratify = y)
# Initialize and fit the KNN model
best_k = None
best_p = None
best_weights = None
best_accuracy = 0.0
k_values = range(1,11)
p_values = [1,2]
weight = ['uniform', 'distance']
for k in k_values:
    for p in p_values:
        for weights in weight:
            knn = KNeighborsClassifier(n_neighbors=k, p= p, weights = weights)
            knn.fit(X_train, y_train)
            y_pred = knn.predict(x_test)
            accuracy = accuracy_score(y_test, y_pred)*100
            print(f'Accuracy for k={k} with p{p} and weight {weights}: {accuracy}')
            if accuracy > best_accuracy:
                best_accuracy = accuracy
                best_k = k
                best_p = p
                best_weights = weights
print(f"\nBest k value: {best_k}")
print(f"\nBest p value: {best_p}")
print(f"\nBest weights values: {best_weights}")

# Create the final model with the best k
final_model = KNeighborsClassifier(n_neighbors= best_k, p= best_p, weights = best_weights)
final_model.fit(X_train, y_train)
y_pred = final_model.predict(x_test)
accuracy = accuracy_score(y_test, y_pred)
print("Accuracy of the Model: ", accuracy*100)
print("\nConfusion Matrix:")
conf_matrix = confusion_matrix(y_test, y_pred)
print(conf_matrix)
print("\nPrecision Score:")
precision = precision_score(y_test, y_pred, average ='macro')
print(precision)
print("\nRecall Score:")
recall = recall_score(y_test, y_pred, average = 'macro')
print(recall)
print("\nF1 Score:")
f1score = f1_score(y_test, y_pred, average = 'macro')
print(f1score)