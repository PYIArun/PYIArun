# -*- coding: utf-8 -*-
"""
Created on Thu Feb 29 23:21:37 2024

@author: kripl
"""

# Regression Problem
import numpy as np
import pandas as pd
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.neighbors import KNeighborsRegressor
from sklearn.metrics import mean_squared_error
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import LabelEncoder

data = pd.read_csv("D:/Semester 6/insurance.csv")
print(data.head)
data.columns
data.describe()
le = LabelEncoder()

data['sex'] = le.fit_transform(data['sex'])
data['smoker'] = le.fit_transform(data['smoker'])
data['region'] = le.fit_transform(data['region'])



y = data['charges']
Features = data.drop(['charges'], axis=1)


scaler = StandardScaler()
X = scaler.fit_transform(Features)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0,  shuffle= True)

pipe = Pipeline(steps=[('scaler', StandardScaler()), ('knn', KNeighborsRegressor())])


param_grid = {
    'knn__n_neighbors': list(range(1, 11)),
    'knn__weights': ['uniform', 'distance'],
    'knn__p': [1, 2]
}

grid = GridSearchCV(pipe, param_grid, cv=10, scoring='neg_mean_squared_error')


grid_search = grid.fit(X_train, y_train)
print('Best Hyperparameters: ', grid_search.best_params_)

best_model = grid_search.best_estimator_
y_pred= best_model.predict(X_test) 

mse = mean_squared_error(y_test, y_pred)
print("Mean Squared Error: ", mse)
rmse = np.sqrt(mse)
print("Root Mean Squared Error: ", rmse)
