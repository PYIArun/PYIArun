% Q6. Power
pow(_, 0, 1).

pow(X, Y, R) :-
    Y1 is Y - 1,
    pow(X, Y1, R1),
    R is X * R1.

