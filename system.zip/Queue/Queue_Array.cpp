#include <iostream>
using namespace std;

#define SIZE 10

template <class T>
class Queue {
    int arr[SIZE];
    int front;
    int rear;

public:
    Queue() {
        front = -1;
        rear = -1;
    }

    void enqueue(T x) {
        if (isFull()) {
            cout << "Queue is Full!" << endl;
            return;
        }
        if (isEmpty()) {
            front = 0;
            rear = 0;
            arr[rear] = x;
            return;
        }
        rear++;
        arr[rear] = x;
    }

    T dequeue() {
        if (isEmpty()) {
            cout << "Queue is Empty!" << endl;
            return T();
        }
        T element = arr[front];
        if (front == rear) {
            front = -1;
            rear = -1;
        } else {
            front++;
        }
        return element;
    }

    T getFront() {
        if (isEmpty()) {
            return T();
        }
        return arr[front];
    }

    T getRear() {
        if (isEmpty()) {
            return T();
        }
        return arr[rear];
    }

    bool isEmpty() {
        return front == -1 && rear == -1;
    }

    bool isFull() {
        return rear == SIZE - 1;
    }

    int size() {
        if (isEmpty()) {
            return 0;
        }
        return (rear - front) + 1;
    }

    void printQueue() {
        if (isEmpty()) {
            cout << "Queue is Empty!" << endl;
            return;
        }
        for (int i = front; i <= rear; i++) {
            cout << arr[i] << " ";
        }
        cout << endl;
    }
};

int main() {
    Queue<int> q;
    int choice, value;

    do {
        cout << "\nMenu:\n";
        cout << "1. Enqueue\n";
        cout << "2. Dequeue\n";
        cout << "3. Get Front\n";
        cout << "4. Get Rear\n";
        cout << "5. Check if Empty\n";
        cout << "6. Check if Full\n";
        cout << "7. Print Queue\n";
        cout << "8. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter value to enqueue: ";
                cin >> value;
                q.enqueue(value);
                break;
            case 2:
                cout << "Dequeued: " << q.dequeue() << endl;
                break;
            case 3:
                cout << "Front: " << q.getFront() << endl;
                break;
            case 4:
                cout << "Rear: " << q.getRear() << endl;
                break;
            case 5:
                cout << (q.isEmpty() ? "Queue is Empty." : "Queue is Not Empty.") << endl;
                break;
            case 6:
                cout << (q.isFull() ? "Queue is Full." : "Queue is Not Full.") << endl;
                break;
            case 7:
                cout << "Current Queue: ";
                q.printQueue();
                break;
            case 8:
                cout << "Exiting..." << endl;
                break;
            default:
                cout << "Invalid choice! Please try again." << endl;
        }
    } while (choice != 8);

    return 0;
}
