#include <graphics.h>
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>

//hello
#define ROUND(a) ((int)(a + 0.5))

int xmax, ymax;

void ellipsePlotPoints(int, int, int, int, int, int, int, int);

void ellipseMidPoint(int xc, int yc, int rx, int ry)
{
   int rx2 = rx * rx, ry2 = ry * ry, tworx2 = 2 * rx2, twory2 = 2 * ry2;
   int p;
   int x = 0, y = ry, px = 0, py = tworx2 * y;

   ellipsePlotPoints(xc, yc, 4*x, 4*y, xc, yc, rx, ry);

   p = ROUND(ry2 - (rx2 * ry) + (0.25 * rx2));
   while (px < py)
   {
      x++;
      px += twory2;
      if (p < 0)
      {
     p += ry2 + px;
      }
      else
      {
     y--;
     py -= tworx2;
     p += ry2 + px - py;
      }
      ellipsePlotPoints(xc, yc, 4*x,4*y, xc, yc, rx, ry);
   }

   p = ROUND(ry2 * (x + 0.5) * (x + 0.5) + rx2 * (y - 1) * (y - 1) - rx2 * ry2);
   while (y > 0)
   {
      y--;
      py -= tworx2;
      if (p > 0)
     p += rx2 - py;
      else
      {
     x++;
     px += twory2;
     p += rx2 - py + px;
      }
      ellipsePlotPoints(xc, yc,4*x,4*y, xc, yc, rx, ry);
   }
}

void ellipsePlotPoints(int xc, int yc, int x, int y, int orig_xc, int orig_yc, int rx, int ry)
{
   putpixel(orig_xc + x, orig_yc - y, 255); // Quadrant I
   putpixel(orig_xc - x, orig_yc - y, 255); // Quadrant II
   putpixel(orig_xc - x, orig_yc + y, 255); // Quadrant III
   putpixel(orig_xc + x, orig_yc + y, 255); // Quadrant IV
}

int main(void)
{
   /* request auto detection */
   int gdriver = DETECT, gmode, errorcode;

   /* initialize graphics and local variables */
   initgraph(&gdriver, &gmode, "C:\\TURBOC3\\BGI");

   /* read result of initialization */
   errorcode = graphresult();
   /* an error occurred */
   if (errorcode != grOk)
   {
      printf("Graphics error: %s\n", grapherrormsg(errorcode));
      printf("Press any key to halt:");
      getch();
      exit(1);
   }

   setcolor(getmaxcolor());
   xmax = getmaxx();
   ymax = getmaxy();

   // Draw horizontal and vertical lines
   line(0, ymax/2, xmax, ymax/2); // Horizontal line
   line(xmax/2, 0, xmax/2, ymax); // Vertical line

   // Draw the ellipse
   ellipseMidPoint(xmax/2, ymax/2, 150, 150);

   /* clean up */
   getch();
   closegraph();
   return 0;
}
