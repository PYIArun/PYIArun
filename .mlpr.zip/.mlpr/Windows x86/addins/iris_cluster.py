# -*- coding: utf-8 -*-
"""
Created on Thu Jul 23 19:27:11 2020

@author: BALJEET KAUR
"""
# -*- coding: utf-8 -*-
"""
Created on Mon Jul  6 18:04:26 2020

@author: BALJEET KAUR
"""

from sklearn import datasets


iris= datasets.load_iris()
x=iris.data
iris.feature_names
y=iris.target
iris.target_names
iris.data.shape

from sklearn.cluster import KMeans
kmeans=KMeans(n_clusters=3)
kmeans.fit(x)
kmeans.cluster_centers_
ypred=kmeans.labels_
import matplotlib.pyplot as plt
plt.scatter(x[:,0],x[:,1],c=y )
plt.scatter(x[:,0],x[:,1],c=kmeans.labels_ )


