# -*- coding: utf-8 -*-
"""
Created on Fri Mar 15 12:08:15 2024

@author: hp
"""
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_squared_error

studentdata = pd.read_csv("C:/Users/hp/Desktop/3432/ML/Student_Performance.csv")

# Map "Extracurricular Activities" feature to 0 and 1
activity_mapping = {'Yes': 1, 'No': 0}
studentdata['Extracurricular Activities'] = studentdata['Extracurricular Activities'].map(activity_mapping)

X = studentdata.drop('Performance Index', axis = 1)
y = studentdata['Performance Index']
# Assuming your data is stored in X (features) and y (target)
# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Define a range of lambda values to test
lambda_values = [0.001, 0.01, 0.1, 1, 10, 100]

best_lambda = None
best_score = float('inf')

# Loop through each lambda value
for lambda_val in lambda_values:
    # Train the model
    model = Ridge(alpha=lambda_val)
    model.fit(X_train, y_train)
    
    # Evaluate the model
    y_pred = model.predict(X_test)
    mse = mean_squared_error(y_test, y_pred)
    
    print(f"for lambda: {lambda_val} mse is {mse}")
    
    # Check if this is the best lambda so far
    if mse < best_score:
        best_score = mse
        best_lambda = lambda_val

print("Best lambda:", best_lambda)
