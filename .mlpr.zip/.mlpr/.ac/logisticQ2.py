# m,n = 1372,4
# y==0, 0.55
# y==1, 0.44


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import scipy.optimize as opt
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

def prediction(X, y, theta, cutoff):
    y_cap = sigmoid(np.dot(X, theta))
    pred = [1 if yi >= cutoff else 0 for yi in y_cap]
    return pred
    
def accuracy(pred, y):
    acc = np.mean(pred == y)
    return (acc * 100)

def sigmoid(x):
  return 1/(1+np.exp(-x))

def costFunction(theta, X, y):
    J = (-1/m) * ((y.T@ np.log(sigmoid(X @ theta)))+((1-y).T@np.log(1 - sigmoid(X @ theta))))
    return J  

def gradient(theta, X, y):
    return ((1/m) * X.T @ (sigmoid(X @ theta) - y))

def gradientDescent(X, y, theta, alpha):
    while(True):
        derivative = gradient(theta, X, y)
        new_theta = theta - alpha*derivative
        delta = np.isclose(new_theta,theta)
        if(delta.all()==True):
            return new_theta
        theta = new_theta
        print(costFunction(theta, X, y))

scaler = StandardScaler()
alpha = 2

data = pd.read_csv("D:\\ML\\data_banknote_authentication.txt", header = None)
X = data.iloc[:,:-1]
X = scaler.fit_transform(X)
X = np.hstack((np.ones((len(X),1)), X))
y = np.array(data.iloc[:,-1]).reshape(-1,1)
m,n = X.shape

theta = np.zeros((n,1))

X_train, X_test, y_train, y_test = train_test_split(X,y, test_size=0.2,random_state=0, stratify=y)

cost = costFunction(theta, X_train, y_train)
print(cost)

temp = opt.fmin_tnc(func = costFunction, x0 = theta.flatten(),
                    fprime = gradient, args = (X_train, y_train.flatten()))
theta_optimized = temp[0]
theta_optimized_cost = costFunction(theta_optimized,X_train,y_train)
new_theta = gradientDescent(X_train,y_train,theta,alpha)
new_theta_cost = costFunction(new_theta,X_train,y_train)

train_accuracy = []
test_accuracy = []
for i in range(10):
    X_train, X_test, y_train, y_test = train_test_split(X,y, test_size=0.2,random_state=0, stratify=y)
    train_pred = prediction(X_train, y_train, theta_optimized, 0.5)
    train_accuracy.append(accuracy_score(train_pred, y_train))
    test_pred = prediction(X_test, y_test, theta_optimized, 0.5)
    test_accuracy.append(accuracy_score(test_pred, y_test))
    
logisticRegr = LogisticRegression()
logisticRegr.fit(X_train, y_train)
predictions = logisticRegr.predict(X_test)
score = logisticRegr.score(X_test, y_test)

predictions == test_pred


