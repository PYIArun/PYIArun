#include <iostream>
#include <vector>

using namespace std;

// Function to traverse a 2-D matrix in spiral order
// To: Print the elements of the matrix in spiral order
// Input:
//   - int matrix[][]: 2-D matrix to be traversed
//   - int rows: Number of rows in the matrix
//   - int cols: Number of columns in the matrix
// Output:
//   - None
// Approach:
//   - Use four boundaries to traverse the matrix: top, bottom, left, and right.
//   - Move in the order: left to right, top to bottom, right to left, bottom to top.
//   - Adjust the boundaries after each move.

void traverse_spiral(int** matrix, int rows, int cols) {
    if (rows == 0 || cols == 0) return;

    int top = 0, bottom = rows - 1;
    int left = 0, right = cols - 1;

    cout << "Matrix elements in spiral order:" << endl;

    while (top <= bottom && left <= right) {
        for (int i = left; i <= right; ++i) {
            cout << matrix[top][i] << " ";
        }
        ++top;

        for (int i = top; i <= bottom; ++i) {
            cout << matrix[i][right] << " ";
        }
        --right;

        if (top <= bottom) {
            for (int i = right; i >= left; --i) {
                cout << matrix[bottom][i] << " ";
            }
            --bottom;
        }

        if (left <= right) {
            for (int i = bottom; i >= top; --i) {
                cout << matrix[i][left] << " ";
            }
            ++left;
        }
    }
}

int main() {
    int rows, cols;

    cout << "Enter the number of rows and columns: ";
    cin >> rows >> cols;

    int** matrix = new int*[rows];
    for (int i = 0; i < rows; ++i) {
        matrix[i] = new int[cols];
    }

    cout << "Enter the elements of the matrix:" << endl;
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            cin >> matrix[i][j];
        }
    }

    traverse_spiral(matrix, rows, cols);

    for (int i = 0; i < rows; ++i) {
        delete[] matrix[i];
    }
    delete[] matrix;

    return 0;
}
