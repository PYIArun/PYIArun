# -*- coding: utf-8 -*-
"""
Created on Thu Feb 29 13:15:36 2024

@author: kripl
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import cross_val_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import precision_score, make_scorer, recall_score, f1_score
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import StandardScaler

data = pd.read_csv("D:/Semester 6/jobs_in_data.csv")
print(data.head)
data.columns
data.describe()
le = LabelEncoder()

data['job_title'] = le.fit_transform(data['job_title'])
data['job_category'] = le.fit_transform(data['job_category'])
data['employee_residence'] = le.fit_transform(data['employee_residence'])
data['experience_level'] = le.fit_transform(data['experience_level'])
data['employment_type'] = le.fit_transform(data['employment_type'])
data['work_setting'] = le.fit_transform(data['work_setting'])
data['company_location'] = le.fit_transform(data['company_location'])
data['company_size'] = le.fit_transform(data['company_size'])
data['salary_currency'] = le.fit_transform(data['salary_currency'])


y = data['company_size']
Features = data.drop(['company_size'], axis=1)


scaler = StandardScaler()
X = scaler.fit_transform(Features)
knn = KNeighborsClassifier(n_neighbors=10, p= 2, weights = 'distance')
print('Using Accuracy Score: ')
cv_folds = 10
cv_scr=cross_val_score(knn, X, y, cv=cv_folds)
print('Cross Val Score: ', cv_scr)
print('Mean: ', np.mean(cv_scr))
print('Standard Deviation: ', np.std(cv_scr))

print('Using Precision Score: ')
precision_scorer = make_scorer(precision_score, average = 'macro')
cv_folds = 10
cv_scr=cross_val_score(knn, X, y, cv=cv_folds, scoring = precision_scorer)
print('Cross Val Score: ', cv_scr)
print('Mean: ', np.mean(cv_scr))
print('Standard Deviation: ', np.std(cv_scr))

print('Using Recall Score: ')
recall_scorer = make_scorer(recall_score, average = 'macro')
cv_folds = 10
cv_scr=cross_val_score(knn, X, y, cv=cv_folds, scoring = recall_scorer)
print('Cross Val Score: ', cv_scr)
print('Mean: ', np.mean(cv_scr))
print('Standard Deviation: ', np.std(cv_scr))

print('Using F1 Score: ')
f1_scorer = make_scorer(f1_score, average = 'macro')
cv_folds = 10
cv_scr=cross_val_score(knn, X, y, cv=cv_folds, scoring = f1_scorer)
print('Cross Val Score: ', cv_scr)
print('Mean: ', np.mean(cv_scr))
print('Standard Deviation: ', np.std(cv_scr))
