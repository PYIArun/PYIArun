#include <iostream>

using namespace std;

// Function to sort an array of integers in ascending order
// To: Sort the array so that elements are arranged in increasing order
// Input:
//   - int arr[]: Array to be sorted
//   - int size: Number of elements in the array
// Output:
//   - None
// Approach:
//   - Iterate through the array and for each element, compare it with previous elements.
//   - Shift elements as necessary to insert the current element into its correct position.

void sort_array(int arr[], int size) {
    for (int i = 1; i < size; ++i) {
        int key = arr[i];
        int j = i - 1;

        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            --j;
        }
        arr[j + 1] = key;
    }
}

int main() {
    int size;

    cout << "Enter the number of elements in the array: ";
    cin >> size;

    int* arr = new int[size];

    cout << "Enter the elements of the array: ";
    for (int i = 0; i < size; ++i) {
        cin >> arr[i];
    }

    sort_array(arr, size);

    cout << "Sorted array: ";
    for (int i = 0; i < size; ++i) {
        cout << arr[i] << " ";
    }
    cout << endl;

    delete[] arr;

    return 0;
}
