# -*- coding: utf-8 -*-
"""
Created on Mon Feb 26 23:11:56 2024

@author: kripl
"""

from sklearn.preprocessing import LabelEncoder
from sklearn.decomposition import TruncatedSVD
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.naive_bayes import GaussianNB
import pandas as pd
import numpy as np
from scipy.linalg import svd
from numpy.linalg import svd

data = pd.read_csv("D:/Semester 6/jobs_in_data.csv")
print(data.head)
data.columns
data.describe()
le = LabelEncoder()

data['job_title'] = le.fit_transform(data['job_title'])
data['job_category'] = le.fit_transform(data['job_category'])
data['employee_residence'] = le.fit_transform(data['employee_residence'])
data['experience_level'] = le.fit_transform(data['experience_level'])
data['employment_type'] = le.fit_transform(data['employment_type'])
data['work_setting'] = le.fit_transform(data['work_setting'])
data['company_location'] = le.fit_transform(data['company_location'])
data['company_size'] = le.fit_transform(data['company_size'])
data['salary_currency'] = le.fit_transform(data['salary_currency'])


y = data['company_size']
Features = data.drop(['company_size'], axis=1)

scaler = StandardScaler()
X = scaler.fit_transform(Features)

gnb = GaussianNB()



features = []
accuracies = []

#svd = TruncatedSVD()

for i in range(X.shape[1]):
    svd = TruncatedSVD(i+1)
    svd.fit(X)
    value = svd.transform(X)
    x_train, x_test, y_train, y_test = train_test_split(value, y, test_size=0.2, random_state=0)
    gnb = GaussianNB()

    model = gnb.fit(x_train, y_train)
    y_pred = model.predict(x_test)
    accuracy = accuracy_score(y_test, y_pred)*100
    features.append(i)
    accuracies.append(accuracy)
    

  
result_df = pd.DataFrame({
    "No. of features: " : features,
    "Accuracy": accuracies
    })

print(result_df)


from numpy import array
from numpy import diag
from numpy import zeros
from scipy.linalg import svd


U, s, VT = svd(X)

Sigma = zeros((X.shape[0], X.shape[1]))

d = np.diag(s[:X.shape[1]])
Sigma[:d.shape[0], :d.shape[1]] = d

n_elements = 2
Sigma = Sigma[:, :n_elements]
VT = VT[:n_elements, :]

B = U.dot(Sigma.dot(VT))
print(B)
# transform
T = U.dot(Sigma)
print(T)
T = X.dot(VT.T)
print(T)




import numpy as np
import pandas as pd

# Assuming X is a DataFrame with 9335 rows and 12 columns
X = pd.DataFrame(np.random.rand(9335, 12), columns=[f'col_{i}' for i in range(1, 13)])

# Perform SVD
U, s, VT = np.linalg.svd(X)

# Create m x n Sigma matrix
Sigma = np.zeros((X.shape[0], X.shape[1]))

# Populate Sigma with n x n diagonal matrix
Sigma[:X.shape[1], :X.shape[1]] = np.diag(s)

# Select the desired number of singular values
n_elements = 2
Sigma = Sigma[:, :n_elements]
VT = VT[:n_elements, :]

# Reconstruct the matrix
B = U.dot(Sigma.dot(VT))
reconstructed_df = pd.DataFrame(B, columns=X.columns)
print("Reconstructed DataFrame B:")
print(reconstructed_df)

# Transform using U and Sigma
T = U.dot(Sigma)
transformed_df = pd.DataFrame(T, columns=[f'SV_{i+1}' for i in range(n_elements)])
print("\nTransformed DataFrame T (using U and Sigma):")
print(transformed_df)

# Alternatively, transform using X and VT.T
T_alternative = X.dot(VT.T)
transformed_alternative_df = pd.DataFrame(T_alternative, columns=[f'SV_{i+1}' for i in range(n_elements)])
print("\nTransformed DataFrame T (using X and VT.T):")
print(transformed_alternative_df)
