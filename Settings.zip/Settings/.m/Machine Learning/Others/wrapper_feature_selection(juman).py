'''

# Importing necessary libraries
import numpy as np
from sklearn.datasets import load_iris
from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# Load the Iris dataset
iris = load_iris()
X = iris.data
y = iris.target

# Splitting the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Initialize Gaussian Naive Bayes classifier
gnb = GaussianNB()

# Initialize empty list to store selected features
selected_features = []

# Iterate through each feature
for i in range(X_train.shape[1]):
    # Initialize best correlation and feature index
    best_correlation = -1
    best_feature_index = -1
    
    # Iterate through each feature
    for j in range(X_train.shape[1]):
        # If the feature is already selected, skip it
        if j in selected_features:
            continue
        
        # Calculate correlation between the current feature and the target variable
        correlation = np.abs(np.corrcoef(X_train[:, j], y_train)[0, 1])
        
        # Update best correlation and feature index if current correlation is higher
        if correlation > best_correlation:
            best_correlation = correlation
            best_feature_index = j
    
    # Add the best feature to the selected features list
    selected_features.append(best_feature_index)
    
    # Select the features
    X_train_selected = X_train[:, selected_features]
    X_test_selected = X_test[:, selected_features]
    
    # Train Gaussian Naive Bayes classifier on the selected features
    gnb.fit(X_train_selected, y_train)
    
    # Predicting on the test set
    y_pred = gnb.predict(X_test_selected)
    
    # Calculate accuracy
    accuracy = accuracy_score(y_test, y_pred)
    
    # Print accuracy and selected features
    print(f"Accuracy after adding feature {i + 1}: {accuracy:.4f}")
    print("Selected features:", selected_features)
    print()





import numpy as np
import pandas as pd
from sklearn.datasets import load_iris
from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

iris = load_iris()
X = iris.data
y = iris.target

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=8)

gnb = GaussianNB()

model= gnb.fit(X_train, y_train)
y_pred=model.predict(X_test)
print("Number of mislabeled points out of a total %d points : %d"
      % (X_test.shape[0], (y_test != y_pred).sum()))


from sklearn.metrics import accuracy_score
print(accuracy_score(y_test, y_pred))

from sklearn.metrics import confusion_matrix
print(confusion_matrix(y_test, y_pred))

df=pd.DataFrame(X)
df['class']=y
corr_data=df.corr()

# Initialize empty list to store selected features
selected_features = []
accuracies = []

# Initialize empty list to store results
results = []

# Iterate through each feature
for i in range(X_train.shape[1]):
    # Initialize best correlation and feature index
    best_correlation = -1
    best_feature_index = -1
    
    # Iterate through each feature
    for j in range(X_train.shape[1]):
        # If the feature is already selected, skip it
        if j in selected_features:
            continue
        
        # Calculate correlation between the current feature and the target variable
        correlation = np.abs(np.corrcoef(X_train[:, j], y_train)[0, 1])
        
        # Update best correlation and feature index if current correlation is higher
        if correlation > best_correlation:
            best_correlation = correlation
            best_feature_index = j
    
    # Add the best feature to the selected features list
    selected_features.append(best_feature_index)
    
    # Select the features
    X_train_selected = X_train[:, selected_features]
    X_test_selected = X_test[:, selected_features]
    
    # Train Gaussian Naive Bayes classifier on the selected features
    gnb.fit(X_train_selected, y_train)
    
    # Predicting on the test set
    y_pred = gnb.predict(X_test_selected)
    
    # Calculate accuracy
    accuracy = accuracy_score(y_test, y_pred)
    accuracies.append(accuracy)
    
    # Store results in list
    results.append({'Iteration': i + 1,
                    'Selected Features': selected_features.copy(),
                    'Accuracy': accuracy})

# Convert list of dictionaries to DataFrame
results_df = pd.DataFrame(results)

# Save results to Excel file
results_df.to_excel("feature_selection_results.xlsx", index=False)

# Print DataFrame
print(results_df)

'''

import numpy as np
import pandas as pd
from sklearn.datasets import load_iris
from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# Load the Iris dataset
iris = load_iris()
X = iris.data
y = iris.target

# Splitting the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=5)

# Initialize Gaussian Naive Bayes classifier
gnb = GaussianNB()

# Initialize empty list to store selected features
selected_features = []

# Initialize empty DataFrame to store detailed results
detailed_results_df = pd.DataFrame(columns=['Iteration', 'Features', 'Accuracy'])

# Iterate through each feature
for i in range(X_train.shape[1]):
    # Initialize best accuracy and feature index
    best_accuracy = -1
    best_feature_index = -1
    
    # Initialize empty list to store detailed results for this iteration
    accuracies = []
    
    # Iterate through each feature
    for j in range(X_train.shape[1]):
        # If the feature is already selected, skip it
        if j in selected_features:
            continue
        
        # Select the current feature
        current_features = selected_features + [j]
        X_train_selected = X_train[:, current_features]
        X_test_selected = X_test[:, current_features]
        
        # Train Gaussian Naive Bayes classifier on the selected features
        gnb.fit(X_train_selected, y_train)
        
        # Predicting on the test set
        y_pred = gnb.predict(X_test_selected)
        
        # Calculate accuracy
        accuracy = accuracy_score(y_test, y_pred)
        
        # Append accuracy of the current combination of features to accuracies list
        accuracies.append({'Iteration': i + 1, 'Features': current_features, 'Accuracy': accuracy})
        
    # Get the feature with the highest accuracy for this iteration
    best_feature = max(accuracies, key=lambda x: x['Accuracy'])
    best_accuracy = best_feature['Accuracy']
    
    # Add the best feature to the selected features list
    selected_features = best_feature['Features']
    
    # Convert the list of dictionaries to a DataFrame
    accuracies_df = pd.DataFrame(accuracies)
    
    # Append detailed results for this iteration to the DataFrame
    detailed_results_df = pd.concat([detailed_results_df, accuracies_df], ignore_index=True)
    
    # Print detailed results for this iteration
    print(f"Iteration {i + 1}: Features = {best_feature['Features']}, Accuracy = {best_accuracy:.4f}")

# Save detailed results to Excel file
detailed_results_df.to_excel("feature_selection_detailed_results.xlsx", index=False)

# Print DataFrame
print(detailed_results_df)
