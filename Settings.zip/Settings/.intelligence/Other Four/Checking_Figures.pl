is_triangle(Side1, Side2, Side3):-
    Side1 + Side2>Side3,
    Side2 + Side3>Side1,
    Side1 + Side3>Side2.

is_rectangle(Side1, Side2, Side3, Side4):-
    Side1 = Side3,
    Side2 = Side4,
    Side1 \= Side2.

is_square(Side1, Side2, Side3, Side4) :-
    Side1 = Side2,
    Side2 = Side3,
    Side3 = Side4.

is_circle(Radius) :-
    Radius > 0.
