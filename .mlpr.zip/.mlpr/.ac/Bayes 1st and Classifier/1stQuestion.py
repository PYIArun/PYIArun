# -*- coding: utf-8 -*-
"""
Created on Mon Feb  5 09:57:44 2024

@author: Arun 
"""

from sklearn.datasets import make_blobs
from scipy.stats import norm
from numpy import mean
from numpy import std
import numpy as np
from numpy import mean, std

def fit_distribution(data):
    mu = mean(data)
    sigma = std(data)
    print(mu, sigma)
    
    # Fit distribution
    dist = norm(mu, sigma)
    return dist

def probability(X, prior, dist1, dist2):
    return prior * dist1.pdf(X[0]) * dist2.pdf(X[1])



# Generate 2D classification dataset
X, y = make_blobs(n_samples=100, centers=3, n_features=2, random_state=1, cluster_std=2)

import matplotlib.pyplot as plt


plt.scatter(X[:,0], X[:, 1], c=y)

# Calculate priors
priory0 = len(X[y == 0]) / len(X)
priory1 = len(X[y == 1]) / len(X)
priory2 = len(X[y == 2]) / len(X)

# Create PDFs for y==0
distX1y0 = fit_distribution(X[y == 0][:, 0])
distX2y0 = fit_distribution(X[y == 0][:, 1])

# Create PDFs for y==1
distX1y1 = fit_distribution(X[y == 1][:, 0])
distX2y1 = fit_distribution(X[y == 1][:, 1])

# Create PDFs for y==2
distX1y2 = fit_distribution(X[y == 2][:, 0])
distX2y2 = fit_distribution(X[y == 2][:, 1])

# classify one example
Xsample, ysample = X[2], y[2]
py0 = probability(Xsample, priory0, distX1y0, distX2y0)
py1 = probability(Xsample, priory1, distX1y1, distX2y1)
py2 = probability(Xsample, priory1, distX1y2, distX2y2)

print('P(y=0 | %s) = %.3f' % (Xsample, py0*100))
print('P(y=1 | %s) = %.3f' % (Xsample, py1*100))
print('P(y=2 | %s) = %.3f' % (Xsample, py2*100))
print('Truth: y=%d' % ysample)

# Initialize counters
yhat_counts = [0, 0, 0]
correct_counts = [0, 0, 0]
actual_counts = [0, 0, 0]


confusion_matrix = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]


for Xsample, ysample in zip(X, y):
    py0, py1, py2 = probability(Xsample, priory0, distX1y0, distX2y0), probability(Xsample, priory1, distX1y1, distX2y1), probability(Xsample, priory2, distX1y2, distX2y2)


    chosen_class = np.argmax([py0, py1, py2])

    yhat_counts[chosen_class] += 1

    if chosen_class == ysample:
        correct_counts[ysample] += 1

    actual_counts[ysample] += 1
    
    confusion_matrix[ysample][chosen_class] += 1

print()
for c in range(3):
    print('Predicted Class', c, 'Count:', yhat_counts[c])
    print('Correctly Predicted Class', c, 'Count:', correct_counts[c])
    print('Actual Class', c, 'Count:', actual_counts[c])
    print("__")

print()
for c in range(3):
    accuracy = correct_counts[c] / actual_counts[c] * 100
    print('Accuracy for Class', c, ':', accuracy)

print()

overall_accuracy = sum(correct_counts) / len(X) * 100
print('Overall Accuracy:', overall_accuracy)

print()
print("Confusion Matrix:")
for row in confusion_matrix:
    print(row)


