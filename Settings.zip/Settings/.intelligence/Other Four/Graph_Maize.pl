edge(a,b).
edge(b,a).
edge(b,c).
edge(c,d).
edge(e,f).
edge(f,g).

can_go(X, Y):-
    edge(X,Y).

can_go(X, Y):-
    edge(X,Z),
    can_go(Z,Y).


