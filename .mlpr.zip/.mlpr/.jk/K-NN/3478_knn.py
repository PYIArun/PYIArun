# -*- coding: utf-8 -*-
"""
Created on Mon Feb 26 00:54:31 2024

@author: kaush
"""

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.neighbors import KNeighborsClassifier

# Read the dataset
df = pd.read_csv('apple_quality.csv')

label_encoder = LabelEncoder()
df['Quality'] = label_encoder.fit_transform(df['Quality'])

df.dropna(inplace=True)
df.drop('A_id', axis=1, inplace=True)

features = ['Size', 'Weight', 'Sweetness', 'Crunchiness', 'Juiciness', 'Ripeness', 'Acidity']
target = "Quality"

# Scale the features
scaler = StandardScaler()
df_scaled = df.copy()
df_scaled[features] = scaler.fit_transform(df_scaled[features])

X = df_scaled[features]
y = df_scaled[target]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=1)

k_range = range(1, 100)

# Lists to store metrics
accuracy_list = []
precision_list = []
recall_list = []
f1_score_list = []
confusion_matrices = []

# Iterate over k values
for k in k_range:
    # Train KNN classifier
    knn = KNeighborsClassifier(n_neighbors=k)
    knn.fit(X_train, y_train)
    
    y_pred = knn.predict(X_test)
    
    accuracy = accuracy_score(y_test, y_pred)
    accuracy_list.append(accuracy)
    
    cm = confusion_matrix(y_test, y_pred)
    confusion_matrices.append(cm)
    
    precision = cm[1, 1] / (cm[1, 1] + cm[0, 1])
    precision_list.append(precision)

    recall = cm[1, 1] / (cm[1, 1] + cm[1, 0])
    recall_list.append(recall)
    
    # Calculate F1 score
    f1_score = 2 * (precision * recall) / (precision + recall)
    f1_score_list.append(f1_score)

# Find best k
best_k_index = accuracy_list.index(max(accuracy_list))
best_k = k_range[best_k_index]

# Plot the graph
plt.plot(k_range, accuracy_list)
plt.xlabel('Values for k')
plt.ylabel('Accuracy Score')
plt.title('KNN Accuracy for Different Values of k')
plt.show()

# Print metrics
print("Best k:", best_k)
print("Accuracy:", accuracy_list[best_k_index])
print("Precision:", precision_list[best_k_index])
print("Recall:", recall_list[best_k_index])
print("F1 Score:", f1_score_list[best_k_index])
print("Confusion Matrix:")
print(confusion_matrices[best_k_index])
