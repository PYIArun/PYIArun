# -*- coding: utf-8 -*-
"""
Created on Sun Feb 25 20:50:04 2024

@author: kaush
"""

from ucimlrepo import fetch_ucirepo 
  
# fetch dataset 
dry_bean_dataset = fetch_ucirepo(id=602) 
  
X = dry_bean_dataset.data.features 
y = dry_bean_dataset.data.targets 
  
# metadata 
#print(dry_bean_dataset.metadata)  
# variable information 
#print(dry_bean_dataset.variables) 


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.naive_bayes import GaussianNB
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler, LabelEncoder, StandardScaler
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn.decomposition import TruncatedSVD



df=pd.DataFrame(X)
df.info()
rows, columns= df.shape
df.describe()
print(df.isnull().sum())

label_encoder = LabelEncoder()
y= label_encoder.fit_transform(y)

class_counts = pd.Series(y).value_counts()
print("Total number of wines in each class:")
print(class_counts)


scaler = StandardScaler()
X_Scaled = scaler.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(X_Scaled, y, test_size=0.3,stratify=y, random_state=0)

gnb = GaussianNB()
gnb.fit(X_train, y_train)

y_test_hat = gnb.predict(X_test)
test_accuracy = accuracy_score(y_test, y_test_hat) * 100

print("Accuracy for the testing dataset without tuning: {:.2f}%".format(test_accuracy))

results = []


max_components = min(len(X_Scaled[0]), len(X_Scaled))
for n_features in range(1, max_components + 1):
    X_Scaled = scaler.fit_transform(X)
    
    svd = TruncatedSVD(n_components=n_features)
    X_svd = svd.fit_transform(X_Scaled)
    X_train, X_test, y_train, y_test = train_test_split(X_svd, y, test_size=0.3,stratify=y, random_state=0)
    gnb = GaussianNB()
    gnb.fit(X_train, y_train)
    y_test_hat = gnb.predict(X_test)
    test_accuracy = accuracy_score(y_test, y_test_hat) * 100
    
    results.append({'No. of Features': n_features,
                    'Accuracy': test_accuracy,
                    'Explained Variance Ratio': sum(svd.explained_variance_ratio_)})

results_df = pd.DataFrame(results)
results_df.to_excel('3478_drbean_svd_results.xlsx', index=False)
print(results_df)

