#include <iostream>
#include <algorithm>

using namespace std;

// Function to find the union of two sorted arrays and return all unique elements
// To: Find all unique elements that are present in either of the two input arrays.
// Input:
//   - int arr1[]: First sorted array
//   - int m: Size of the first array
//   - int arr2[]: Second sorted array
//   - int n: Size of the second array
// Output:
//   - int*: Pointer to the array containing unique elements from both input arrays
//   - int& result_size: Reference to an integer to store the size of the resulting array
// Approach:
//   - Combine both arrays into a single array.
//   - Sort the combined array.
//   - Use a two-pointer approach to merge and find unique elements.

int* find_union(int arr1[], int m, int arr2[], int n, int& result_size) {
    // Allocate an array to hold combined elements
    int* combined = new int[m + n];
    
    // Copy elements from arr1 to combined
    for (int i = 0; i < m; ++i) {
        combined[i] = arr1[i];
    }
    
    // Copy elements from arr2 to combined
    for (int i = 0; i < n; ++i) {
        combined[m + i] = arr2[i];
    }
    
    // Sort the combined array
    sort(combined, combined + m + n);
    
    // Remove duplicates using two-pointer approach
    int* result = new int[m + n]; // Allocate maximum possible size for result
    int result_size_index = 0;
    
    for (int i = 0; i < m + n; ++i) {
        // Skip duplicates
        if (i == 0 || combined[i] != combined[i - 1]) {
            result[result_size_index++] = combined[i];
        }
    }
    
    // Adjust the result size
    result_size = result_size_index;
    
    // Free the combined array
    delete[] combined;
    
    return result;
}

int main() {
    int m, n;
    
    // Input size and elements for the first array
    cout << "Enter the size of the first array: ";
    cin >> m;
    int* arr1 = new int[m];
    
    cout << "Enter the elements of the first array: ";
    for (int i = 0; i < m; ++i) {
        cin >> arr1[i];
    }
    
    // Input size and elements for the second array
    cout << "Enter the size of the second array: ";
    cin >> n;
    int* arr2 = new int[n];
    
    cout << "Enter the elements of the second array: ";
    for (int i = 0; i < n; ++i) {
        cin >> arr2[i];
    }
    
    // Sort both arrays
    sort(arr1, arr1 + m);
    sort(arr2, arr2 + n);
    
    // Find the union of the two arrays
    int result_size;
    int* result = find_union(arr1, m, arr2, n, result_size);

    // Output the result
    cout << "Union of the two arrays: ";
    for (int i = 0; i < result_size; ++i) {
        cout << result[i] << " ";
    }
    cout << endl;

    // Free dynamically allocated memory
    delete[] arr1;
    delete[] arr2;
    delete[] result;

    return 0;
}
