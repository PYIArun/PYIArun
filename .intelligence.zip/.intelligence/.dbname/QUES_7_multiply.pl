% Q7. Multiplication
multiply(0, _, 0).
multiply(X, Y, Z) :-
    X > 0,
    X1 is X - 1,
    multiply(X1, Y, Z1),
    sum(Z1, Y, Z).
sum(X,Y,Z):-
    Z is X+Y.
