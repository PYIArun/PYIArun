#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jan 27 08:46:21 2024

@author: baljeetkaur
"""

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
#L=load_iris()
X, y = load_iris(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
gnb = GaussianNB()
model= gnb.fit(X_train, y_train)
y_pred=model.predict(X_test)
print("Number of mislabeled points out of a total %d points : %d"
      % (X_test.shape[0], (y_test != y_pred).sum()))


















from sklearn.metrics import accuracy_score
accuracy_score(y_test, y_pred)


from sklearn.metrics import confusion_matrix
confusion_matrix(y_test, y_pred)



