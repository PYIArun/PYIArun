#include <iostream>
#include <stack>

using namespace std;

template <class T>
class QueueUsingStacks {
private:
    stack<T> stack1;
    stack<T> stack2;

public:
    void enqueue(T value) {
        stack1.push(value);
    }

    T dequeue() {
        if (stack2.empty()) {
            while (!stack1.empty()) {
                stack2.push(stack1.top());
                stack1.pop();
            }
        }

        if (stack2.empty()) {
            cout << "Queue is empty!" << endl;
            return T();
        }

        T value = stack2.top();
        stack2.pop();
        return value;
    }

    T front() {
        if (stack2.empty()) {
            while (!stack1.empty()) {
                stack2.push(stack1.top());
                stack1.pop();
            }
        }

        if (stack2.empty()) {
            cout << "Queue is empty!" << endl;
            return T();
        }

        return stack2.top();
    }

    bool isEmpty() {
        return stack1.empty() && stack2.empty();
    }

    void printQueue() {
        if (isEmpty()) {
            cout << "Queue is empty!" << endl;
            return;
        }

        stack<T> tempStack = stack2;
        while (!tempStack.empty()) {
            cout << tempStack.top() << " ";
            tempStack.pop();
        }

        tempStack = stack1;
        stack<T> reverseStack;
        while (!tempStack.empty()) {
            reverseStack.push(tempStack.top());
            tempStack.pop();
        }
        while (!reverseStack.empty()) {
            cout << reverseStack.top() << " ";
            reverseStack.pop();
        }
        cout << endl;
    }
};

int main() {
    QueueUsingStacks<int> queue;

    queue.enqueue(10);
    queue.enqueue(20);
    queue.enqueue(30);
    
    cout << "Current queue: ";
    queue.printQueue();

    cout << "Front element: " << queue.front() << endl;

    cout << "Dequeued: " << queue.dequeue() << endl;
    cout << "Current queue after dequeue: ";
    queue.printQueue();

    cout << "Dequeued: " << queue.dequeue() << endl;
    cout << "Current queue after dequeue: ";
    queue.printQueue();

    cout << "Dequeued: " << queue.dequeue() << endl;
    cout << "Current queue after dequeue: ";
    queue.printQueue();

    return 0;
}
