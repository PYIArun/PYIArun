% Base case: Reversing an empty list results in an empty list
reverse([], []).

% Recursive rule: Reverse the tail of the list and append the head at the end
reverse([Head|Tail], Reversed) :-
    reverse(Tail, ReversedTail),
    append(ReversedTail, [Head], Reversed).
% Example usage:
% Querying reverse([1, 2, 3, 4], Result).
