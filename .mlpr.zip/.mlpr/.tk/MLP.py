# -*- coding: utf-8 -*-
"""
Created on Tue Apr  9 22:26:33 2024

@author: kripl
"""

from sklearn.neural_network import MLPClassifier
import numpy as np
from sklearn.metrics import accuracy_score
from sklearn import datasets

Iris = datasets.load_iris()
X = Iris.data
y = Iris.target

data = datasets.load_breast_cancer()
X = data.data
y = data.target


model = MLPClassifier(
    activation='logistic', max_iter=2000, hidden_layer_sizes=(4,2))
model.fit(X, y)

model = MLPClassifier(
    activation='relu', max_iter=20000, hidden_layer_sizes=(3,3,3))
model.fit(X, y)

print('score:', model.score(X, y))
print('predictions:', model.predict(X)) 
print('expected:', y)
