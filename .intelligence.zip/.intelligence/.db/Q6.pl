% Base case: Any number raised to the power 0 is 1
power(_, 0, 1).

% Recursive rule: Num^Pow is Num multiplied by Num^(Pow-1)
power(Num, Pow, Ans) :-
    Pow > 0,
    Pow1 is Pow - 1,
    power(Num, Pow1, Temp),
    Ans is Num * Temp.
% Example usage:
% power(2, 3, Result).
