% Base case: An empty list is a palindrome
palindrome([]).

% Base case: A list with a single element is a palindrome
palindrome([_]).

% Recursive rule: A list is a palindrome if its first and last elements
% are the same, and the rest of the list (excluding the first and last
% elements) is also a palindrome.
palindrome([First|Rest]) :-
    append(Middle, [Last], Rest),
    First = Last,
    palindrome(Middle).
% Example usage:
% Querying palindrome([1, 2, 3, 2, 1]).
