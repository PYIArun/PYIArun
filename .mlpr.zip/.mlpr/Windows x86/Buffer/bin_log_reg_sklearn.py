# -*- coding: utf-8 -*-
"""
Created on Thu Mar 21 12:20:28 2024

@author: 
"""

import pandas as pd
from sklearn.preprocessing import StandardScaler
data=pd.read_csv("C:/Users/91931/Desktop/MLprograms/loistic_regression/diabetes.csv")
x = data.iloc[:,:-1]
y = data.iloc[:,8]

Scaler=StandardScaler()
x_scaled=Scaler.fit_transform(x)

print(x.shape)

print( y.shape)
import numpy as np 
 
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x_scaled, y, test_size=0.25, random_state=0)

from sklearn.linear_model import LogisticRegression
logr= LogisticRegression()
logr.fit(x_train, y_train)
predictions = logr.predict(x_test)
y_test=np.array(y_test)
# Use score method to get accuracy of model
score = logr.score(x_test,y_test)
print(score)

