% Define a rule for summing two numbers
sum(X, Y, Result) :-
    Result is X + Y.

% Example usage:
% sum(3, 4, Result).
