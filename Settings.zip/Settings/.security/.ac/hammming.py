import random

class Hamming:
    def __init__(self):
        self.M = [0] * 8

    def sending(self):
        self.M[0] = 0
        print("Enter any 4 data bits: ", end="")
        self.M[7], self.M[6], self.M[5], self.M[3] = map(int, input().split())

        self.M[1] = self.M[3] ^ self.M[5] ^ self.M[7]
        self.M[2] = self.M[3] ^ self.M[6] ^ self.M[7]
        self.M[4] = self.M[5] ^ self.M[6] ^ self.M[7]

        print("Resultant Bits sending towards receiver:", end=" ")
        for i in range(7, 0, -1):
            print(self.M[i], end=" ")
    
    def communication(self):
        random_data = self.M[3:8]  # copy data bits for random errors

        n_error = random.randint(0, 3)
        print("\nNumber of error bits:", n_error)

        print("Position of error bit:", end=" ")
        for i in range(n_error):
            place = random.randint(3, 7)
            print(place, end=" ")
            random_data[place-3] = 0 if random_data[place-3] == 1 else 1  # flip random bits
        
        # Assigning the random bit errors into the main data bits
        self.M[3:8] = random_data

        print("\nMessage after error bits:", end=" ")
        for i in range(7, 0, -1):
            print(self.M[i], end=" ")

    def receiving(self):
        c1 = self.M[1] ^ self.M[3] ^ self.M[5] ^ self.M[7]
        c2 = self.M[2] ^ self.M[3] ^ self.M[6] ^ self.M[7]
        c3 = self.M[4] ^ self.M[5] ^ self.M[6] ^ self.M[7]

        p = c1*1 + c2*2 + c3*4  # binary to decimal conversion
        print()
        if p == 0:
            print("No error detected.")
        else:
            print("There is an error that has been detected.")

def main():
    h = Hamming()
    h.sending()
    h.communication()
    h.receiving()

if __name__ == "__main__":
    main()
