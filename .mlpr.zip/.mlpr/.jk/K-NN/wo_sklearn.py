# -*- coding: utf-8 -*-
"""
Created on Mon Mar  4 09:37:12 2024

@author: kaush
"""

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix, precision_score, recall_score, f1_score
from sklearn.preprocessing import StandardScaler, LabelEncoder
import numpy as np


df = pd.read_csv('apple_quality.csv')

label_encoder = LabelEncoder()
df['Quality'] = label_encoder.fit_transform(df['Quality'])

df.dropna(inplace=True)
df.drop('A_id', axis=1, inplace=True)

features = ['Size', 'Weight', 'Sweetness', 'Crunchiness', 'Juiciness', 'Ripeness', 'Acidity']
target = "Quality"

# Scale the features
scaler = StandardScaler()
df_scaled = df.copy()
df_scaled[features] = scaler.fit_transform(df_scaled[features])

X = df_scaled[features].values
y = df_scaled[target].values

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=1)

#def euclidean_distance(point1, point2):
#   return np.sqrt(np.sum((point1 - point2)**2))

def knn_predict(X_train, y_train, X_test, k, p=2, weight='uniform'):
    y_pred = []
    for test_point in X_test:
        distances = []
        for i, train_point in enumerate(X_train):
            if p == 1:  # Manhattan distance
                dist = np.sum(np.abs(test_point - train_point))
            else:  # Euclidean distance
                dist = np.sqrt(np.sum((test_point - train_point) ** 2))
            distances.append((dist, y_train[i]))
        if weight == 'distance':
            distances = sorted(distances)[:k]  # Sort distances and select top k
            weighted_labels = [(1 / (1e-10 + dist), label) for dist, label in distances]  # Weighted labels
            labels = [label for weight, label in weighted_labels]
            y_pred.append(max(set(labels), key=labels.count))  # Predict the label with weighted majority vote
        else:  # Uniform weight
            distances = sorted(distances)[:k]  # Sort distances and select top k
            labels = [label for _, label in distances]
            y_pred.append(max(set(labels), key=labels.count))  # Predict the label with majority vote
    return np.array(y_pred)

best_accuracy = 0
best_k = 0
best_p = 0
best_weight = ''

k_range = range(1, 3)
p_values = [1, 2]
weight_types = ['uniform', 'distance']

for k in k_range:
    for p in p_values:
        for weight in weight_types:
            y_pred = knn_predict(X_train, y_train, X_test, k, p=p, weight=weight)
            accuracy = accuracy_score(y_test, y_pred)
            if accuracy > best_accuracy:
                best_accuracy = accuracy
                best_k = k
                best_p = p
                best_weight = weight

precision = precision_score(y_test, y_pred)
recall = recall_score(y_test, y_pred)
f1 = f1_score(y_test, y_pred)

conf_matrix = confusion_matrix(y_test, y_pred)

print("Best Parameters:")
print("Best k:", best_k)
print("Best p:", best_p)
print("Best weight:", best_weight)
print("Best Accuracy:", best_accuracy)
print("Precision:", precision)
print("Recall:", recall)
print("F1 Score:", f1)
print("Confusion Matrix:")
print(conf_matrix)
