# -*- coding: utf-8 -*-
"""
Created on Mon Mar 2 09:37:08 2024

@author: Arun
"""

import numpy as np
from collections import Counter
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import StandardScaler
import pandas as pd
from sklearn.datasets import load_iris

iris = load_iris()
X, y = iris.data, iris.target


# df = pd.read_csv("C:/Users/arunc/Desktop/Programs/HRanalytics.csv")
# df['left'].value_counts()  # Ratio is 70 (not left) and 30 (left)
    
# label_encoder = LabelEncoder()
# df['Department'] = label_encoder.fit_transform(df['Department'])
# df['salary'] = df['salary'].replace({'low': 1, 'medium': 2, 'high':3})
    
    
# y = df['left']
# X_prev = df.drop(['left'], axis=1)
    
    
# scaler = StandardScaler()
# X = scaler.fit_transform(X_prev)


def euclidean_distance(x1, x2):
    return np.sqrt(np.sum((x1 - x2) ** 2))

def knn_predict(X_train, y_train, x, k):
    distances = [euclidean_distance(x, x_train) for x_train in X_train]
    sorted_indices = np.argsort(distances)[:k]  # Indices of the k-nearest neighbors

    neighbors_labels = [y_train[i] for i in sorted_indices]

    unique_labels, counts = np.unique(neighbors_labels, return_counts=True)

    prediction = unique_labels[np.argmax(counts)]

    return prediction


def parameter(X, y):
    best_accuracy = 0
    best_k = 0

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
    for k in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]:
        accuracy = calculate_accuracy(X_train, y_train, X_test, y_test, k)
        
        print(accuracy)
        if accuracy > best_accuracy:
            best_accuracy = accuracy
            best_k = k

    return best_k, best_accuracy

def calculate_accuracy(X_train, y_train, X_test, y_test, k):
    
    y_pred_val = np.array([knn_predict(X_train, y_train, x, k) for x in X_test])
    accuracy_test = np.mean(y_pred_val == y_test)
    return accuracy_test



best_k, best_accuracy = parameter(X, y)

print("Best K Value : ", best_k)
print("Best Accuracy: ", best_accuracy)

y_pred= np.array([knn_predict(X, y, x, best_k) for x in X])

accuracy_manual = np.mean(y_pred == y)

print("Accuracy:", accuracy_manual)
    