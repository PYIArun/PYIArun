#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Feb 10 11:56:36 2024

@author: baljeetkaur
"""

from sklearn.datasets import load_wine
winedata = load_wine()
X, y = winedata['data'], winedata['target']
print(X.shape)
print(y.shape)


from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)
gnb = GaussianNB()
model= gnb.fit(X_train, y_train)
y_pred=model.predict(X_test)

from sklearn.metrics import accuracy_score
accuracy_score(y_test, y_pred)





import matplotlib.pyplot as plt
plt.scatter(X[:,1], X[:,2], c=y)
plt.show()

"""
The class is first fit on a dataset by calling the fit() function, 
and then the original dataset or other data can be projected into a subspace with the chosen number of dimensions by calling the transform() function.

Once fit, the eigenvalues and principal components can be accessed on the PCA class via the explained_variance_ and components_ attributes.
"""
from sklearn.decomposition import PCA
pca = PCA()
Xt = pca.fit_transform(X)
plot = plt.scatter(Xt[:,0], Xt[:,1], c=y)
plt.legend(handles=plot.legend_elements()[0], labels=list(winedata['target_names']))
plt.show()



#after standard scaling
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
pca = PCA()
pipe = Pipeline([('scaler', StandardScaler()), ('pca', pca)])
Xt = pipe.fit_transform(X)
plot = plt.scatter(Xt[:,0], Xt[:,1], c=y)
plt.legend(handles=plot.legend_elements()[0], labels=list(winedata['target_names']))
plt.show()


#pick up few first columns as see accuracy
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
X_train, X_test, y_train, y_test = train_test_split(Xt[:,:3], y, test_size=0.2,random_state=0)
gnb = GaussianNB()
model= gnb.fit(X_train, y_train)
y_pred=model.predict(X_test)

from sklearn.metrics import accuracy_score
accuracy_score(y_test, y_pred)

print(pca.explained_variance_ratio_)

from sklearn.metrics import accuracy_score
accuracy_score(y_test, y_pred)
