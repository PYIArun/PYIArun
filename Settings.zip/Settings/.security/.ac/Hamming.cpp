#include <iostream>
#include <ctime>
using namespace std;

class Hamming{

    public:
    int n;
    int M[8];
    void sending();
    void communication();
    void receiving();

};

void Hamming::sending(){
    M[0] = 0; 
      
    cout<< "Enter any 4 data bits: ";
    cin>> M[7]; 
    cin>> M[6]; 
    cin>> M[5]; 
    cin>> M[3]; 


    M[1] = M[3] ^ M[5] ^ M[7];
    M[2] = M[3] ^ M[6] ^ M[7];
    M[4] = M[5] ^ M[6] ^ M[7];


    cout<< "Resultant Bits sending towards receiver: ";
    for(int i =7; i>=1; i--){
        cout<< M[i]<< " ";
    }
}

void Hamming:: communication(){
    int random[4]; // will take the random bit errors and assign it the main mssg
    
    //copyingelements
    random[0] = M[7];
    random[1] = M[6];
    random[2] = M[5];
    random[3] = M[3];

    srand(time(0));
    int n_error = rand() % 4;

    cout<<"\nNumber of error bits: ";
    cout<<n_error<<endl;

    int place=0;
    cout<<"Position of error bit: ";
    for(int i = 0; i < n_error; i++){
        place = rand()%4;
        cout<< place<< " ";
        random[place]==0 ? random[place]= 1 : random[place] =0;
    }

    //Assigning the random bit errors into the main data bits
    M[7]= random[0];
    M[6]= random[1];
    M[5]= random[2];
    M[3]= random[3];

    cout<<"\nMessage after errors bit: ";
    for(int i =7 ; i>=1 ;i--){
        cout<< M[i] << " ";
    }

}
void Hamming::receiving(){
    int c1, c2, c3;

    c1 = M[1] ^ M[3] ^ M[5] ^ M[7];
    c2 = M[2] ^ M[3] ^ M[6] ^ M[7];
    c3 = M[4] ^ M[5] ^ M[6] ^ M[7];
    
    cout<< endl;
    int p = c1*1 + c2*2 + c3*4; // binary to decimal conversion
    if(p==0){
        cout<< "No error detected.";
    }
    else{
        cout<< "There is an error that has been detected.";
        
    }
    
}
int main(){
    Hamming h;

    h.sending();
    h.communication();
    h.receiving();

    return 0;
}