% Base case: Merging an empty list with any list results in the second list
merge([], L, L).

% Merging a non-empty list with an empty list results in the first list
merge(L, [], L).

% Recursive rule: Merge two non-empty ordered lists
merge([X|Rest1], [Y|Rest2], [X|MergedRest]) :-
    X =< Y,
    merge(Rest1, [Y|Rest2], MergedRest).

merge([X|Rest1], [Y|Rest2], [Y|MergedRest]) :-
    X > Y,
    merge([X|Rest1], Rest2, MergedRest).
% Example usage:
% merge([1, 3, 5], [2, 4, 6], Result).
