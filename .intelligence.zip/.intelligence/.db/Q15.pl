% Base case: The maximum of an empty list is undefined
maxlist([], undefined).

% Base case: The maximum of a list with a single element is that element
maxlist([X], X).

% Recursive rule: The maximum of a list is the maximum of its head and
% the maximum of its tail
maxlist([Head|Tail], Max) :-
    maxlist(Tail, TailMax),
    (Head >= TailMax -> Max = Head ; Max = TailMax).
% Example usage:
% maxlist([5, 3, 8, 2, 7], M).
