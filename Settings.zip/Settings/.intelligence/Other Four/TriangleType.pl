is_triangle(Side1, Side2, Side3):-
    Side1 + Side2> Side3,
    Side1 + Side3> Side2,
    Side2 + Side3> Side1.


is_equilateral(Side1, Side2, Side3):-
    is_triangle(Side1, Side2,Side3),
    Side1 = Side2,
    Side2 = Side3,
    Side1 = Side3.


is_isosceles(S, S, S1):-
    is_triangle(S, S, S1).

is_isosceles(S, S2, S):-
    is_triangle(S, S2, S).

is_isosceles(S3, S, S):-
    is_triangle(S3, S, S).


is_scalene(S1, S2, S3):-
    is_triangle(S1, S2, S3),
    is_isosceles(S1, S2, S3).
