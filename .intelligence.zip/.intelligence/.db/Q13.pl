% Base case: An empty list has even length
evenlength([]).

% Recursive rule: A list has even length if its tail has odd length
evenlength([_|Tail]) :-
    oddlength(Tail).

% Base case: An empty list does not have odd length
oddlength([_]).

% Recursive rule: A list has odd length if its tail has even length
oddlength([_|Tail]) :-
    evenlength(Tail).
% Example usage:
% evenlength([1, 2, 3]).
% oddlength([1, 2, 3]).
