import pandas as pd
from sklearn.preprocessing import MinMaxScaler

df = pd.read_csv("C:/Users/hp/Desktop/Machine Learning/Mobile.csv")

X = df.drop('price_range',axis=1)
y = df['price_range']
scaler = MinMaxScaler((0,1))
X=scaler.fit_transform(X)

from sklearn.decomposition import TruncatedSVD
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score
gnb = GaussianNB()

result = []
for i in range(0,X.shape[1]):
    svd = TruncatedSVD(n_components = i+1)
    svd.fit(X)
    Xt = svd.transform(X)
    X_train, X_test, y_train, y_test = train_test_split(Xt, y, test_size=0.2,random_state=0)
    model= gnb.fit(X_train, y_train)
    y_pred=model.predict(X_test)
    test_accuracy = accuracy_score(y_test, y_pred) * 100
    print(f'Accuracy with k{i+1} : {test_accuracy}')
    result.append({'Features Count': i+1, 'Accuracy': '{:.2f}'.format(test_accuracy)})
    
df2 = pd.DataFrame(result)
print(df2) 
print(df2[df2['Accuracy']==max(df2['Accuracy'])].iloc[0,:])
excel_fp = 'AshishSah_3436.xlsx'
df2.to_excel(excel_fp, index=False)
print(f'Data Exported to {excel_fp}')
print()

from AshishSah_3436_pca import pca_bp
print("PCA Best Performace:")
print(pca_bp)
print()

from Mobile_Wrapper import wrapper_bp
print("Wrapper Method Best Performance:")
print(pca_bp)
print()

from AshishSah_3436 import FS_bp
print("Filter Feature Pearson Correlation Best Performace:")
print(FS_bp)
print()

from Ashish_sklearn import df2 as df_new
for x in range(1,len(df_new.columns)):
    cl = df_new.columns[x]
    print(f'{cl} Best Performance:')
    df4 = df_new.iloc[:,[0,x]]
    print(df4[df4[cl]==max(df4[cl])].iloc[0,:])
    print()
    


