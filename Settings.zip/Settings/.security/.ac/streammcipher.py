import random

def Crypt(string,key,encrypt=1):
    random.seed(key)
    # This must be *2 so a letter shifted beyond the end of the alphabet will loop back to the beginning
    alphabet = 2 * " AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz1234567890.;:,'?/|{}[]-=+_!@#$%^&*()<>`~"
    # I declare this in a variable so the program can work with a variable length alphabet
    lenalpha = int(len(alphabet)/2)
    if encrypt:
        # This will shift each letter up the alphabet by a pseudo-random amount based on the key
        return ''.join([alphabet[alphabet.index(string[p]) + lenalpha - int(lenalpha * random.random())] for p in range(len(string))])
    else:
        # This will shift each letter down the alphabet by a pseudo-random amount based on the key
        return ''.join([alphabet[alphabet.index(string[p]) - lenalpha + int(lenalpha * random.random())] for p in range(len(string))])

if __name__ == '__main__':
    message = input("Input your message: ")
    key = input("Input a key: ")
    finished_with_the_user = False
    while not finished_with_the_user:
        encrypt_question = input("Encrypt or decrypt a message?(1,0): ")
        if encrypt_question.isdigit():
            finished_with_the_user = True
            encrypt_question = int(encrypt_question)
        else:
            print("Please input a valid number.")
    print(Crypt(message, key, encrypt_question))
    input("Press enter to exit.")