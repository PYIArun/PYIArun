# -*- coding: utf-8 -*-
"""
Created on Wed Oct 13 22:36:49 2021

@author: BALJEET KAUR
"""

from sklearn import datasets
from sklearn import tree
from sklearn.pipeline import Pipeline
from sklearn.model_selection import GridSearchCV
from sklearn.preprocessing import StandardScaler

dataset = datasets.load_wine()
X = dataset.data
y = dataset.target


std_slc = StandardScaler()
dec_tree = tree.DecisionTreeClassifier()

pipe = Pipeline(steps=[('std_slc', std_slc),
                          ('dec_tree', dec_tree)])
 
criterion = ['gini', 'entropy']
max_depth = [2,4,6,8,10,12]
parameters = dict(dec_tree__criterion=criterion,
                      dec_tree__max_depth=max_depth)

clf_GS = GridSearchCV(pipe, parameters)
#clf_GS = GridSearchCV(dec_tree, parameters)

clf_GS.fit(X, y)
print('Best Criterion:', clf_GS.best_estimator_.get_params()['dec_tree__criterion'])
print('Best max_depth:', clf_GS.best_estimator_.get_params()['dec_tree__max_depth'])
print(); print(clf_GS.best_estimator_.get_params()['dec_tree'])

###


