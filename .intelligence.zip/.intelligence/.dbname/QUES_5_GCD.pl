% Q5. GCD of two numbers
gcd(X, X, X).

gcd(X, Y, D) :-
    X > Y,
    Y1 is X-Y,
    gcd(Y, Y1, D).

gcd(X, Y, D) :-
    Y > X,
    gcd(Y, X, D).

gcdOfTwoNums :-
    read_num("Enter the first number: ", N1),
    read_num("Enter the second number: ", N2),
    gcd(N1, N2, D),
    write("The GCD is: "),
    write(D).
% Defining basic functions

read_num(Prompt, N) :-
    write(Prompt),
    read(N).
