% Define edges in the graph
edge(a, b).
edge(b, c).
edge(c, d).
edge(b, e).
edge(e, f).
edge(f, g).

% Predicate to find a path between two nodes
path(X, Y) :-
    edge(X, Y). % Base case: There is a direct edge between X and Y

path(X, Y) :-
    edge(X, Z),  % Recursive case: There is an edge between X and some intermediate node Z
    path(Z, Y).  % Recur on Z to find a path from Z to Y

% Example query:
% ?- path(a, g).
% Output: true (there is a path from a to g: a -> b -> e -> f -> g)
