# -*- coding: utf-8 -*-
"""
Created on Fri Feb 23 11:26:41 2024


"""

from numpy import array
from numpy import diag
from numpy import zeros
from scipy.linalg import svd
from sklearn.datasets import load_digits
from numpy.linalg import svd
digits = load_digits()
# define a matrix
A =digits.data
print(A)
# Singular-value decomposition
U, s, VT = svd(A)
print(A.shape[1])
# create m x n Sigma matrix
Sigma = zeros((A.shape[0], A.shape[1]))
# populate Sigma with n x n diagonal matrix
Sigma[:A.shape[1], :A.shape[0]] = diag(s)
# select
n_elements = 10
Sigma = Sigma[:, :n_elements]
VT = VT[:n_elements, :]
# reconstruct
B = U.dot(Sigma.dot(VT))
print(B)
# transform
T = U.dot(Sigma)
print(T)
T1 = A.dot(VT.T)
print(T1)



from numpy import array
from sklearn.decomposition import TruncatedSVD
# define array
print(A)
# svd
svd = TruncatedSVD(n_components=10)
svd.fit(A)
result = svd.transform(A)
print(result)