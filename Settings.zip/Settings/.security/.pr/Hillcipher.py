import numpy as np

def hillcipher_encrypt(plaintext, key):
    n = int(len(key)**0.5)
    plaintext_l = []
    for char in plaintext:
        if char !=' ':
            plaintext_l.append(ord(char) - ord('A'))
    plaintext = np.array(plaintext_l)
    key_m = np.array([ord(char) - ord('A') for char in key])
    key_matrix = key_m.reshape(n,-1)
    print(key_matrix)
    # Padding the plaintext if its length is not a multiple of n
    if len(plaintext)%n != 0:
        padding = n - (len(plaintext)%n)
        plaintext = np.pad(plaintext, (0, padding), mode = 'constant')
    plaintext= plaintext.reshape((n,-1), order='F')
    ciphertext = (key_matrix @ plaintext) % 26
    ciphertext = ciphertext.T
    ciphertext = ciphertext.flatten()
    return ''.join([chr(char + ord('A')) for char in ciphertext])

def hillcipher_decrypt(ciphertext, key):
    n = int(len(key)**0.5)
    ciphertext = [ord(char) - ord('A') for char in ciphertext]
    ciphertext = np.array(ciphertext)
    key_m = np.array([ord(char) - ord('A') for char in key])
    key_matrix = key_m.reshape(n,-1)

    key_matrix_inv = np.linalg.inv(key_matrix)
    det = np.linalg.det(key_matrix)

    key_matrix_inv = np.round(key_matrix_inv * det).astype(int)%26
    det = np.round(det).astype(int)%26
    
    det_inv = pow(int(det),-1,26)
    key_matrix_inv = (det_inv * key_matrix_inv) % 26
    ciphertext= ciphertext.reshape((n,-1), order='F')
    print(key_matrix_inv)
    plaintext = (key_matrix_inv @ ciphertext) % 26
    plaintext = plaintext.T
    plaintext = plaintext.flatten()
    return ''.join([chr(char + ord('A')) for char in plaintext])

def main():
    while True:
        print("\nHill Cipher Menu:")
        print("1. Encrypt")
        print("2. Decrypt")
        print("3. Quit")

        choice = input("Enter your choice (1/2/3): ")

        if choice == '1':
            plaintext = input("Enter the plaintext: ").upper()
            key = input("Enter the key: ").upper()
            ciphertext = hillcipher_encrypt(plaintext, key)
            print("Encrypted Text:", ciphertext)

        elif choice == '2':
            ciphertext = input("Enter the ciphertext: ").upper()
            key = input("Enter the key: ").upper()
            plaintext = hillcipher_decrypt(ciphertext, key)
            print("Decrypted Text:", plaintext)

        elif choice == '3':
            print("Exiting the program.")
            break

        else:
            print("Invalid choice. Please enter 1, 2, or 3.")

if __name__ == "__main__":
    main()