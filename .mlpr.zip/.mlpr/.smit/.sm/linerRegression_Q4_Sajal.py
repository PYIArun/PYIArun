# -*- coding: utf-8 -*-
"""
Created on Thu Mar 14 12:28:45 2024

@author: hp
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib.pyplot as plt

# Load the dataset
studentdata = pd.read_csv("C:/Users/hp/Desktop/3432/ML/Student_Performance.csv")

# Map "Extracurricular Activities" feature to 0 and 1
activity_mapping = {'Yes': 1, 'No': 0}
studentdata['Extracurricular Activities'] = studentdata['Extracurricular Activities'].map(activity_mapping)

X = studentdata.drop('Performance Index', axis = 1)
y = studentdata['Performance Index']

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Define polynomial degrees to try
degrees = range(1,10)


# Initialize lists to store results
train_mse = []
test_mse = []
train_r2 = []
test_r2 = []

# Loop through each degree
for degree in degrees:
    # Transform features to polynomial features
    poly = PolynomialFeatures(degree=degree)
    X_train_poly = poly.fit_transform(X_train)
    X_test_poly = poly.transform(X_test)
    
    # Fit linear regression model
    model = LinearRegression()
    model.fit(X_train_poly, y_train)
    
    # Predict on training and testing set
    y_train_pred = model.predict(X_train_poly)
    y_test_pred = model.predict(X_test_poly)
    
    # Calculate mean squared error and R2 score
    train_mse.append(mean_squared_error(y_train, y_train_pred))
    test_mse.append(mean_squared_error(y_test, y_test_pred))
    train_r2.append(r2_score(y_train, y_train_pred))
    test_r2.append(r2_score(y_test, y_test_pred))

# Create a dataframe to store results
results_df = pd.DataFrame({
    'Degree': degrees,
    'Train MSE': train_mse,
    'Test MSE': test_mse,
    'Train R2': train_r2,
    'Test R2': test_r2
})

# Print the results
print(results_df)

# Plot the training and testing errors
plt.figure(figsize=(10, 6))
plt.plot(degrees, train_mse, label='Train MSE', marker='o')
plt.plot(degrees, test_mse, label='Test MSE', marker='o')
plt.xlabel('Polynomial Degree')
plt.ylabel('Mean Squared Error')
plt.title('Training and Testing Error vs. Polynomial Degree')
plt.legend()
plt.grid(True)
plt.show()

# Discuss the best model
best_model_index = np.argmin(test_mse)
best_degree = degrees[best_model_index]
print(f"\nThe best model is the one with degree {best_degree}, with a test MSE of {test_mse[best_model_index]}.")

