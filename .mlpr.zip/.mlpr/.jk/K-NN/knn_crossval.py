# -*- coding: utf-8 -*-
"""
Created on Tue Feb 27 09:47:13 2024

@author: kaush
"""

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import cross_val_score
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.neighbors import KNeighborsClassifier

# Read the dataset
df = pd.read_csv('apple_quality.csv')

label_encoder = LabelEncoder()
df['Quality'] = label_encoder.fit_transform(df['Quality'])

df.dropna(inplace=True)
df.drop('A_id', axis=1, inplace=True)

features = ['Size', 'Weight', 'Sweetness', 'Crunchiness', 'Juiciness', 'Ripeness', 'Acidity']
target = "Quality"

# Scale the features
scaler = StandardScaler()
df_scaled = df.copy()
df_scaled[features] = scaler.fit_transform(df_scaled[features])

X = df_scaled[features]
y = df_scaled[target]

# Initialize KNN classifier
knn = KNeighborsClassifier(n_neighbors= 6)

# Perform cross-validation
cv_scores = cross_val_score(knn, X, y, cv=5, scoring='accuracy')

# Calculate mean accuracy
mean_accuracy = cv_scores.mean()

# Print mean accuracy
print("Mean Accuracy:", mean_accuracy)
