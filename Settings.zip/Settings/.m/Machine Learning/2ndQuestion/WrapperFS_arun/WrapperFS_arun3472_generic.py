# -*- coding: utf-8 -*-
"""
Created on Fri Feb 8 6:47:03 2024

@author: Arun
"""

import numpy as np
import pandas as pd
from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.datasets import load_iris

X, y = load_iris(return_X_y=True)

df = pd.DataFrame(X)

starting_features = df.columns.tolist()
best_features = []
best_accuracy = 0.0
round_results = []

for i in range(len(starting_features)):
    accuracies = []
    
    for column in starting_features:
        selected_features = best_features + [column]
        X_subset = df[selected_features]

        gnb = GaussianNB()
        X_train, X_test, y_train, y_test = train_test_split(X_subset, y, stratify=y, test_size=0.3, random_state=3)
        gnb.fit(X_train, y_train)
        y_pred = gnb.predict(X_test)
        accuracy = accuracy_score(y_test, y_pred)
        accuracies.append(accuracy)
        
    max_feature_1 = np.argmax(accuracies)
    best_features = best_features + [starting_features[max_feature_1]]  
    best_accuracy = max(accuracies)

    round_results.append({
        'Round': len(best_features),
        'Selected Features': best_features,
        'Accuracy': best_accuracy
    })

    starting_features.pop(max_feature_1)  
    
    if best_accuracy == 1.0:
        break

selected_features_table = pd.DataFrame(round_results)
print(selected_features_table)

selected_features_table.to_excel("C:/Users/arunc/Desktop/Programs/Machine Learning/2ndQuestion/WrapperFS_arun/wrapperFSresults.xlsx", index=False, engine='xlsxwriter')


