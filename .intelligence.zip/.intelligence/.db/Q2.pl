% Base case: M is the maximum of X and Y when X is greater than or equal to Y
max(X, Y, M) :-
    X >= Y,
    M is X.

% M is the maximum of X and Y when Y is greater than X
max(X, Y, M) :-
    X < Y,
    M is Y.
% Example usage:
% max(3, 7, Result).
