# -*- coding: utf-8 -*-
"""
Created on Tue Apr 16 10:09:08 2024

@author: 
"""

# SVM program to classify data

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import scipy.optimize as opt
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
from scipy import stats

from sklearn.datasets import make_blobs
# use seaborn plotting defaults
import seaborn as sns; sns.set()

data=pd.read_csv("C:/Users/91931/Desktop/MLprograms/loistic_regression/diabetes.csv")
x = data.iloc[:,:-1]
y = data.iloc[:,8]
                          
Scaler=StandardScaler()
x_scaled=Scaler.fit_transform(x)

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x_scaled, y, test_size=0.25, random_state=0)

# SVM for multi-class classification using built-in one-vs-one
from sklearn.datasets import make_classification
from sklearn.svm import SVC
# define dataset
#X, y = make_classification(n_samples=1000, n_features=10, n_informative=5, n_redundant=5, n_classes=3, random_state=1)
# define model
model = SVC(kernel='linear')
# fit model
model.fit(x_train, y_train)
# make predictions
yhat = model.predict(x_test)

scr = model.score(x_test,y_test)
print(scr)

