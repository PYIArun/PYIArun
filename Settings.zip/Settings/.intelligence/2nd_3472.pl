side(a,t1).
side(b,t1).
side(c,t1).

equilateral:-
    side(a,t1),
    side(b,t1),
    side(c,t1),
    side(a,t1) = side(b,t1),
    side(b,t1) = side(c,t1),
    side(a,t1) = side(c,t1).
