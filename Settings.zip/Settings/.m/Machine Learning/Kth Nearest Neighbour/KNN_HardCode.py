# -*- coding: utf-8 -*-
"""
Created on Fri Mar  1 12:04:57 2024

@author: Arun
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import StandardScaler
from scipy.stats import mode

df = pd.read_csv("C:/Users/arunc/Desktop/Programs/HRanalytics.csv")
df['left'].value_counts()  # Ratio is 70 (not left) and 30 (left)
    
label_encoder = LabelEncoder()
df['Department'] = label_encoder.fit_transform(df['Department'])
df['salary'] = df['salary'].replace({'low': 1, 'medium': 2, 'high':3})
    
    
y = df['left']
X_prev = df.drop(['left'], axis=1)
    
    
scaler = StandardScaler()
X = scaler.fit_transform(X_prev)


def euclidean_distance(point1, point2):
    return np.sqrt(np.sum((point1 - point2) ** 2))

def knn_predict(X_train, y_train, x, k):
    distances = [euclidean_distance(x, x_train) for x_train in X_train]
    sorted_indices = np.argsort(distances)[:k]

    # Additional checks
    if len(y_train) == 0:
        raise ValueError("y_train is empty.")
    
    if np.max(sorted_indices) >= len(y_train):
        raise ValueError("Invalid indices in sorted_indices.")

    # Use Counter for classification (assuming binary classification)
    neighbors_labels = y_train[sorted_indices]
    print("sorted_indices:", sorted_indices)  # Print the indices for debugging
    print("neighbors_labels:", neighbors_labels)  # Print the labels for debugging
    
    prediction = mode(neighbors_labels).mode[0]

    return prediction



def hyperparameter_search(X, y):
    best_accuracy = 0
    best_k = 0

    for k in [3, 4, 5, 6, 7, 8, 9, 10]:
        accuracy = cross_val_accuracy(X, y, k)
                
        if accuracy > best_accuracy:
            best_accuracy = accuracy
            best_k = k

    return best_k, best_accuracy


def cross_val_accuracy(X, y, k):
    accuracies = []

    for i in range(5): 
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=None)

        y_pred_val = np.array([knn_predict(X_train, y_train, x, k) for x in X_test])

        accuracy_val = np.mean(y_pred_val == y_test)
        accuracies.append(accuracy_val)

    average_accuracy = np.mean(accuracies)
    return average_accuracy


def main():
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=None)
    
    best_k, best_accuracy = hyperparameter_search(X_train, y_train)

    print("Best K Value : ", best_k)
    print("Best Cross Validation Accuracy : ", best_accuracy)

    y_pred_manual = np.array([knn_predict(X_train, y_train, x, best_k) for x in X_test])

    accuracy = np.mean(y_pred_manual == y_test)
    precision = np.sum((y_pred_manual == 1) & (y_test == 1)) / np.sum(y_pred_manual == 1)
    recall = np.sum((y_pred_manual == 1) & (y_test == 1)) / np.sum(y_test == 1)
    f1 = 2 * (precision * recall) / (precision + recall)

    print("Accuracy:", accuracy)
    print("Precision:", precision)
    print("Recall:", recall)
    print("F1 Score:", f1)

if __name__ == "__main__":
    main()

