    # -*- coding: utf-8 -*-
"""
Created on Tue Apr 16 09:51:03 2024

@author: Arun
"""

from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import accuracy_score, classification_report, r2_score
import numpy as np
import pandas as pd
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler

df = pd.read_csv("C:/Users/arunc/Desktop/Programs/banana_quality.csv")
df['Quality'].value_counts() # Ratio is 70 (not left) and 30 (left)
# print(df.head())

label_encoder = LabelEncoder()
df['Quality'] = label_encoder.fit_transform(df['Quality'])

y = df['Quality']
X_prev = df.drop(['Quality'], axis=1)

scaler = StandardScaler()
X = scaler.fit_transform(X_prev)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

svm = SVC()     

param_grid = {
    'kernel': ['linear', 'poly', 'rbf', 'sigmoid'],
    'C': [0.01, 0.1, 1, 10, 30, 50, 100, 1000],
    'gamma': [0.1, 0.125, 10]
}

grid_search = GridSearchCV(estimator=svm, param_grid=param_grid, cv=5, scoring='accuracy', n_jobs=-1)
grid_search.fit(X_train, y_train)

best_params = grid_search.best_params_

print("Best Parameters : ", best_params)
print()
best_svm = SVC(**best_params)
best_svm.fit(X_train, y_train)

y_pred = best_svm.predict(X_test)

accuracy = accuracy_score(y_test, y_pred)
print("Accuracy:", accuracy)

print("Classification Report:")
print(classification_report(y_test, y_pred))

r2 = r2_score(y_test, y_pred)
print("R2 Score:", r2)
