% Triangle or not
is_triangle(Side1, Side2, Side3) :-
    Side1 + Side2 > Side3,
    Side1 + Side3 > Side2,
    Side2 + Side3 > Side1.

% A triangle is equilateral
is_equilateral(Side1, Side2, Side3) :-
    is_triangle(Side1, Side2, Side3),
    Side1 =:= Side2,
    Side2 =:= Side3.

is_iso(Side1, Side2, Side3) :-
    is_triangle(Side1, Side2, Side3),
    (   Side1 =:= Side2; Side2 =:= Side3; Side3 =:= Side1).



