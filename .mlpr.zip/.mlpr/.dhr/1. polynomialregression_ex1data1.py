# -*- coding: utf-8 -*-
"""
Created on Sat Oct 12 15:44:25 2019

@author: BALJEET
"""

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

data = pd.read_csv('ex1data1.txt', header = None) #read from dataset
x = data.iloc[:,0].values.reshape(-1,1) # read first two column
y = data.iloc[:,1].values.reshape(-1,1) # read target column




#linear regression
model = LinearRegression()
model.fit(x, y)
y_pred = model.predict(x)

rmse = mean_squared_error(y, y_pred)
r2 = r2_score(y, y_pred)

print('Root mean squared error: ', rmse)
print('R2 score: ', r2)

plt.scatter(x, y, s=10)
plt.plot(x, y_pred, color='r')
plt.show()

#polynomial fit
from sklearn.preprocessing import PolynomialFeatures
polynomial_features= PolynomialFeatures(degree=2)

x_poly = polynomial_features.fit_transform(x)

model = LinearRegression()
model.fit(x_poly, y)
y_poly_pred = model.predict(x_poly)

rmse = (mean_squared_error(y,y_poly_pred))
r2 = r2_score(y,y_poly_pred)
print('Root mean squared error: ', rmse)
print('R2 score: ', r2)


plt.scatter(x, y, s=10)
# sort the values of x before line plot
#sort as per this method 
z=np.hstack((x,y_poly_pred))
a = z[z[:,0].argsort()]
plt.plot(a[:,0], a[:,1], color='r')

plt.show()

#degree 3,4,510,20 etc

polynomial_features= PolynomialFeatures(degree=3)

x_poly = polynomial_features.fit_transform(x)

model = LinearRegression()
model.fit(x_poly, y)
y_poly_pred = model.predict(x_poly)

rmse = mean_squared_error(y,y_poly_pred)
r2 = r2_score(y,y_poly_pred)
print('Root mean squared error: ', rmse)
print('R2 score: ', r2)


plt.scatter(x, y, s=10)


z=np.hstack((x,y_poly_pred))
a = z[z[:,0].argsort()]
plt.plot(a[:,0], a[:,1], color='m')

plt.show()


polynomial_features= PolynomialFeatures(degree=4)

x_poly = polynomial_features.fit_transform(x)

model = LinearRegression()
model.fit(x_poly, y)
y_poly_pred = model.predict(x_poly)

rmse = np.sqrt(mean_squared_error(y,y_poly_pred))
r2 = r2_score(y,y_poly_pred)
print('Root mean squared error: ', rmse)
print('R2 score: ', r2)


plt.scatter(x, y, s=10)


z=np.hstack((x,y_poly_pred))
a = z[z[:,0].argsort()]
plt.plot(a[:,0], a[:,1], color='m')

plt.show()


polynomial_features= PolynomialFeatures(degree=10)

x_poly = polynomial_features.fit_transform(x)

model = LinearRegression()
model.fit(x_poly, y)
y_poly_pred = model.predict(x_poly)

rmse = np.sqrt(mean_squared_error(y,y_poly_pred))
r2 = r2_score(y,y_poly_pred)
print('Root mean squared error: ', rmse)
print('R2 score: ', r2)


plt.scatter(x, y, s=10)


z=np.hstack((x,y_poly_pred))
a = z[z[:,0].argsort()]
plt.plot(a[:,0], a[:,1], color='m')

plt.show()

