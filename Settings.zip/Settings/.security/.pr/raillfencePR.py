def sequence(n):
    arr = []
    i = 0

    while(i<n-1):
        arr.append(i)
        i += 1

    while(i>0):
        arr.append(i)
        i -=1

    return (arr)


def encrypt(s, n):
    s = s.lower()
    s = s.replace(" ", "")
    L = sequence(n)
    temp =  L

    while (len(s) > len(L)):
        L = L + temp
    
    for i in range(len(L) - len(s)):
        L.pop()

    print("The transformed mssg for encryption is : ", s)


    num = 0

    ciphertext = ""
    while(num<n):
        for i in range(L.count(num)):
            ciphertext = ciphertext + s[L.index(num)]
            L[L.index(num)] = n
        num +=1
    print("The cipher text is : ", ciphertext)

def decrypt(ciphertext, n):
    ciphertext = ciphertext.lower()
    L = sequence(n)
    temp = L
    
    while (len(ciphertext) - len(L)):
        L = L + temp

    for i in range(len(L)-len(ciphertext)):
        L.pop()


    temp1 = sorted(L)


    plaintext = ""
    for i in L:
        k  = temp1.index(i)
        temp1[k] = n
        plaintext += ciphertext[k]


    print("The plain text is : ", plaintext)




plaintext = input("Enter the string to be encrypted: ")
n = int(input("Enter the depth: "))
encrypt(plaintext, n)


ciphertext = input("Enter the string to be decrypted; ")
n = int(input("Enter the depth: "))
decrypt(ciphertext, n)