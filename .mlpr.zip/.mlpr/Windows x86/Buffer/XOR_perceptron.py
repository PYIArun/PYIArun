# -*- coding: utf-8 -*-
"""
Created on Fri Apr  5 10:47:16 2024


"""

# importing the MLP classifier from sklearn
from sklearn.neural_network import MLPClassifier
import numpy as np
from sklearn.metrics import accuracy_score

xs = np.array([
    0, 0,
    0, 1,
    1, 0,
    1, 1
]).reshape(4, 2)

ys = np.array([0, 1, 1, 0]).reshape(4,)

model = MLPClassifier(
    activation='relu', max_iter=3000, hidden_layer_sizes=(4,7))
model.fit(xs, ys)

#model = MLPClassifier(
#    activation='relu', max_iter=20000, hidden_layer_sizes=(4,2))
#model.fit(xs, ys)

print('score:', model.score(xs, ys)) # outputs 0.5
print('predictions:', model.predict(xs)) # outputs [0, 0, 0, 0]
print('expected:', np.array([0, 1, 1, 0]))
