# -*- coding: utf-8 -*-
"""
Created on Mon Jul  6 19:56:05 2020

@author: BALJEET KAUR
"""

import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.datasets import make_blobs
data=make_blobs(n_samples=200,n_features=2,centers=4,cluster_std=1.8,random_state=101)
data[0].shape
plt.scatter(data[0][:,0],data[0][:,1])
plt.scatter(data[0][:,0],data[0][:,1],c=data[1])
plt.scatter(data[0][:,0],data[0][:,1],c=data[1],cmap='rainbow')


from sklearn.cluster import KMeans
kmeans=KMeans(n_clusters=4)
kmeans.fit(data[0])
#kmeans.cluster_centers_
kmeans.labels_

plt.scatter(data[0][:,0],data[0][:,1],c=kmeans.labels_ ,cmap='rainbow')


#3 clusters
kmeans=KMeans(n_clusters=3)
kmeans.fit(data[0])

plt.scatter(data[0][:,0],data[0][:,1],c=kmeans.labels_ ,cmap='rainbow')

#2 clusters
kmeans=KMeans(n_clusters=2)
kmeans.fit(data[0])

plt.scatter(data[0][:,0],data[0][:,1],c=kmeans.labels_ ,cmap='rainbow')

#5 clusters


kmeans=KMeans(n_clusters=5)
kmeans.fit(data[0])

plt.scatter(data[0][:,0],data[0][:,1],c=kmeans.labels_ ,cmap='rainbow')
