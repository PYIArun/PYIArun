# -*- coding: utf-8 -*-
"""
Created on Mon Mar 18 09:06:45 2024

@author: kripl
"""

import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

import csv

input_file = "data.csv"
output_file = "output.csv"


with open(input_file, 'r') as csvfile:
    reader = csv.reader(csvfile, delimiter=';')
    data = list(reader)

column_names = data[0]
column_names = [name.replace('"', '') for name in column_names]


with open(output_file, 'w', newline='') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(column_names)  # Write columnX = names
    for row in data[1:]:
        writer.writerow(row)
        
new_data = pd.read_csv('output.csv')
new_data.columns
new_data.head()
le = LabelEncoder()
new_data['Target'] = le.fit_transform(new_data['Target'])
y = new_data['Target']
X = new_data.drop("Target",axis=1)

model = LogisticRegression(multi_class='ovr')
model.fit(X, y)
yhat = model.predict(X)

from sklearn.svm import SVC
from sklearn.multiclass import OneVsOneClassifier

model = SVC()

ovo = OneVsOneClassifier(model)

ovo.fit(X, y)

yhat = ovo.predict(X)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = LogisticRegression(multi_class='ovr')
model.fit(X_train,y_train)
yhat = model.predict(X_test)

score = model.score(X_test,y_test)
print(score)

