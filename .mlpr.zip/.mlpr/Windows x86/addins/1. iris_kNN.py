# -*- coding: utf-8 -*-
"""
Created on Mon Jul  6 18:04:26 2020

@author: BALJEET KAUR
"""

from sklearn import datasets


iris= datasets.load_iris()
x=iris.data
iris.feature_names
y=iris.target
iris.target_names
iris.data.shape

from sklearn.neighbors import KNeighborsClassifier
from sklearn import metrics

#knn=KNeighborsClassifier(n_neighbors=2,weights='distance')
knn=KNeighborsClassifier(n_neighbors=2)

#knn=KNeighborsClassifier(n_neighbors=5)   #5 2 1
knn.fit(x,y)
y_predict=knn.predict(x)

score=metrics.accuracy_score(y, y_predict)
print(score)
print(metrics.confusion_matrix(y, y_predict))

#knn=KNeighborsClassifier(n_neighbors=2,weights='distance')
#print(metrics.classification_report(y, y_predict))

k_range=range(3,10)
score_list=[]
for i in k_range:
    knn=KNeighborsClassifier(n_neighbors=i)
    knn.fit(x,y)
    y_predict=knn.predict(x)
    score_list.append(metrics.accuracy_score(y, y_predict))
    
    
import matplotlib.pyplot as plt
plt.plot(k_range,score_list)
plt.xlabel('values for k')
plt.ylabel ('score')   
plt.show()


