% multiplication of two numbers
% Base case: multiply any number with 0 gives 0.
multi(_,0,0).

% Recursive case: multiply N1 with N2-1 N and add the result to N1.
multi(N1, N2, R) :-
    N2>0,
    N3 = N2-1,
    multi(N1,N3,R1),
    R is N1+R1.
% Example usage:
% multi(3, 4, Result).
