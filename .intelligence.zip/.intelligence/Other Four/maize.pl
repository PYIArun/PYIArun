way(a, b).
way(b, c).
way(c, d).
way(e, f).

edge(X, Y):-
 way(X, Y);
 way(Y, X).

cango(X, Y):-
 edge(X, Y);
 edge(X, Z), cango(Z, Y).

triangle(X, Y, Z):-
 edge(X, Y), edge(Y, Z), edge(Z, X).

