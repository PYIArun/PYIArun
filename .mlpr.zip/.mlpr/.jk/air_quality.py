# -*- coding: utf-8 -*-
"""
Created on Mon Feb  5 09:53:14 2024

@author: kaush
"""

pip install ucimlrepo

from ucimlrepo import fetch_ucirepo 
  
# fetch dataset 
optical_recognition_of_handwritten_digits = fetch_ucirepo(id=80) 
  
# data (as pandas dataframes) 
X = optical_recognition_of_handwritten_digits.data.features 
y = optical_recognition_of_handwritten_digits.data.targets 
  
# metadata 
print(optical_recognition_of_handwritten_digits.metadata) 
  
# variable information 
print(optical_recognition_of_handwritten_digits.variables) 

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.naive_bayes import GaussianNB
# from sklearn.naive_bayes import CategoricalNB
# from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix

from sklearn.datasets import load_wine




df=pd.DataFrame(X)
df.info()
rows, columns= df.shape
df.describe()
print(df.isnull().sum())

class_counts = pd.Series(y).value_counts()
print("Total number of wines in each class:")
print(class_counts)

X_train, X_test, y_train, y_test= train_test_split(X, y, stratify=y, random_state=6)
gnb= GaussianNB()
model= gnb.fit(X_train, y_train)


y_pred=model.predict(X_test)
print("Number of mislabeled points out of a total %d points : %d"
      % (X_test.shape[0], (y_test != y_pred).sum()))


print(accuracy_score(y_test, y_pred))
print(confusion_matrix(y_test, y_pred))


# Splitting the data 10 times 

print('PART 2')

num_splits = 10
accuracies = []

for i in range(num_splits):
    X_train, X_test, y_train, y_test = train_test_split(X, y, stratify=y)
    gnb = GaussianNB()
    model = gnb.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    
    accuracy = accuracy_score(y_test, y_pred)
    accuracies.append(accuracy)
    
    print(f"Accuracy for split {i + 1}: {accuracy}")
    print("Confusion Matrix:")
    print(confusion_matrix(y_test, y_pred))
    print("-" * 40)

average_accuracy = np.mean(accuracies)
print(f"\nAverage Accuracy over {num_splits} splits: {average_accuracy}")



