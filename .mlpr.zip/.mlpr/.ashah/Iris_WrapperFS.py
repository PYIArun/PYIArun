# Naive Bayes theorem Implementation
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.datasets import load_iris
from sklearn.metrics import accuracy_score
import pandas as pd

# seperate features(X) and target variable(y)
iris = load_iris()
X = iris.data
y = iris.target
X = pd.DataFrame(X)
y = pd.DataFrame(y)
col = iris.feature_names
col = pd.DataFrame(col)

gnb = GaussianNB()
result=[]
n=0
while n<=x_train.shape[1]:
    for i in range(x_train.shape[1]-n):
        current_feature_indices = []
        ctr=i
        while len(current_feature_indices)<=n:
            current_feature_indices = current_feature_indices + [ctr]
            ctr=ctr+1
        gnb.fit(x_train.loc[:,current_feature_indices],y_train)
        y_test_hat = gnb.predict(x_test.loc[:,current_feature_indices])
        accuracy= accuracy_score(y_test,y_test_hat)*100
        result.append({'Indices' : [col.loc[current_feature_indices,0]], 'Accuracy': '{:.2f}'.format(accuracy)})
    n=n+1
df2 = pd.DataFrame(result)
print(df2) 
excel_fp = 'Iris_Wrapper.xlsx'
df2.to_excel(excel_fp, index=False)
print(f'Data Exported to {excel_fp}')