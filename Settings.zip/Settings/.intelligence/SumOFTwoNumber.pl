%Write a prolog program to calculate the sum of two numbers.

sum(X, Y, Result) :-
    Result is X+Y.

