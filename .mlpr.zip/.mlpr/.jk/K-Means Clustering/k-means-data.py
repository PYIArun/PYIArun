# -*- coding: utf-8 -*-
"""
Created on Fri May  3 11:09:07 2024

@author: kaush
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler, LabelEncoder


def euclidean_distance(a, b):
    return np.sqrt(np.sum((a - b)**2))

def k_means_clustering(data, k, max_iterations=100):
    centroids = data[np.random.choice(len(data), k, replace=False)]

    for _ in range(max_iterations):
        clusters = [[] for _ in range(k)]
        for point in data:
            distances = [euclidean_distance(point, centroid) for centroid in centroids]
            cluster_index = np.argmin(distances)
            clusters[cluster_index].append(point)

        new_centroids = []
        for cluster in clusters:
            new_centroid = np.mean(cluster, axis=0)
            new_centroids.append(new_centroid)
        new_centroids = np.array(new_centroids)

        if np.allclose(centroids, new_centroids):
            break

        centroids = new_centroids

    return centroids, clusters

# Load the dataset

#prkd=pd.read_csv('parkinsons.data',sep=',')
#prkd.isna().sum()

#X_old=prkd.drop(['status','name'],axis=1)
#y_old=prkd['status']


df = pd.read_csv("parkinsons.data")

# Select two columns for clustering
X = df[['MDVP:Flo(Hz)', 'MDVP:Jitter(Abs)']].values

scaler = StandardScaler()
X = scaler.fit_transform(X)
# Select target column
target = df['status'].values

# Number of clusters
k_values = [2, 3, 4, 5]

# Perform k-means clustering for each value of k
for k in k_values:
    centroids, clusters = k_means_clustering(X, k)
    print(f"Number of clusters: {k}")
    print("Centroids:")
    print(centroids)

    # Plot the clusters
    plt.figure(figsize=(12, 5))

    plt.subplot(1, 2, 1)
    plt.title(f"K-Means Clustering (k={k})")
    colors = ['r', 'g', 'b', 'y', 'c', 'm']
    for i, cluster in enumerate(clusters):
        cluster = np.array(cluster)
        plt.scatter(cluster[:, 0], cluster[:, 1], c=colors[i], label=f'Cluster {i+1}')
    plt.scatter(centroids[:, 0], centroids[:, 1], marker='x', c='black', label='Centroids')
    plt.xlabel('MDVP:Flo(Hz)')
    plt.ylabel('MDVP:Jitter(Abs)')
    plt.legend()

    plt.subplot(1, 2, 2)
    plt.title("Scatter Plot for Target Column")
    plt.scatter(X[:, 0], X[:, 1], c=target, cmap='viridis')
    plt.xlabel('MDVP:Flo(Hz)')
    plt.ylabel('MDVP:Jitter(Abs)')
    plt.colorbar(label='status')
    
    plt.tight_layout()
    plt.show()
