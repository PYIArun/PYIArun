% Q.1
sum :-
    write('Enter first number: '),
    read(X),
    write('Enter second number: '),
    read(Y),
    S is X + Y,
    write('Sum is: '),
    write(S).

% Q.2
max :-
    write('Enter first number: '),
    read(X),
    write('Enter second number: '),
    read(Y),
    max(X, Y, M),
    write('Maximum is: '),
    write(M),
    nl.

max(X, Y, M) :-
    (   X >= Y
    ->  M is X
    ;   M is Y
    ).

% Q.3
factorial :-
    write('Enter a number: '),
    read(N),
    factorial(N, F),
    write('Factorial is: '),
    write(F),
    nl.

factorial(N, F) :-
    (   N =:= 0
    ->  F is 1
    ;   N > 0,
        N1 is N - 1,
        factorial(N1, F1),
        F is N * F1
    ).

% Q.4
generate_fib :-
    write('Enter the term number: '),
    read(N),
    generate_fib(N, T),
    write('The '), write(N), write('th term of Fibonacci series is: '), write(T),
    nl.

generate_fib(0, 0) :- !.
generate_fib(1, 1) :- !.
generate_fib(N, T) :-
    N > 1,
    N1 is N - 1,
    N2 is N - 2,
    generate_fib(N1, T1),
    generate_fib(N2, T2),
    T is T1 + T2.

% Q.5
gcd :-
    write('Enter first number: '),
    read(X),
    write('Enter second number: '),
    read(Y),
    gcd(X, Y, GCD),
    write('GCD is: '),
    write(GCD),
    nl.

gcd(X, 0, X) :- !.
gcd(X, Y, GCD) :-
    Z is X mod Y,
    gcd(Y, Z, GCD).

% Q.6
power :-
    write('Enter a number: '),
    read(Num),
    write('Enter the power: '),
    read(Pow),
    power(Num, Pow, Ans),
    write('Result is: '),
    write(Ans),
    nl.

power(_, 0, 1) :- !.
power(Num, Pow, Ans) :-
    Pow > 0,
    Pow1 is Pow - 1,
    power(Num, Pow1, Ans1),
    Ans is Ans1 * Num.

% Q.7
multi :-
    write('Enter first number: '),
    read(N1),
    write('Enter second number: '),
    read(N2),
    multi(N1, N2, R),
    write('Result is: '),
    write(R),
    nl.

multi(_, 0, 0) :- !.
multi(N1, N2, R) :-
    N2 > 0,
    N3 is N2 - 1,
    multi(N1, N3, R1),
    R is R1 + N1.

% Q.8
memb :-
    write('Enter element to check: '),
    read(X),
    write('Enter list: '),
    read(L),
    (   memb(X, L)
    ->  write('Yes, it is a member.')
    ;   write('No, it is not a member.')
    ).

% Q.9
conc :-
    write('Enter first list: '),
    read(L1),
    write('Enter second list: '),
    read(L2),
    conc(L1, L2, L3),
    write('Resultant list is: '),
    write(L3),
    nl.

% Q.10
reverse :-
    write('Enter a list: '),
    read(L),
    reverse(L, R),
    write('Reversed list is: '),
    write(R),
    nl.

reverse([], []).
reverse([H|T], R) :- reverse(T, RT), conc(RT, [H], R).

% Q.11
palindrome :-
    write('Enter a list: '),
    read(L),
    (   palindrome(L)
    ->  write('Yes, it is a palindrome.')
    ;   write('No, it is not a palindrome.')
    ).

palindrome(L) :-
    reverse(L, L).

% Q.12
sumlist :-
    write('Enter a list: '),
    read(L),
    sumlist(L, S),
    write('Sum of the list is: '), write(S),
    nl.

sumlist([], 0).
sumlist([H|T], S) :-
    sumlist(T, S1),
    S is S1 + H.

% Q.13
evenlength :-
    write('Enter a list: '),
    read(L),
    (   evenlength(L)
    ->  write('Yes, it has even length.')
    ;   write('No, it does not have even length.')
    ).

evenlength([]).
evenlength([_|T]) :- oddlength(T).

oddlength([_]).
oddlength([_|T]) :- evenlength(T).

% Q.14
nth_element :-
    write('Enter the position: '),
    read(N),
    write('Enter a list: '),
    read(L),
    nth_element(N, L, X),
    write('The '), write(N), write('th element of the list is: '), write(X),
    nl.

nth_element(1, [X|_], X) :- !.
nth_element(N, [_|T], X) :-
    N > 1,
    N1 is N - 1,
    nth_element(N1, T, X).

% Q.15
maxlist :-
    write('Enter a list: '),
    read(L),
    maxlist(L, M),
    write('Maximum number in the list is: '), write(M),
    nl.

maxlist([X], X).
maxlist([H|T], M) :-
    maxlist(T, MT),
    (   H > MT
    ->  M is H
    ;   M is MT
    ).

% Q.16
insert_nth :-
    write('Enter the item to insert: '),
    read(I),
    write('Enter the position: '),
    read(N),
    write('Enter a list: '),
    read(L),
    insert_nth(I, N, L, R),
    write('Resultant list after insertion is: '), write(R),
    nl.

insert_nth(I, 1, L, [I|L]).
insert_nth(I, N, [H|T], [H|R]) :-
    N > 1,
    N1 is N - 1,
    insert_nth(I, N1, T, R).

% Q.17
delete_nth :-
    write('Enter the position: '),
    read(N),
    write('Enter a list: '),
    read(L),
    delete_nth(N, L, R),
    write('Resultant list after deletion is: '), write(R),
    nl.

delete_nth(1, [_|T], T).
delete_nth(N, [H|T], [H|R]) :-
    N > 1,
    N1 is N - 1,
    delete_nth(N1, T, R).

% Q.18
merge :-
    write('Enter the first ordered list: '),
    read(L1),
    write('Enter the second ordered list: '),
    read(L2),
    merge(L1, L2, M),
    write('Merged list is: '), write(M),
    nl.

merge([], L, L).
merge(L, [], L).
merge([H1|T1], [H2|T2], [H1|M]) :-
    H1 =< H2,
    merge(T1, [H2|T2], M).
merge([H1|T1], [H2|T2], [H2|M]) :-
    H1 > H2,
    merge([H1|T1], T2, M).
