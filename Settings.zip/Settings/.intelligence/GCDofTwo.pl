%Write a Prolog program to implement GCD of two numbers.


gcd(X, 0, X).
gcd(X, Y, G) :-
    Y > 0,
    Z is X mod Y,
    gcd(Y, Z, G).
