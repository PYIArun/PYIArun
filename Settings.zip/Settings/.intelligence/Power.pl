power(0,X,Ans):-
    X>0,
    Ans is 0.

power(_, 0, 1).

power(Num,Pow, Ans):-
      Num>0,
      Pow1 is Pow-1,
      power(Num, Pow1, Ans1),
      Ans is Num*Ans1.

