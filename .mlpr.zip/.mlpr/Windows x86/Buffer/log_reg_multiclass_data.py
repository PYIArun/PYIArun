# -*- coding: utf-8 -*-
"""
Created on Thu Mar 21 13:25:45 2024

@author:
"""
# logistic regression for multi-class classification using built-in one-vs-rest
from sklearn.datasets import make_classification
from sklearn.linear_model import LogisticRegression
from sklearn import datasets
from sklearn.preprocessing import StandardScaler

# define dataset

wine= datasets.load_wine()
x=wine.data
wine.feature_names
y=wine.target
wine.data.shape
Scaler=StandardScaler()
X=Scaler.fit_transform(x)

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=0)

# define model
model = LogisticRegression(multi_class='ovr')
# fit model
model.fit(x_train, y_train)
# make predictions
yhat = model.predict(x_test)
scr = model.score( x_test,y_test)
print(scr)

from sklearn.multiclass import OneVsRestClassifier
# define model
model = LogisticRegression()
# define the ovr strategy
ovr = OneVsRestClassifier(model)
# fit model
ovr.fit(x_train, y_train)
# make predictions
yhat = ovr.predict(x_test)

score = ovr.score(x_test,y_test)
print(score)


# SVM for multi-class classification using built-in one-vs-one
from sklearn.datasets import make_classification
from sklearn.svm import SVC
# define dataset

model = SVC(decision_function_shape='ovo')
# fit model
model.fit(X, y)
# make predictions
yhat = model.predict(X)


# SVM for multi-class classification using one-vs-one
from sklearn.datasets import make_classification
from sklearn.svm import SVC
from sklearn.multiclass import OneVsOneClassifier
# define model
model = SVC()
# define ovo strategy
ovo = OneVsOneClassifier(model)
# fit model
ovo.fit(X, y)
# make predictions
yhat = ovo.predict(X)

score = ovo.score(x_test,y_test)
print(score)

