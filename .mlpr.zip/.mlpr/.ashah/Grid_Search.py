import numpy as np
import pandas as pd
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, precision_score, recall_score, f1_score

df = pd.read_csv('C:/Users/HP/Desktop/Machine Learning/Mobile.csv')
X = df.drop('price_range',axis=1)
y = df['price_range']
df.drop('price_range',axis=1, inplace= True)
X = np.array(X)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 42, shuffle= True, stratify = y)
knn = KNeighborsClassifier()

k_range = list(range(1, 11))
weight = ['uniform', 'distance']
ps=[1,2]
param_grid = dict(n_neighbors=k_range,weights=weight,p=ps)
grid = GridSearchCV(knn, param_grid, cv=10, scoring= 'accuracy')
# fitting the model for grid search
grid_search=grid.fit(X_train, y_train)
print(grid_search.best_params_) 
best_k=grid_search.best_estimator_.get_params()['n_neighbors']
best_w=grid_search.best_estimator_.get_params()['weights']
best_p=grid_search.best_estimator_.get_params()['p']
print('Best K neighbors:', best_k)
print('Best weight:', best_w)
print('Beat P value:', best_p)

knn = KNeighborsClassifier(n_neighbors=best_k,weights=best_w,p=best_p)
knn.fit(X_train, y_train)
y_pred=knn.predict(X_test) 
accuracy= accuracy_score(y_test,y_pred)*100
print("Accuracy of the Model: ", accuracy)
print("\nConfusion Matrix:")
conf_matrix = confusion_matrix(y_test, y_pred)
print(conf_matrix)
print("\nPrecision Score:")
precision = precision_score(y_test, y_pred, average ='weighted')
print(precision)
print("\nRecall Score:")
recall = recall_score(y_test, y_pred, average = 'weighted')
print(recall)
print("\nF1 Score:")
f1score = f1_score(y_test, y_pred, average = 'weighted')
print(f1score)