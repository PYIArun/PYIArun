# -*- coding: utf-8 -*-
"""
Created on Mon Apr 29 23:22:12 2024

@author: kripl
"""
from sklearn import metrics
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


scaler = StandardScaler()
data = pd.read_csv('Heart_failure.csv')
data.columns
y = data['DEATH_EVENT'] 
X = data.drop('DEATH_EVENT', axis =1)

X = scaler.fit_transform(X)

s1 = []
for i in range(10):
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
    gnb = GaussianNB()
    model= gnb.fit(X_train, y_train)
    score = model.score(X_test,y_test)
    print(score)
    s1.append(score)

Score_1 = np.average(s1)
print('Average Score using Gussian naivebayes classifier:',Score_1)


s2 =[]
for i in range(10):
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
    model = MLPClassifier(
        activation='logistic', max_iter=2000, hidden_layer_sizes=(4,2))
    model.fit(X, y)
    score = model.score(X_test,y_test)
    print(score)
    s2.append(score)


Score_2 = np.average(s2)
print('Average Score using MLP classifier:',Score_2)

s3 = []

for i in range(10):
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
    dtc=DecisionTreeClassifier(max_depth=2)
    dtc.fit(X_train,y_train)
    score = model.score(X_test,y_test)
    y_predict=dtc.predict(X_test)
    #score=metrics.accuracy_score(y_test, y_predict)
    print(score)
    #print(score)
    s3.append(score)

Score_3 = np.average(s3)
print('Average Score using Decision tree classifier:',Score_3)


s4 = []
for i in range(10):
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
    knn=KNeighborsClassifier(n_neighbors=2)
    knn.fit(X_train,y_train)
    score = knn.score(X_test,y_test)
    y_predict=dtc.predict(X_test)
    #score=metrics.accuracy_score(y_test, y_predict)
    print(score)
    s4.append(score)

Score_4 = np.average(s4)
print('Average Score using KNeighbour classifier:',Score_4)


s5 = []
for i in range(10):
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    Logistic_Reg = LogisticRegression()
    Logistic_Reg.fit(X_train,y_train)
    predictions = Logistic_Reg.predict(X_test)
    score = Logistic_Reg.score(X_test,y_test)
    print(score)
    s5.append(score)
    
Score_5 = np.average(s5)
print('Average Score using Logistic Regression:',Score_5)

Results = {
    "Gussian naivebayes classifier": Score_1,
    "MLP classifier":Score_2,
    "Decision tree classifier":Score_3,
    "KNeighbour classifier":Score_4,
    "Logistic Regression":Score_5}

print(Results)
Classifiers = pd.Series(Results)
Classifiers= pd.DataFrame(Classifiers)
Classifiers.to_excel('Classifier.xlsx')
