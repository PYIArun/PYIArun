def stream_cipher_encrypt(plaintext, key):
    ciphertext = ""
    for i in range(len(plaintext)):
        ciphertext += chr(ord(plaintext[i]) ^ ord(key[i % len(key)]))
    return ciphertext

def stream_cipher_decrypt(ciphertext, key):
    plaintext = ""
    for i in range(len(ciphertext)):
        plaintext += chr(ord(ciphertext[i]) ^ ord(key[i % len(key)]))
    return plaintext

def plaintext_attack(ciphertext, known_plaintext):
    key = ""
    for i in range(len(known_plaintext)):
        key += chr(ord(ciphertext[i]) ^ ord(known_plaintext[i]))
    return key

def ciphertext_attack(ciphertext, known_ciphertext):
    key = ""
    for i in range(len(known_ciphertext)):
        key += chr(ord(ciphertext[i]) ^ ord(known_ciphertext[i]))
    return key

def main():
    plaintext = "This is a secret message."
    key = "randomkey"
    
    # Encryption
    ciphertext = stream_cipher_encrypt(plaintext, key)
    print("Original plaintext:", plaintext)
    print("Encrypted ciphertext:", ciphertext)
    
    # Plaintext Attack
    known_plaintext = "This is a"
    recovered_key_plaintext = plaintext_attack(ciphertext, known_plaintext)
    decrypted_plaintext = stream_cipher_decrypt(ciphertext, recovered_key_plaintext)
    print("\nPlaintext Attack:")
    print("Recovered key from known plaintext:", recovered_key_plaintext)
    print("Decrypted plaintext:", decrypted_plaintext)
    
    # Ciphertext Attack
    known_ciphertext = ciphertext[:len(known_plaintext)]
    recovered_key_ciphertext = ciphertext_attack(ciphertext, known_ciphertext)
    decrypted_plaintext = stream_cipher_decrypt(ciphertext, recovered_key_ciphertext)
    print("\nCiphertext Attack:")
    print("Recovered key from known ciphertext:", recovered_key_ciphertext)
    print("Decrypted plaintext:", decrypted_plaintext)

if __name__ == "__main__":
    main()
