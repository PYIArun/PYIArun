# -*- coding: utf-8 -*-
"""
Created on Mon Feb  5 22:08:55 2024

@author: TANMAY
"""

import pandas as pd
from sklearn.naive_bayes import CategoricalNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix

doc_num=pd.read_csv('C:/Users/TANMAY/Desktop/TANMAY/python/NPHA-doctor-visits.csv',sep=',')
doc_num.drop(['Age'],axis=1,inplace=True)
doc_num.drop(['Gender'],axis=1,inplace=True)

features=['Phyiscal Health','Mental Health','Dental Health','Employment','Stress Keeps Patient from Sleeping','Medication Keeps Patient from Sleeping','Pain Keeps Patient from Sleeping','Bathroom Needs Keeps Patient from Sleeping','Uknown Keeps Patient from Sleeping','Trouble Sleeping','Prescription Sleep Medication','Race']
target="Number of Doctors Visited"
doc_num.replace(-1,10,inplace=True)
#doc_num.replace(-2,11,inplace=True)

x=doc_num[features]
y=doc_num[target]

X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.2 ,stratify=y)

clf = CategoricalNB()

clf.fit(X_train,y_train)
y_pred=clf.predict(X_test)
accuracy_score(y_test, y_pred)
confusion_matrix(y_test, y_pred)















# acc=[]
# acc_c=0
# c= None
# for i in range(10):
#     X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.2 ,stratify=y)

#     clf = CategoricalNB()

#     clf.fit(X_train,y_train)
#     y_pred=clf.predict(X_test)
#     acc.append(accuracy_score(y_test, y_pred))
#     acc_c=acc_c+accuracy_score(y_test, y_pred)
#     c=confusion_matrix(y_test, y_pred)
#     print(c)
#     c=None
# print('Average accuracy of 10 splits : ',acc_c/10)
# print('accuracies were : ',acc)

