# Naive Bayes theorem Implementation
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import MinMaxScaler
import pandas as pd

# seperate features(X) and target variable(y)
df = pd.read_csv("C:/Users/ashis/OneDrive/Desktop/Machine Learning/Mobile.csv")

X = df.drop('price_range',axis=1)
y = df['price_range']
scaler = MinMaxScaler((0,1))
X=scaler.fit_transform(X)
X = pd.DataFrame(X)
x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=0.2,random_state=0)
gnb = GaussianNB()
result=[]
n=0
while n<=x_train.shape[1]:
    for i in range(x_train.shape[1]-n):
        current_feature_indices = []
        ctr=i
        while len(current_feature_indices)<=n:
            current_feature_indices = current_feature_indices + [ctr]
            ctr=ctr+1
        gnb.fit(x_train.loc[:,current_feature_indices],y_train)
        y_test_hat = gnb.predict(x_test.loc[:,current_feature_indices])
        accuracy= accuracy_score(y_test,y_test_hat)*100
        result.append({'Indices' : df.columns[current_feature_indices], 'Features Count: ': len(current_feature_indices), 'Accuracy': '{:.2f}'.format(accuracy)})
    n=n+1
df2 = pd.DataFrame(result)
print(df2)
print(df2[df2['Accuracy']==max(df2['Accuracy'])].iloc[0,1:])
excel_fp = 'Iris_Wrapper.xlsx'
df2.to_excel(excel_fp, index=False)
print(f'Data Exported to {excel_fp}')