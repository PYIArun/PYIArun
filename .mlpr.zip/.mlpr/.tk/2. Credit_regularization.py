#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Feb  8 09:26:23 2020

@author: baljeetkaur
"""
# I have understood this using an example by Smith College 
#http://www.science.smith.edu/~jcrouser/SDS293/labs/lab10-py.html

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.preprocessing import scale 
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Ridge, RidgeCV
from sklearn.metrics import mean_squared_error


df = pd.read_csv('Credit.csv')
X1=df.iloc[:,1:]
y=X1['Balance']
X=X1.drop(['Gender','Student','Married','Ethnicity','Balance' ],axis=1) #Just for better visulaiation, we could have created by changing these too



#generate some big to small lamdas, in pythonscikit learn it is called alpha
alphas = 10**np.linspace(10,-2,100)*0.5
alphas
ridge = Ridge() #standardize the variables to be on the same scale
coefs = []

for a in alphas:
    ridge.set_params(alpha = a)
    ridge.fit(X, y)
    coefs.append(ridge.coef_)
    
np.shape(coefs)


#see if the coeefs acre decreasing with increasing alphas

ax = plt.gca()
ax.plot(alphas, coefs)
ax.set_xscale('log')
plt.axis('tight')
plt.xlabel('alpha')
plt.ylabel('weights')



#split data for better inference
X_train, X_test , y_train, y_test = train_test_split(X, y, test_size=0.5, random_state=1) 



#let lamda = 4
ridge2 = Ridge(alpha = 4)
ridge2.fit(X_train, y_train)             # Fit a ridge regression on the training data
pred2 = ridge2.predict(X_test)           # Use this model to predict the test data
print(pd.Series(ridge2.coef_, index = X.columns)) # Print coefficients
print(mean_squared_error(y_test, pred2))          # Calculate the test MSE


#let lamda = very big
ridge3 = Ridge(alpha = 10**10)
ridge3.fit(X_train, y_train)             # Fit a ridge regression on the training data
pred3 = ridge3.predict(X_test)           # Use this model to predict the test data
print(pd.Series(ridge3.coef_, index = X.columns)) # Print coefficients
print(mean_squared_error(y_test, pred3))          # Calculate the test MSE

#This resulted in a model with only the intercept, very large MSE


#let lambda=0 which is the full least squares 
ridge1 = Ridge(alpha = 0)
ridge1.fit(X_train, y_train)             # Fit a ridge regression on the training data
pred = ridge1.predict(X_test)            # Use this model to predict the test data
print(pd.Series(ridge1.coef_, index = X.columns)) # Print coefficients
print(mean_squared_error(y_test, pred))           # Calculate the test MSE



#to find the best labda we do cross val

ridgecv = RidgeCV(alphas = alphas, scoring = 'neg_mean_squared_error')
ridgecv.fit(X_train, y_train)
ridgecv.alpha_

#Now let us investigate this lambda

ridge4 = Ridge(alpha = ridgecv.alpha_)
ridge4.fit(X_train, y_train)
mean_squared_error(y_test, ridge4.predict(X_test))

#MSE decreased slightly


#Refit on full dataset
ridge4.fit(X, y)
pd.Series(ridge4.coef_, index = X.columns)





