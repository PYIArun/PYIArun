#include "Stack.h"
#include <iostream>
using namespace std;

void sortStack(Stack<int> &s1, Stack<int> &s2) {
    while (!s1.isEmpty()) {
        int s1Pop = s1.pop();

        while (!s2.isEmpty() && s2.topEl() > s1Pop) {
            s1.push(s2.pop());
        }

        s2.push(s1Pop);
    }

    while (!s2.isEmpty()) {
        s1.push(s2.pop());
    }
}

int main(){

    Stack<int> s1;
    Stack<int> s2;

    s1.push(5);
    s1.push(1);
    s1.push(3);
    s1.push(2);
    s1.push(6);
    cout<<"Unsorted Stack: ";
    s1.printStack();

    sortStack(s1, s2);
    cout<<"Sorted Stack: ";
    s1.printStack();
    return 0;
}