% Facts: Define family relations
% Family 1
parent(john1, ann1).
parent(john1, mary1).
parent(jane1, ann1).
parent(jane1, mary1).
parent(ann1, pete1).
parent(ann1, sara1).
parent(mary1, jim1).

% Family 2
parent(john2, ann2).
parent(john2, mary2).
parent(jane2, ann2).
parent(jane2, mary2).
parent(ann2, pete2).
parent(ann2, sara2).
parent(mary2, jim2).


% Additional facts for gender
male(john1).
male(pete1).
male(jim1).
male(john2).
male(pete2).
male(jim2).

female(jane1).
female(ann1).
female(mary1).
female(sara1).
female(jane2).
female(ann2).
female(mary2).
female(sara2).


% Rules: Define relationships
father(X, Y) :- parent(X, Y), male(X).
mother(X, Y) :- parent(X, Y), female(X).
child(X, Y) :- parent(Y, X).
sibling(X, Y) :- parent(Z, X), parent(Z, Y), X \= Y.

% Ancestor relationships
ancestor(X, Y) :- parent(X, Y).
ancestor(X, Y) :- parent(X, Z), ancestor(Z, Y).

% Define a generic relation-checking predicate
related(X, Y) :- ancestor(X, Y).
related(X, Y) :- ancestor(Y, X).
related(X, Y) :- sibling(X, Y).
related(X, Y) :- sibling(Y, X).
related(X, Y) :- father(X, Z), mother(Y, Z).
related(X, Y) :- mother(X, Z), father(Y, Z).

% Example queries:
% ancestor(john, jim) will succeed.
% ancestor(ann, sara) will succeed.
% related(john, sara) will succeed.
% related(ann, jim) will succeed.
