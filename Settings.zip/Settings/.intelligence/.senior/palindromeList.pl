%is_palindrome([]).
%is_palindrome([_]).

%is_palindrome(List) :-
%    append([First|Middle], [Last], List),
%    First == Last,
%    is_palindrome(Middle).
%

is_palindrome(L):-
    reverse_list(L,L).
