#include <iostream>
#include <algorithm>

using namespace std;

// Function to find the intersection of two sorted arrays
// To: Find elements common to both input arrays and return them as an array
// Input:
//   - int arr1[]: First sorted array
//   - int m: Size of the first array
//   - int arr2[]: Second sorted array
//   - int n: Size of the second array
// Output:
//   - int*: Pointer to the array containing elements common to both input arrays
// Approach:
//   - Use two pointers to traverse the sorted arrays.
//   - Store common elements in a temporary array.
//   - Remove duplicates from the temporary array.
//   - Allocate a new array and copy the unique elements from the temporary array.
int* find_intersection(int arr1[], int m, int arr2[], int n, int &result_size) {
    int* temp_result = new int[m > n ? m : n];  // Allocate temporary array with maximum possible size
    int temp_size = 0;
    int first = 0;
    int second = 0;

    while (first < m && second < n) {
        if (arr1[first] == arr2[second]) {
            // Avoid adding duplicates
            if (temp_size == 0 || temp_result[temp_size - 1] != arr1[first]) {
                temp_result[temp_size++] = arr1[first];
            }
            first++;
            second++;
        } else if (arr1[first] < arr2[second]) {
            first++;
        } else {
            second++;
        }
    }

    int* result = new int[temp_size];
    copy(temp_result, temp_result + temp_size, result);

    delete[] temp_result; 
    result_size = temp_size;
    return result;
}

int main() {
    int m, n;

    cout << "Enter the size of the first array: ";
    cin >> m;
    int* arr1 = new int[m];
    cout << "Enter the elements of the first array: ";
    for (int i = 0; i < m; ++i) {
        cin >> arr1[i];
    }

    cout << "Enter the size of the second array: ";
    cin >> n;
    int* arr2 = new int[n];
    cout << "Enter the elements of the second array: ";
    for (int i = 0; i < n; ++i) {
        cin >> arr2[i];
    }

    sort(arr1, arr1 + m);
    sort(arr2, arr2 + n);

    int result_size;
    int* result = find_intersection(arr1, m, arr2, n, result_size);

    cout << "Intersection of the two arrays: ";
    for (int i = 0; i < result_size; ++i) {
        cout << result[i] << " ";
    }
    cout << endl;

    delete[] arr1;
    delete[] arr2;
    delete[] result;

    return 0;
}
