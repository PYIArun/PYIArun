# -*- coding: utf-8 -*-
"""
Created on Sun Feb 18 15:25:36 2024

@author: 
"""

import pandas as pd
import numpy as np
from sklearn.datasets import load_digits
digits=load_digits()
digits.keys()

digits.data.shape

x,y=digits.data,digits.target
from sklearn.preprocessing import StandardScaler
scaler=StandardScaler()
x_scaled=scaler.fit_transform(x)
x_scaled
from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(x_scaled,y,test_size=0.2, random_state=30)
from sklearn.linear_model import LogisticRegression
model=LogisticRegression()
model.fit(x_train,y_train)
model.score(x_test, y_test)

from sklearn.decomposition import PCA
pca=PCA(0.95)
x_pca=pca.fit_transform(x)
x_pca.shape
x_pca
pca.explained_variance_ratio_

pca.n_components_

Feat=[]
Info=[]
Accuracy=[]


x_train_pca,x_test_pca,y_train,y_test=train_test_split(x_pca,y,test_size=0.2,random_state=0)
model=LogisticRegression(max_iter=1000)
model.fit(x_train_pca,y_train)
model.score(x_test_pca,y_test)

for i in range(x_pca.shape[1]):
   x_train_pca,x_test_pca,y_train,y_test=train_test_split(x_pca[:,:i+1],y,test_size=0.2,random_state=0)
   model=LogisticRegression(max_iter=1000)
   model.fit(x_train_pca,y_train)
   Acc= model.score(x_test_pca,y_test)
   Accuracy.append(Acc)
   
   info_sum = sum(pca.explained_variance_ratio_[0:i+1]) *  100
   Info.append(info_sum)
   Feat.append(i+1)
   

  
df = pd.DataFrame({'Features' :pd.Series(Feat),'Information':pd.Series(Info), 'Accuracy':pd.Series(Accuracy)})
print(df)
filep="3462_dev Ratan.xlsx"
df.to_excel(filep,index=False) 
print("SUCCESSFULLY EXPORTED")



