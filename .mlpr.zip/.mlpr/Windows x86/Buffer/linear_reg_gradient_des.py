# -*- coding: utf-8 -*-
"""
Created on Thu Mar  7 13:12:54 2024

@author: 
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


data = pd.read_csv("C:/Users/91931/Downloads/ex1data1.txt", header = None) #read from dataset
X = data.iloc[:,0] # read first column
y = data.iloc[:,1] # read second column
m = len(y) # number of training example
data.head() # view first few rows of the data


plt.scatter(X, y)
plt.xlabel('Population of City in 10,000s')
plt.ylabel('Profit in $10,000s')
plt.show()

X=np.array(X).reshape(X.shape[0],1)
y=np.array(y).reshape(y.shape[0],1)

ones = np.ones((m,1))
X = np.hstack((ones, X)) # adding the intercept term

theta = np.zeros((2,1))
#iterations = 20000
#alpha = 0.001

# alpha 0.001 iter 20000 gave near to normal equations
# alpha 0.01 iter 20000 gave near to normal equations

iterations = 500
alpha = 0.02


def computeCost(X, y, theta):
    temp = np.dot(X, theta) - y
    return np.sum(np.power(temp, 2)) / (2*m)



def gradientDescent(X, y, theta, alpha, iterations):
    
    for _ in range(iterations):
        temp = np.dot(X, theta) - y
        temp = np.dot(X.T, temp)
        theta = theta - (alpha/m) * temp
        print(computeCost(X,y,theta))
        plt.scatter(X[:,1], y)
        plt.plot(X[:,1], np.dot(X, theta))
        plt.show()
    return  theta


J = computeCost(X, y, theta)
print(J)
plt.scatter(X[:,1], y)
plt.plot(X[:,1], np.dot(X, theta))
plt.show()
theta = gradientDescent(X, y, theta, alpha, iterations)
print(theta)
plt.scatter(X[:,1], y)
plt.plot(X[:,1], np.dot(X, theta))
plt.show()
J = computeCost(X, y, theta)
print(J)







