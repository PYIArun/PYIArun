# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 02:49:17 2024

@author: kaush
"""

import numpy as np
from sklearn.datasets import fetch_california_housing
from sklearn.datasets import fetch_olivetti_faces
import matplotlib.pyplot as plt

# Fetch the California housing dataset
#housing = fetch_california_housing()
housing = fetch_olivetti_faces()

# Extract features (taking only the first column) and target
X = housing.data[:, 0].reshape(-1, 1)  # First column as feature
y = housing.target.reshape(-1, 1)  # Target

# Print shape of data
print("Shape of features:", X.shape)
print("Shape of target:", y.shape)

# Check for null values
null_values = np.isnan(X).sum()
print("Null values in first column:", null_values)

# Plot the original data
plt.scatter(X, y)
plt.xlabel('Feature (First Column)')
plt.ylabel('Target')
plt.title('Original Data')
plt.show()

# Normal equation method
def normal_equation(X, y):
    X_b = np.c_[np.ones((len(X), 1)), X]  # Add intercept term
    theta = np.linalg.inv(X_b.T.dot(X_b)).dot(X_b.T).dot(y)
    return theta

# Calculate theta values
theta = normal_equation(X, y)
print("Theta values obtained from the normal equation:")
print(theta)

# Make predictions
y_pred = np.dot(np.c_[np.ones((len(X), 1)), X], theta)

# Plot the original data along with the regression line
plt.scatter(X, y)
plt.plot(X, y_pred, color='red', label='Linear Regression')
plt.xlabel('Feature (First Column)')
plt.ylabel('Target')
plt.title('Linear Regression')
plt.legend()
plt.show()
