# -*- coding: utf-8 -*-
"""
Created on Tue Mar  5 09:05:21 2024

@author: hp

m = 442
n = 10

"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import load_diabetes
from sklearn.metrics import mean_squared_error , r2_score

X, y = load_diabetes(return_X_y=True)
m = len(y)
y = y.reshape(-1,1)

ones = np.ones((m,1))
X = np.hstack((ones, X))


def theta_calc(x,y):
    theta_1=np.linalg.inv(np.dot(x.T,x))
    theta_2=np.dot(theta_1,x.T)
    theta=np.dot(theta_2,y)
    return theta

theta_val=theta_calc(X,y)
y_pred = np.dot(X, theta_val)

mse = mean_squared_error(y,y_pred)
r2_score = r2_score(y,y_pred)




