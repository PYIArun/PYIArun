import string

def key_generation(key):
    # initializing all and generating key_matrix
    main=string.ascii_lowercase.replace('j','.')
    # convert all alphabets to lower
    key=key.lower()
    
    key_matrix=['' for i in range(5)]
    # if we have spaces in key, those are ignored automatically
    i=0;j=0
    for c in key:
        if c in main:
            # putting into matrix
            key_matrix[i]+=c

            # to make sure repeated characters in key
            # doesnt include in the key_matrix, we replace the
            # alphabet into . in the main, whenever comes in iteration
            main=main.replace(c,'.')
            # counting column change
            j+=1
            # if column count exceeds 5
            if(j>4):
                # row count is increased
                i+=1
                j=0

    for c in main:
        if c!='.':
            key_matrix[i]+=c

            j+=1
            if j>4:
                i+=1
                j=0
                
    return(key_matrix)


# Now ciphertext is to be converted into plaintext

def conversion(cipher_text):
    plain_text_pairs=[]
    cipher_text_pairs=[]

    cipiher_text=cipher_text.lower()

    #if both letters in the pair are same or one letter is left at last,
    # replace second letter with x or add x, else continue with normal pairing

    i=0
    while i<len(cipher_text):
        # i=0,1,2,3
        a=cipher_text[i]
        b=cipher_text[i+1]

        cipher_text_pairs.append(a+b)
        i+=2
            
    print("cipher text pairs: ",cipher_text_pairs)


    for pair in cipher_text_pairs:
        # if the letters are in the same row, replace them with
        # letters to their immediate right respectively
        flag=False
        for row in key_matrix:
            if(pair[0] in row and pair[1] in row):
                j0=row.find(pair[0])
                j1=row.find(pair[1])

                plain_text_pair=row[(j0+4)%5]+row[(j1+4)%5]
                plain_text_pairs.append(plain_text_pair)
                flag=True
        if flag:
            continue

        #if the letters are in the same column, replace them with
        # letters to their immediate below respectively
                
        for j in range(5):
            col="".join([key_matrix[i][j] for i in range(5)])
            if(pair[0] in col and pair[1] in col):
                i0=col.find(pair[0])
                i1=col.find(pair[1])
                plain_text_pair=col[(i0+4)%5]+col[(i1+4)%5]
                plain_text_pairs.append(plain_text_pair)
                flag=True
        if flag:
            continue


        i0=0
        i1=0
        j0=0
        j1=0

        for i in range(5):
            row=key_matrix[i]
            if(pair[0] in row):
                i0=i
                j0=row.find(pair[0])
            if(pair[1] in row):
                i1=i
                j1=row.find(pair[1])
        plain_text_pair=key_matrix[i0][j1]+key_matrix[i1][j0]
        plain_text_pairs.append(plain_text_pair)
        
    print("plain text pairs: ",plain_text_pairs)
    # final statements
    
    print('cipher text: ',"".join(cipher_text_pairs))
    print('plain text (message): ',"".join(plain_text_pairs))


key=input("Enter the key: ")

key_matrix=key_generation(key)
print("Key Matrix for encryption:")
print(key_matrix)
cipher_text=input("Enter the encrypted message: ")

conversion(cipher_text)

