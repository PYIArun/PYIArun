% Base case: X is the first element of the list
memb(X, [X|_]).

% Recursive rule: X is a member of the tail of the list
memb(X, [_|Tail]) :-
    memb(X, Tail).
% Example usage:
% memb(3, [1, 2, 3, 4, 5]).
