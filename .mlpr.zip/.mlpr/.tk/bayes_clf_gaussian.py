#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Dec 29 11:38:18 2019

@author: baljeetkaur
"""

# example of gaussian naive bayes
from sklearn.datasets import make_blobs
from sklearn.naive_bayes import GaussianNB
# generate 2d classification dataset
X, y = make_blobs(n_samples=100, centers=2, n_features=2, random_state=1,cluster_std=3)
# define the model
import matplotlib.pyplot as plt

plt.scatter(X[:,0],X[:,1],c=y)

model = GaussianNB()
# fit the model
model.fit(X, y)
# select a single sample
Xsample, ysample = [X[0]], y[0]   #scikit expects a 2 D array, hence note the difference

#Xsample.reshape(1,-1)
# make a probabilistic prediction
yhat_prob = model.predict_proba(Xsample)
print('Predicted Probabilities: ', yhat_prob)
# make a classification prediction
yhat_class = model.predict(Xsample)
print('Predicted Class: ', yhat_class)
print('Truth: y=%d' % ysample)



# make a classification prediction
yhat_class = model.predict(X)
print('Predicted Class: ', yhat_class)
from sklearn.metrics import accuracy_score
accuracy_score(yhat_class, y)
