# -*- coding: utf-8 -*-
"""
Created on Thu Feb 29 20:12:18 2024

@author: Arun
"""


'''
Knearest neighbour
For a sufficiently large data do the following:
1. Write a Python program to classify the data as per KNN. Determine the a) best k, b) 
p, c) whether normal or distance. Give the average result for crossval on 5 folds. Give 
performance in terms of accuracy, precision, recall, and f1 score.
2. Repeat the program using
i. Sklearn
ii. Crossval
iii. Gridserach
iv. Pipeline
3. Take a regression problem and build a regression model using sklearn, crossval, 
gridsearch, pipelines. Give performance in terms of RMSE.
'''

from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import cross_val_score, cross_val_predict, GridSearchCV, train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score
import pandas as pd
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn import metrics
import numpy as np
import pandas as pd

df = pd.read_csv("C:/Users/arunc/Desktop/Programs/HRanalytics.csv")
df['left'].value_counts() # Ratio is 70 (not left) and 30 (left)
print(df.head())

label_encoder = LabelEncoder()
df['Department'] = label_encoder.fit_transform(df['Department'])
df['salary'] = df['salary'].replace({'low': 1, 'medium': 2, 'high':3})

y = df['left']
X_prev = df.drop(['left'], axis=1)

x_train, x_test, y_train, y_test = train_test_split(X_prev, y, test_size = 0.2, random_state = 0)


pipeline = Pipeline([
    ('scaler', StandardScaler()), 
    ('knn', KNeighborsClassifier())
])

param_grid = {'knn__n_neighbors': [3, 4, 5, 6, 7, 8, 9, 10],'knn__p': [1, 2],'knn__weights': ['uniform', 'distance']}

grid_search = GridSearchCV(pipeline, param_grid, cv=5, scoring='accuracy')
grid_search.fit(x_train, y_train)

print("Best Parameters:", grid_search.best_params_)
print("Best C-Val Accuracy:", grid_search.best_score_)

best_model = grid_search.best_estimator_
y_pred = cross_val_predict(best_model, x_test, y_test, cv=5)

accuracy = metrics.accuracy_score(y_test, y_pred)
precision = metrics.precision_score(y_test, y_pred, average='weighted')
recall = metrics.recall_score(y_test, y_pred, average='weighted')
f1 = metrics.f1_score(y_test, y_pred, average='weighted')

print("Accuracy:", accuracy)
print("Precision:", precision)
print("Recall:", recall)
print("F1 Score:", f1)
