% Q16. Insert to nth position
insert(_, _, [], []).
insert(X, 0, L, [X | L]).

insert(X, N, [H | T1] , [H | T]) :-
    N1 is N - 1,
    insert(X, N1, T1, T).

insertToList :-
    read_num("Enter the list: ", L),
    read_num("Enter the new value: ", X),
    read_num("Enter the position: ", N),
    insert(X, N, L, R),
    write("The new list: "),
    write(R).
