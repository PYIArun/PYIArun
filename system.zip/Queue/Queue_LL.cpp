#include <iostream>
#include "Node.h"
using namespace std;

template <class T>
class Queue{

    public:
    Node<T> *front;
    Node<T> *rear;

    Queue(){
        front = nullptr;
        rear = nullptr;
    }

    void enqueue(T x){

        Node<T> *newNode = new Node<T>(x);

        if(isEmpty()){
            front = newNode;
            rear = newNode;
            return;
        }

        rear->next  = newNode;
        rear = newNode;

    }

    void dequeue(){

        if(isEmpty()){
            cout<<"Queue is empty!";
            return;
        }

        Node<T> *temp = front;
        if(front==rear){
            front = nullptr;
            rear = nullptr;
            delete temp;
        }else{
            front = front->next;
            delete temp;
        }

    }

    T getFront(){
        if(isEmpty()){
            cout<<"Queue is empty!";
            return T();
        }
        return front->data;
    }

    bool isEmpty(){
        if(front==nullptr){
            return true;
        }

        return false;

    }

    void printQueue(){
        Node<T> *temp = front;

        while(temp!=nullptr){
            cout<< temp->data << " ";
            temp = temp->next;
        }

    }
    
};

int main() {
    Queue<int> q;
    int choice, value;

    do {
        cout << "\nMenu:\n";
        cout << "1. Enqueue\n";
        cout << "2. Dequeue\n";
        cout << "3. Get Front\n";
        cout << "4. Check if Empty\n";
        cout << "5. Print Queue\n";
        cout << "6. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter value to enqueue: ";
                cin >> value;
                q.enqueue(value);
                break;
            case 2:
                q.dequeue();
                break;
            case 3:
                cout << "Front: " << q.getFront() << endl;
                break;
            case 4:
                cout << (q.isEmpty() ? "Queue is Empty." : "Queue is Not Empty.") << endl;
                break;
            case 5:
                cout << "Current Queue: ";
                q.printQueue();
                break;
            case 6:
                cout << "Exiting..." << endl;
                break;
            default:
                cout << "Invalid choice! Please try again." << endl;
        }
    } while (choice != 6);

    return 0;
}