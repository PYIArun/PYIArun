% Base case: Concatenating an empty list with any list results in the same list
conc([], L, L).

% Recursive rule: The first element of L1 becomes the head of result,
% then recursively append the rest L1 to L3.
conc([Head|Tail], L2, [Head|Result]) :-
    conc(Tail, L2, Result).
% Example usage:
% conc([1, 2, 3], [4, 5, 6], Result).
