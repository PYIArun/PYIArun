# -*- coding: utf-8 -*-
"""
Created on Thu Feb 22 23:06:37 2024

@author: IN Phantom AKR
"""
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.decomposition import TruncatedSVD
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score

df = pd.read_csv("K:/Phantom AKR, LLC/Semester 6/WineQT.csv")
X = df.drop('quality', axis=1)
y = df['quality']

scaler = MinMaxScaler((0, 1))
X = scaler.fit_transform(X)
model = GaussianNB()

best_accuracy = 0
optimal_k = 0
results = []
result = []

for k in range(1, X.shape[1] + 1):
    svd = TruncatedSVD(n_components=k)
    svd.fit(X)
    Xt = svd.transform(X)

    X_train, X_test, y_train, y_test = train_test_split(Xt, y, test_size=0.2, random_state=0)

    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    test_accuracy = accuracy_score(y_test, y_pred) * 100

    if test_accuracy > best_accuracy:
        best_accuracy = test_accuracy
        optimal_k = k
        
    results.append({"Iteration":k-1, 'No. of Features': k,'Accuracy': f'{test_accuracy:.7f}'})
    print(f'Accuracy with k={k} : {test_accuracy:.7f}')

if optimal_k>0:
    print(f'Best accuracy: {best_accuracy:.7f} with k={optimal_k}')
else:
    print('No optimal k found :|')
    
resultant_df  = pd.DataFrame(results)
print(resultant_df)
resultant_df.to_excel("svd_result_AKR.xlsx", index=False)
print(f'Data Exported to {excel_fp}')



# import pandas as pd
# from sklearn.preprocessing import MinMaxScaler

# df = pd.read_csv("K:/Phantom AKR, LLC/Semester 6/WineQT.csv")

# X = df.drop('quality',axis=1)
# y = df['quality']
# scaler = MinMaxScaler((0,1))
# X=scaler.fit_transform(X)

# from sklearn.decomposition import TruncatedSVD
# from sklearn.model_selection import train_test_split
# from sklearn.naive_bayes import GaussianNB
# from sklearn.metrics import accuracy_score
# gnb = GaussianNB()

# result = []
# for i in range(0,X.shape[1]):
#     svd = TruncatedSVD(n_components = i+1)
#     svd.fit(X)
#     Xt = svd.transform(X)
#     X_train, X_test, y_train, y_test = train_test_split(Xt, y, test_size=0.2,random_state=0)
#     model= gnb.fit(X_train, y_train)
#     y_pred=model.predict(X_test)
#     test_accuracy = accuracy_score(y_test, y_pred) * 100
#     print(f'Accuracy with k{i+1} : {test_accuracy}')
#     result.append({'Features Count': i+1, 'Accuracy': '{:.2f}'.format(test_accuracy)})
    
# df2 = pd.DataFrame(result)
# print(df2) 
# print(df2[df2['Accuracy']==max(df2['Accuracy'])].iloc[0,:])
# excel_fp = 'AshishSah_3436.xlsx'
# df2.to_excel(excel_fp, index=False)
# print(f'Data Exported to {excel_fp}')

# from AshishSah_3436_pca import pca_bp
# print(pca_bp)
# print(class(pca_bp)) 