# -*- coding: utf-8 -*-
"""
Created on Thu Apr 18 11:55:59 2024

@author:
"""



# SVM program to classify multiclass data

import numpy as np
import pandas as pd

import scipy.optimize as opt
from sklearn.preprocessing import StandardScaler

from scipy import stats
from sklearn.preprocessing import LabelEncoder
# use seaborn plotting defaults


data=pd.read_csv("C:/Users/91931/Desktop/MLprograms/loistic_regression/Dry_Bean_Dataset.csv")
x=data.iloc[:,:-1]
y = data.iloc[:,16]
# Initialize LabelEncoder
label_encoder = LabelEncoder()

# Fit and transform the data
y = label_encoder.fit_transform(y)

# Print the encoded data
print(y)

Scaler=StandardScaler()
X=Scaler.fit_transform(x)

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=0)

from sklearn.svm import SVC
# define dataset
#X, y = make_classification(n_samples=1000, n_features=10, n_informative=5, n_redundant=5, n_classes=3, random_state=1)
# define model
model = SVC(C=10,kernel='rbf',gamma='auto',decision_function_shape="ovo")
# fit model
model.fit(x_train, y_train)
# make predictions
yhat = model.predict(x_test)
scr = model.score(x_test,y_test)
print(scr)
