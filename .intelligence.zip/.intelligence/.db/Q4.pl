% Base cases: Fib(0) is 0, Fib(1) is 1
generate_fib(0, 0).
generate_fib(1, 1).

% Recursive rule: Fib(N) is the sum of Fib(N-1) and Fib(N-2)
generate_fib(N, T) :-
    N > 1,
    N1 is N - 1,
    N2 is N - 2,
    generate_fib(N1, T1),
    generate_fib(N2, T2),
    T is T1 + T2.
% Example usage: 0 1 1 2 3 5 8 13 21 34
% generate_fib(5, Result).
