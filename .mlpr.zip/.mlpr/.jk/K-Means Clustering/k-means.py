# -*- coding: utf-8 -*-
"""
Created on Fri May  3 10:46:53 2024

@author: kaush
"""

import numpy as np
import matplotlib.pyplot as plt

def euclidean_distance(a, b):
    return np.sqrt(np.sum((a - b)**2))

def k_means_clustering(data, k, max_iterations=100):
    # Initialize centroids randomly
    centroids = data[np.random.choice(len(data), k, replace=False)]

    for _ in range(max_iterations):
        # Assign each data point to the nearest centroid
        clusters = [[] for _ in range(k)]
        for point in data:
            distances = [euclidean_distance(point, centroid) for centroid in centroids]
            cluster_index = np.argmin(distances)
            clusters[cluster_index].append(point)

        # Update centroids
        new_centroids = []
        for cluster in clusters:
            new_centroid = np.mean(cluster, axis=0)
            new_centroids.append(new_centroid)
        new_centroids = np.array(new_centroids)

        # Check for convergence
        if np.allclose(centroids, new_centroids):
            break

        centroids = new_centroids

    return centroids, clusters

# Example dataset
data = np.array([[1, 2], [1.5, 1.8], [5, 8], [8, 8], [1, 0.6], [9, 11]])

# Number of clusters
k_values = [2, 3, 4, 5]

# Perform k-means clustering for each value of k
for k in k_values:
    centroids, clusters = k_means_clustering(data, k)
    print(f"Number of clusters: {k}")
    print("Centroids:")
    print(centroids)
    print("Clusters:")
    for i, cluster in enumerate(clusters):
        print(f"Cluster {i+1}: {cluster}")
    
    # Plot the clusters
    plt.figure()
    plt.title(f"K-Means Clustering (k={k})")
    colors = ['r', 'g', 'b', 'y', 'c', 'm']
    for i, cluster in enumerate(clusters):
        cluster = np.array(cluster)
        plt.scatter(cluster[:, 0], cluster[:, 1], c=colors[i], label=f'Cluster {i+1}')
    plt.scatter(centroids[:, 0], centroids[:, 1], marker='x', c='black', label='Centroids')
    plt.xlabel('X')
    plt.ylabel('Y')
    plt.legend()
    plt.show()
