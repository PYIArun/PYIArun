# -*- coding: utf-8 -*-
"""
Created on Sun Feb 25 22:22:49 2024

@author: Arun
"""

'''
Knearest neighbour
For a sufficiently large data do the following:
1. Write a Python program to classify the data as per KNN. Determine the a) best k, b) 
p, c) whether normal or distance. Give the average result for crossval on 5 folds. Give 
performance in terms of accuracy, precision, recall, and f1 score.
2. Repeat the program using
i. Sklearn
ii. Crossval
iii. Gridserach
iv. Pipeline
3. Take a regression problem and build a regression model using sklearn, crossval, 
gridsearch, pipelines. Give performance in terms of RMSE.
'''

from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import cross_val_score, cross_val_predict
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn import metrics
import numpy as np
import pandas as pd

df = pd.read_csv("C:/Users/arunc/Desktop/Programs/HRanalytics.csv")
df['left'].value_counts() # Ratio is 70 (not left) and 30 (left)
print(df.head())


#Encoding two categorical attributes
label_encoder = LabelEncoder()
df['Department'] = label_encoder.fit_transform(df['Department'])
df['salary'] = df['salary'].replace({'low': 1, 'medium': 2, 'high':3})


y = df['left']
X_prev = df.drop(['left'], axis=1)


scaler = StandardScaler()
X = scaler.fit_transform(X_prev)


# knn = KNeighborsClassifier(n_neighbors=i, p=p, weights=weight)
# knn.fit(X, y)
# y_predict = knn.predict(X)
# score = metrics.accuracy_score(y, y_predict) 

knn=KNeighborsClassifier(n_neighbors=2)

knn.fit(X,y)
y_predict=knn.predict(X)




kRange = [3, 4, 5, 6, 7, 8, 9, 10]
pRange = [1,2]  #(1 for Manhattan distance, 2 for Euclidean distance).
weights = ['uniform', 'distance']

bestAccuracy = 0
bestKvalue = 0
bestWeight = ''
bestPValue = 0

l_accuracies = []
l_k = []
l_p = []
l_weight = []

for k in kRange:
    for p in pRange:
        for weight in weights:
            knn = KNeighborsClassifier(n_neighbors=k, p=p, weights=weight)
            knn.fit(X, y)
            y_predict = knn.predict(X)
            score = metrics.accuracy_score(y, y_predict) 
            

            if score>bestAccuracy:
                bestAccuracy= score
                bestKvalue = k
                bestWeight = weight
                bestPValue = p
                
                l_accuracies.append(score)
                l_k.append(bestKvalue)
                l_p.append(p)
                l_weight.append(weight)
                
results_df = pd.DataFrame({
    "K": l_k,
    "P": l_p,
    "Weight" : l_weight,
    "Accuracy": l_accuracies
    
})  

print("Best K Value : ", bestKvalue)
print("Best P Value : ", bestPValue)
print("Best Weight : ", bestWeight)  
print("Best Accuracy : ", bestAccuracy)

cv_scr = cross_val_score(knn, X, y, cv=5) # cv=5 crossVal on 5 folds
print("Crossval:", cv_scr)
print("CrossVal mean:", np.mean(cv_scr))


y_pred = cross_val_predict(knn, X, y, cv=5)
g:\circle.cpaccuracy = metrics.accuracy_score(y, y_pred)
precision = metrics.precision_score(y, y_pred, average='weighted')
recall = metrics.recall_score(y, y_pred, average='weighted')
f1 = metrics.f1_score(y, y_pred, average='weighted')

print("Accuracy:", accuracy)
print("Precision:", precision)
print("Recall:", recall)
print("F1 Score:", f1)








