def stream_cipher_encrypt(plaintext, key):
    ciphertext = ""
    for i in range(len(plaintext)):
        # XOR each character of plaintext with corresponding character of key
        # If key is shorter than plaintext, repeat key cyclically
        ciphertext += chr(ord(plaintext[i]) ^ ord(key[i % len(key)]))
    return ciphertext

def stream_cipher_decrypt(ciphertext, key):
    plaintext = ""
    for i in range(len(ciphertext)):
        # XOR each character of ciphertext with corresponding character of key
        # If key is shorter than ciphertext, repeat key cyclically
        plaintext += chr(ord(ciphertext[i]) ^ ord(key[i % len(key)]))
    return plaintext

def main():
    plaintext = input("Enter plaintext: ")
    key = input("Enter key: ")

    # Encrypt the plaintext
    encrypted_text = stream_cipher_encrypt(plaintext, key)
    print("Encrypted ciphertext:", encrypted_text)

    # Decrypt the ciphertext
    decrypted_text = stream_cipher_decrypt(encrypted_text, key)
    print("Decrypted plaintext:", decrypted_text)

if __name__ == "__main__":
    main()
