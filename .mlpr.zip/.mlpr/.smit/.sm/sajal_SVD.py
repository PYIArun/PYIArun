# -*- coding: utf-8 -*-
"""
Created on Fri Feb 23 11:53:45 2024

@author: Sonu
"""

from sklearn.decomposition import TruncatedSVD
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.naive_bayes import GaussianNB
import pandas as pd
import numpy as np
from scipy.linalg import svd
from sklearn.datasets import load_digits
from numpy.linalg import svd
winedata = pd.read_csv("C:/Users/Sonu/Desktop/WineQT.csv")



X = winedata.drop('quality', axis=1)
y = winedata["quality"]


scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
X_scaled
x_train, x_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=30)

gnb = GaussianNB()


svd_accuracy = []

for i in range(X_scaled.shape[1]):
    svd = TruncatedSVD(n_components=i+1)
    svd.fit(X)
    result = svd.transform(X_scaled)
    x_train, x_test, y_train, y_test = train_test_split(
        result, y, test_size=0.2, random_state=0)
    model = gnb.fit(x_train, y_train)
    y_pred = model.predict(x_test)
    accuracy = accuracy_score(y_test, y_pred)*100
    print(accuracy)
    svd_accuracy.append(accuracy)
    
    
print(svd_accuracy)



df = pd.read_excel("C:/Users/Sonu/Desktop/PCA_result.xlsx")

# Create a new column with some data
Acc=svd_accuracy[:12]
df['svd_accuracy'] = Acc
print(df['svd_accuracy'])
# Save the updated DataFrame back to the Excel file
df.to_excel("C:/Users/Sonu/Desktop/sajal_svd.xlsx", index=False)
#df = pd.DataFrame({'Features' :pd.Series(Feat),'Information':pd.Series(Info), 'Accuracy':pd.Series(Accuracy)})
print(svd_accuracy)

df
print("SUCCESSFULLY EXPORTED")