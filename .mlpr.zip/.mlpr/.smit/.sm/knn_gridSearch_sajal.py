import pandas as pd
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, precision_score, f1_score, recall_score

winedata = pd.read_csv("C:/Users/Mayank/Desktop/Sem6/MachineLearning/Programs/WineQT.csv")

X = winedata.drop('quality', axis = 1)
y = winedata['quality']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state =42, stratify=y)
knn = KNeighborsClassifier()

k_range = range(1,11)
p_range = range(1,3)
weight = ['uniform','distance']

param_grid = dict(n_neighbors=k_range, p=p_range, weights=weight)

grid = GridSearchCV(knn, param_grid, cv=5, scoring='accuracy')

grid_search = grid.fit(X_train, y_train)


print("best parameters:", grid_search.best_params_) 

best_k=grid_search.best_estimator_.get_params()['n_neighbors']
best_p=grid_search.best_estimator_.get_params()['p']
best_weight=grid_search.best_estimator_.get_params()['weights']

print(f"best_k: {best_k}")
print(f"best_p: {best_p}")
print(f"best_weight: {best_weight}")

knn = KNeighborsClassifier(n_neighbors=best_k, weights=best_weight, p=best_p)
knn.fit(X_train, y_train)

y_pred = knn.predict(X_test)
test_accuracy = accuracy_score(y_test, y_pred)*100

print(f"\ntest accuracy for our dataset is: {test_accuracy}")

precision = precision_score(y_test, y_pred, average="weighted", zero_division=0)
print(f"\nprecision: {precision}")

recall = recall_score(y_test, y_pred, average="weighted", zero_division=0)
print(f"recall: {recall}")

f1_score = f1_score(y_test, y_pred, average="weighted", zero_division=0)
print(f"f1_score: {f1_score}")

