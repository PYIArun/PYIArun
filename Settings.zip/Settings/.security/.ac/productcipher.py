def caesar_substitution_encrypt(plaintext, shift):
    ciphertext = ''
    for char in plaintext:
        if char.isalpha():
            if char.islower():
                ciphertext += chr((ord(char) - ord('a') + shift) % 26 + ord('a'))
            else:
                ciphertext += chr((ord(char) - ord('A') + shift) % 26 + ord('A'))
        else:
            ciphertext += char
    return ciphertext

def caesar_substitution_decrypt(ciphertext, shift):
    plaintext = ''
    for char in ciphertext:
        if char.isalpha():
            if char.islower():
                plaintext += chr((ord(char) - ord('a') - shift) % 26 + ord('a'))
            else:
                plaintext += chr((ord(char) - ord('A') - shift) % 26 + ord('A'))
        else:
            plaintext += char
    return plaintext

# Python3 program to illustrate
# Rail Fence Cipher Encryption
# and Decryption
 
# function to encrypt a message
def rail_fence_transposition_encrypt(text, key):
 
    # create the matrix to cipher
    # plain text key = rows ,
    # length(text) = columns
    # filling the rail matrix
    # to distinguish filled
    # spaces from blank ones
    rail = [['\n' for i in range(len(text))]
                for j in range(key)]
     
    # to find the direction
    dir_down = False
    row, col = 0, 0
     
    for i in range(len(text)):
         
        # check the direction of flow
        # reverse the direction if we've just
        # filled the top or bottom rail
        if (row == 0) or (row == key - 1):
            dir_down = not dir_down
         
        # fill the corresponding alphabet
        rail[row][col] = text[i]
        col += 1
         
        # find the next row using
        # direction flag
        if dir_down:
            row += 1
        else:
            row -= 1
    # now we can construct the cipher
    # using the rail matrix
    result = []
    for i in range(key):
        for j in range(len(text)):
            if rail[i][j] != '\n':
                result.append(rail[i][j])
    return("" . join(result))
     
# This function receives cipher-text
# and key and returns the original
# text after decryption
def rail_fence_transposition_decrypt(cipher, key):
 
    # create the matrix to cipher
    # plain text key = rows ,
    # length(text) = columns
    # filling the rail matrix to
    # distinguish filled spaces
    # from blank ones
    rail = [['\n' for i in range(len(cipher))]
                for j in range(key)]
     
    # to find the direction
    dir_down = None
    row, col = 0, 0
     
    # mark the places with '*'
    for i in range(len(cipher)):
        if row == 0:
            dir_down = True
        if row == key - 1:
            dir_down = False
         
        # place the marker
        rail[row][col] = '*'
        col += 1
         
        # find the next row
        # using direction flag
        if dir_down:
            row += 1
        else:
            row -= 1
             
    # now we can construct the
    # fill the rail matrix
    index = 0
    for i in range(key):
        for j in range(len(cipher)):
            if ((rail[i][j] == '*') and
            (index < len(cipher))):
                rail[i][j] = cipher[index]
                index += 1
         
    # now read the matrix in
    # zig-zag manner to construct
    # the resultant text
    result = []
    row, col = 0, 0
    for i in range(len(cipher)):
         
        # check the direction of flow
        if row == 0:
            dir_down = True
        if row == key-1:
            dir_down = False
             
        # place the marker
        if (rail[row][col] != '*'):
            result.append(rail[row][col])
            col += 1
             
        # find the next row using
        # direction flag
        if dir_down:
            row += 1
        else:
            row -= 1
    return("".join(result))


def product_cipher_encrypt(plaintext, caesar_shift, rail_fence_rails):
    # Apply Caesar substitution encryption
    intermediate_text = caesar_substitution_encrypt(plaintext, caesar_shift)
    
    # Apply rail fence transposition encryption
    ciphertext = rail_fence_transposition_encrypt(intermediate_text, rail_fence_rails)
    
    return ciphertext

def product_cipher_decrypt(ciphertext, caesar_shift, rail_fence_rails):
    # Reverse rail fence transposition decryption
    intermediate_text = rail_fence_transposition_decrypt(ciphertext, rail_fence_rails)
    
    # Reverse Caesar substitution decryption
    plaintext = caesar_substitution_decrypt(intermediate_text, caesar_shift)
    
    return plaintext

# Example usage Substitution_Transposition
plaintext = input("Enter Plain text for performing Product Cipher  :- ")
caesar_shift = int(input("Enter shift key for Substitution caesar_cipher :- "))
rail_fence_rails = int(input("Enter Rail_fence key for Transposition Rail_fence :- "))

# Encrypt the plaintext using product cipher
encrypted_text = product_cipher_encrypt(plaintext, caesar_shift, rail_fence_rails)
print("Encrypted text:", encrypted_text)

# Decrypt the ciphertext
decrypted_text = product_cipher_decrypt(encrypted_text, caesar_shift, rail_fence_rails)
print("Decrypted text:", decrypted_text)
