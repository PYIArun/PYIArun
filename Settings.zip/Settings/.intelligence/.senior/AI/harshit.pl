reverse([],[]).
reverse([H|T],R):-reverse(T,R1),append(R1,[H],R).

palindrome([]).
palindrome([_]).
palindrome(L):-append([First|Middle],[Last],L),First=:=Last,palindrome(Middle).

sum([],0).
sum([H|T],S):-sum(T,R),S is H+R.

evenList(L):-length(L,L1),L1 mod 2 =:=0.
oddList(L):-length(L,L1),L1 mod 2 =:=1.

read_number(N):-write("Enter the number: "),read(N).
read_list(X):-write("Enter the list: "),read(X).

nth_ele(1,[H|_],H).
nth_ele(N,[_|L],S):-N1 is N-1,nth_ele(N1,L,S).

max([L],L).
max([H|T],X):-max(T,X1),(H>X1 -> X=H;X=X1).
insert(I,1,L,[I|L]).
insert(_,_,[],[]).
insert(I,N,[H|T],[H|R]):-N1 is N-1,insert(I,N1,T,R).

delete(1,[_|T],T).
delete(N,[H|T],[H|R]):-N1 is N-1,delete(N1,T,R).

merge1([],L,L).
merge1(L,[],L).
merge1([H|T],[H1|T1],[H1|R]):-H>=H1,merge([H|T],T1,R).
merge1([H|T],[H1|T1],[H|R]):-H1>=H,merge(T,[H1|T1],R).
sum_two:-read_list(L),read_list(N),merge(N,L,R),write(R).
