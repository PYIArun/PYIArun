#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Feb 10 12:27:55 2024

@author: baljeetkaur
"""


'''
The example below defines a small 3×2 matrix, 
centers the data in the matrix, 
calculates the covariance matrix of the centered data,
and then the eigendecomposition of the covariance matrix. 
The eigenvectors and eigenvalues are taken as the principal components
and the scale and 
used to project the original data.
'''

from numpy import array
from numpy import mean
from numpy import cov
from numpy.linalg import eig

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
#L=load_iris()
A, y = load_iris(return_X_y=True)

#mean(A, axis=0) or 
     
M = mean(A.T, axis=1)
print(M)
# center columns by subtracting column means
A1 = A - M
print(A1)
# calculate covariance matrix of centered matrix
C = cov(A1.T)
print(C)
# eigendecomposition of covariance matrix
values, vectors = eig(C)
print(vectors)
print(values)
# project data
P = vectors.T.dot(A1.T)
print(P.T)
newA=P.T

(values[0]+values[1])/sum(values)


gnb = GaussianNB()
model= gnb.fit(A1, y)
y_pred=model.predict(A1)
from sklearn.metrics import accuracy_score
accuracy_score(y, y_pred)

gnb = GaussianNB()
model= gnb.fit(newA[:,:3], y)
y_pred=model.predict(newA[:,:3])
from sklearn.metrics import accuracy_score
accuracy_score(y, y_pred)



X_train, X_test, y_train, y_test = train_test_split(A1, y, test_size=0.2,random_state=0)
gnb = GaussianNB()
model= gnb.fit(X_train, y_train)
y_pred=model.predict(X_test)
from sklearn.metrics import accuracy_score
accuracy_score(y_test, y_pred)



