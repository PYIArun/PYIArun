% Q14. Nth element of the list

% Base case: The Nth element of a list is its head when N is 1
nth_element(1, [X|_], X).

% Recursive rule: To find the Nth element, decrement N and consider the tail of the list
nth_element(N, [_|Tail], X) :-
    N > 1,
    N1 is N - 1,
    nth_element(N1, Tail, X).
% Example usage:
% nth_element(3, [1, 2, 3, 4, 5], X).
