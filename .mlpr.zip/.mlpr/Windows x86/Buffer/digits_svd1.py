# -*- coding: utf-8 -*-
"""
Created on Thu Feb 22 14:02:05 2024

@author: 
"""

from sklearn.decomposition import TruncatedSVD
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.naive_bayes import GaussianNB
import pandas as pd
import numpy as np
from scipy.linalg import svd
from sklearn.datasets import load_digits
from numpy.linalg import svd
digits = load_digits()
digits.keys()


x, y = digits.data, digits.target
scaler = StandardScaler()
x_scaled = scaler.fit_transform(x)
x_scaled
x_train, x_test, y_train, y_test = train_test_split(
    x_scaled, y, test_size=0.2, random_state=0)

gnb = GaussianNB()


svd_accuracy = []

for i in range(x_scaled.shape[1]):
    svd = TruncatedSVD(n_components=i+1)
    svd.fit(x_scaled)
    result = svd.transform(x_scaled)
    x_train, x_test, y_train, y_test = train_test_split(
        result, y, test_size=0.2, random_state=0)
    model = gnb.fit(x_train, y_train)
    y_pred = model.predict(x_test)
    accuracy = accuracy_score(y_test, y_pred)
    svd_accuracy.append(accuracy)
    
    '''model.fit(x_train,y_train)
   Acc= model.score(x_test,y_test)'''
print(svd_accuracy)
print(accuracy)


df = pd.read_excel('3462_devratan.xlsx')

# Create a new column with some data
Acc=svd_accuracy[:29]
df['svd_accuracy'] = Acc
print(df['svd_accuracy'])
# Save the updated DataFrame back to the Excel file
df.to_excel('3462_devratan.xlsx', index=False)
#df = pd.DataFrame({'Features' :pd.Series(Feat),'Information':pd.Series(Info), 'Accuracy':pd.Series(Accuracy)})
print(svd_accuracy)

df
print("SUCCESSFULLY EXPORTED")
