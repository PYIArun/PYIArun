% Base case: Inserting into the 1st position results in a list with I at the head
insert_nth(I, 1, L, [I|L]).

% Recursive rule: Insert I into the Nth position of the tail of the list
insert_nth(I, N, [X|Tail], [X|R]) :-
    N > 1,
    N1 is N - 1,
    insert_nth(I, N1, Tail, R).
% Example usage:
% insert_nth(100, 3, [1, 2, 3, 4, 5], Result).
