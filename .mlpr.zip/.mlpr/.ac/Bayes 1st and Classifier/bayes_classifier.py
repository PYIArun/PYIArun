#Bayes Classifier


from sklearn.datasets import make_blobs
from scipy.stats import norm
from numpy import mean
from numpy import std
from sklearn.naive_bayes import GaussianNB

def fit_distribution(data):
    mu = mean(data)
    sigma = std(data)
    print(mu, sigma)
    
    
    #fit distribution
    dist = norm (mu, sigma)
    return dist


#independent conditional probability

def probability(X, prior, dist1, dist2):
    return prior * dist1.pdf(X[0]) * dist2.pdf(X[1])


#generate 2d classification dataset
X, y = make_blobs(n_samples=100, centers=3, n_features=2, random_state =1, cluster_std= 2)


from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt


plt.scatter(X[:,0], X[:, 1], c=y)

Xy0=X[y==0]
Xy1=X[y==1]
Xy2=X[y==2]
#caluculate_priors 
priory0=len(Xy0)/len(X)
priory1=len(Xy1)/len(X)
priory2=len(Xy2)/len(X)
#create PDFS for y==0

distX1y0=fit_distribution(Xy0[:,0])
distX2y0=fit_distribution(Xy0[:,1])

#create PDFS for y==1

distX1y1=fit_distribution(Xy1[:,0])
distX2y1=fit_distribution(Xy1[:,1])


#create PDFS for y==1

distX1y2=fit_distribution(Xy2[:,0])
distX2y2=fit_distribution(Xy2[:,1])

#classify the example

print("For Sample lies in class 0")
print()
Xsample,ysample=X[0],y[0]
py0=probability(Xsample, priory0, distX1y0, distX2y0)
py1=probability(Xsample,priory1,distX1y1,distX2y1)
py2=probability(Xsample,priory2,distX1y2,distX2y2)

print('P(y=0/%s)=%.3f'%(Xsample,py0*100))
print('P(y=1/%s)=%.3f'%(Xsample,py1*100))
print('P(y=2/%s)=%.3f'%(Xsample,py2*100))


print('Truth:y=%d'%ysample)
print()
print()


print("For Sample lies in class 1")
print()
Xsample,ysample=X[1],y[1]
py0=probability(Xsample, priory0, distX1y0, distX2y0)
py1=probability(Xsample,priory1,distX1y1,distX2y1)
py2=probability(Xsample,priory2,distX1y2,distX2y2)

print('P(y=0/%s)=%.3f'%(Xsample,py0*100))
print('P(y=1/%s)=%.3f'%(Xsample,py1*100))
print('P(y=2/%s)=%.3f'%(Xsample,py2*100))


print('Truth:y=%d'%ysample)

print("For Sample lies in class 2")
print()
print()
Xsample,ysample=X[4],y[4]
py0=probability(Xsample, priory0, distX1y0, distX2y0)
py1=probability(Xsample,priory1,distX1y1,distX2y1)
py2=probability(Xsample,priory2,distX1y2,distX2y2)

print('P(y=0/%s)=%.3f'%(Xsample,py0*100))
print('P(y=1/%s)=%.3f'%(Xsample,py1*100))
print('P(y=2/%s)=%.3f'%(Xsample,py2*100))


print('Truth:y=%d'%ysample)


for i in range(0,100):
    Xsample,ysample=X[i],y[i]
    py0=probability(Xsample, priory0, distX1y0, distX2y0)
    py1=probability(Xsample,priory1,distX1y1,distX2y1)
    py2=probability(Xsample,priory2,distX1y2,distX2y2)

    print('P(y=0/%s)=%.3f'%(Xsample,py0*100))
    print('P(y=1/%s)=%.3f'%(Xsample,py1*100))
    print('P(y=2/%s)=%.3f'%(Xsample,py2*100))


    print('Truth:y=%d'%ysample)
    
    
model = GaussianNB()
    
#cluster value 2

model.fit(X, y)
Xsample, ysample = [X[0]], y[0]  

yhat_prob = model.predict_proba(Xsample)
print('Predicted Probabilities: ', yhat_prob)
yhat_class = model.predict(Xsample)
print('Predicted Class: ', yhat_class)
print('Truth: y=%d' % ysample)


yhat_class_all = model.predict(X)
print('Predicted Class: ', yhat_class_all)

overall_accuracy = 100 * accuracy_score(yhat_class_all, y)
print('Overall Accuracy: %.2f%%' % overall_accuracy)


#cluster value 7
X, y = make_blobs(n_samples=100, centers=3, n_features=2, random_state =1, cluster_std= 7)


model = GaussianNB()
model.fit(X, y)

print('Predicted Probabilities: ', yhat_prob)
yhat_class = model.predict(Xsample)
print('Predicted Class: ', yhat_class)
print('Truth: y=%d' % ysample)


yhat_class_all = model.predict(X)
print('Predicted Class: ', yhat_class_all)

overall_accuracy = 100 * accuracy_score(yhat_class_all, y)
print('Overall Accuracy: %.2f%%' % overall_accuracy)


#cluster value 12
X, y = make_blobs(n_samples=100, centers=3, n_features=2, random_state=1, cluster_std=12)

model = GaussianNB()

model.fit(X, y)


yhat_class = model.predict(Xsample)
print('Predicted Class: ', yhat_class)
print('Truth: y=%d' % ysample)

yhat_class_all = model.predict(X)
print('Predicted Class: ', yhat_class_all)

overall_accuracy = 100 * accuracy_score(yhat_class_all, y)
print('Overall Accuracy: %.2f%%' % overall_accuracy)
