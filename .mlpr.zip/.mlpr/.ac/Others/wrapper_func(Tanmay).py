# -*- coding: utf-8 -*-
"""
Created on Thu Feb  8 21:42:23 2024

@author: TANMAY
"""

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score
import pandas as pd
from itertools import zip_longest

L=load_iris()
X, y = load_iris(return_X_y=True)
newx=pd.DataFrame(X)
# X[:,0]

features=[0,1,2,3]

acc_lis_1=[]
for i in features:
    PassX=X[:,i]
    gnb=GaussianNB()
    X_train, X_test, y_train, y_test = train_test_split(PassX.reshape(-1,1),y, test_size=0.2 ,stratify=y)
    gnb.fit(X_train,y_train)
    y_pred=gnb.predict(X_test)
    acc_lis_1.append(accuracy_score(y_test,y_pred))

max_ind_1=acc_lis_1.index(max(acc_lis_1))
features.remove(max_ind_1)

acc_lis_2=[]
for i in features:
    PassX=X[:,[max_ind_1,i]]
    gnb=GaussianNB()
    X_train, X_test, y_train, y_test = train_test_split(PassX,y, test_size=0.2 ,stratify=y)
    gnb.fit(X_train,y_train)
    y_pred=gnb.predict(X_test)
    acc_lis_2.append(accuracy_score(y_test,y_pred))
    
    
max_ind_2=acc_lis_2.index(max(acc_lis_2))
features.remove(max_ind_2)

acc_lis_3=[]
for i in features:
    PassX=X[:,[max_ind_1,max_ind_2,i]]
    gnb=GaussianNB()
    X_train, X_test, y_train, y_test = train_test_split(PassX,y, test_size=0.2 ,stratify=y)
    gnb.fit(X_train,y_train)
    y_pred=gnb.predict(X_test)
    acc_lis_3.append(accuracy_score(y_test,y_pred))   
    
max_ind_3=acc_lis_3.index(max(acc_lis_3))
features.remove(max_ind_3)

acc_lis_4=[]
for i in features:
    PassX=X[:,[max_ind_1,max_ind_2,max_ind_3,i]]
    gnb=GaussianNB()
    X_train, X_test, y_train, y_test = train_test_split(PassX,y, test_size=0.2 ,stratify=y)
    gnb.fit(X_train,y_train)
    y_pred=gnb.predict(X_test)
    acc_lis_4.append(accuracy_score(y_test,y_pred))
    
# max_length = max(len(acc_lis_3), len(acc_lis_2), len(acc_lis_1),len(acc_lis_4))

# data = {
#     'Pass1': list(zip_longest(acc_lis_1, fillvalue=None)), 
#     'Pass2': list(zip_longest(acc_lis_2, fillvalue=None,total=max_length)),
#     'Pass3': list(zip_longest(acc_lis_3, fillvalue=None,total=max_length)),
#     'Pass4': list(zip_longest(acc_lis_4, fillvalue=None,total=max_length))
# }

# df = pd.DataFrame(acc_lis_1)
# d2 = pd.DataFrame(acc_lis_2)
# d3 = pd.DataFrame(acc_lis_3)
# d4 = pd.DataFrame(acc_lis_4)
# df.to_excel('C:/Users/TANMAY/Desktop/TANMAY/python/wrapper_excel.xlsx',index=False,engine='xlsxwriter')
# d2.to_excel('C:/Users/TANMAY/Desktop/TANMAY/python/wrapper_excel.xlsx',index=False,engine='xlsxwriter')


# Create a DataFrame with lists of different lengths
# df = pd.DataFrame({
#     'Column1': acc_lis_1 + [None] * (max(len(acc_lis_2), len(acc_lis_3), len(acc_lis_4)) - len(acc_lis_1)),
#     'Column2': acc_lis_2 + [None] * (max(len(list1), len(list3), len(list4)) - len(acc_lis_1)),
#     'Column3': acc_lis_3 + [None] * (max(len(list1), len(list2), len(list4)) - len(list3)),
#     'Column4': acc_lis_4 + [None] * (max(len(list1), len(list2), len(list3)) - len(list4))
# })



