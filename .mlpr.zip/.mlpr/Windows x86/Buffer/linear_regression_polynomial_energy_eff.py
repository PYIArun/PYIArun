# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 07:30:53 2024

@author:
"""
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
data = pd.read_csv("C:/Users/91931/Desktop/MLprograms/linear_regression/energy_efficiency_data.csv",header=None) #read from dataset
x = data.iloc[1:,:8].values # read first two column
y= data.iloc[1:,8:9].values # read target column
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

#y=pd.DataFrame(Y)
#x=pd.DataFrame(X)
scaler = StandardScaler()
x_scaled = scaler.fit_transform(x) 
x_scaled

#knn=KNeighborsRegressor(n_neighbors=2)



pca=PCA(n_components=2)
x_scaled_pca=pca.fit_transform(x_scaled)
x_scaled_pca.shape
x_scaled_pca
pca.explained_variance_ratio_

pca.n_components_
model = LinearRegression()
model.fit(x_scaled_pca, y)
y_pred = model.predict(x_scaled_pca)
rmse = mean_squared_error(y, y_pred)
r2 = r2_score(y, y_pred)
print('Root mean squared error: ', rmse)
print('R2 score: ', r2)
x_train, x_test, y_train, y_test = train_test_split(x_scaled_pca, y, test_size = 0.2,random_state=0)
#linear regression
'''plt.scatter(y, y_pred, s=10)
plt.plot(x, y_pred, color='r')
plt.show()'''
degrees=[1,2,3,4,5,6,7,8,9,10]
train_error,test_error,r2_train,r2_test=[],[],[],[]

#polynomial fit
for i in  degrees:
    polynomial_features= PolynomialFeatures(degree=i)

    x_train_poly = polynomial_features.fit_transform(x_train)
    x_test_poly = polynomial_features.fit_transform(x_test)
    model = LinearRegression()
    model.fit(x_train_poly,y_train)
    model.fit(x_test_poly,y_test)
    y_train_pred = model.predict(x_train_poly)
    y_test_pred=model.predict(x_test_poly)
    Train_error = (mean_squared_error(y_train,y_train_pred))
    Train_r2 = r2_score(y_train,y_train_pred)
    
    Test_error = (mean_squared_error(y_test,y_test_pred))
    Test_r2 = r2_score(y_test,y_test_pred)
    train_error.append(Train_error)
    test_error.append(Test_error)
    r2_train.append(Train_r2)
    r2_test.append(Test_r2)


train_error
test_error
r2_train
r2_test
plt.scatter(degrees, test_error, s=10)
plt.scatter(degrees,train_error,s=10)
plt.plot(degrees,train_error,label='train_error')
plt.plot(degrees,test_error,label='test_error')

plt.xlabel('degrees')
plt.ylabel('mse')
plt.legend()

plt.scatter(degrees, r2_train, s=10)
plt.scatter(degrees,r2_test,s=10)
plt.plot(degrees,r2_train,label='train_r2')
plt.plot(degrees,r2_test,label='test_r2')

plt.legend()
# sort the values of x before line plot
#sort as per this method 


