% Q13. Even length or Odd length
evenLength(L) :-
    length(L, Len),
    Len mod 2 =:= 0.

oddLength(L) :-
    length(L, Len),
    Len mod 2 =:= 1.

