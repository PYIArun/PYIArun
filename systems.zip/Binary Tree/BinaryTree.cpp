#include <iostream>
#include <vector>
using namespace std;

template <class T> 
class TNode{

    public:

    TNode *left;
    T data;
    TNode *right;

    TNode(){
        data = 0;
        left = nullptr;
        right = nullptr;
    }

    TNode(T x){
        data = x;
        left = nullptr;
        right = nullptr;
    }
};

template <class T> 
class BinaryTree{
    public:

    TNode<T>* root;

    BinaryTree(){
        root = nullptr;
    }

    void insert(int value) {

        if(!root){
            root = new TNode<T>(value);
            return;
        }

        vector<TNode<T>*> intersectionPoints;
        findIntersectionPoints(root, intersectionPoints);

        if(intersectionPoints.empty()){
            cout<< "There are no available empty nodes to insert."<< endl;
            return;
        }

        cout<< "Available Intersection Points: ";
        for(int i =0 ; i<intersectionPoints.size(); i++){
            cout<< i+1<< " : "<< intersectionPoints[i]->data << endl;
        }

        cout<< "At which intersection point you want to insert (1- "<< intersectionPoints.size()<< ")";
        int selection;
        cin>> selection;

        if (selection < 1 || selection > intersectionPoints.size()) {
            cout << "Invalid selection. Aborting insertion." << endl;
            return;
        }
        TNode<T>* selectedNode = intersectionPoints[selection-1];


        char childSide;
        cout<< "Which side you wanna insert it: l for left child or r for right child? ";

        cin>> childSide;
        cout<<endl;
        if (childSide == 'l' || childSide=='L'){
            if(!selectedNode->left){
                selectedNode->left = new TNode<T>(value);
                return;
                cout<< "Element has been successfully inserted in the left.\n";
            }
            else{
                cout<< "Left is already filled. Kindly try on right or on another intersection point.";
                return;
            }
        }
        else if (childSide == 'r' || childSide=='R'){
            if(!selectedNode->right){
                selectedNode->right = new TNode<T>(value);
                return;
                cout<< "Element has been successfully inserted in the right.\n";
            }
            else{
                cout<< "Right is already filled. Kindly try on left or on another intersection point.";
                return;
            }
        }
        else{
            cout<< "Invalid Input. Please Try Again.";
            return;
        }
    }

    void findIntersectionPoints (TNode<T>* node, vector <TNode<T>*>& intersectionPoints){
        if(node){

            if(!node->left || !node->right){
                intersectionPoints.push_back(node);
            }

            findIntersectionPoints(node->left, intersectionPoints);
            findIntersectionPoints(node->right, intersectionPoints);
        }
    }

    void print(TNode<T>* node){
        if(node){
            cout<< node->data<< " ";
            print(node->left);
            print(node->right);
        }
    }

};
 


int main(){
    cout<< "**************** Binary Tree Construction ****************";
    cout<< endl;

    BinaryTree<int> tree;
    char option;
    do{ 
        int element;
        cout<< "Enter the element, you want to insert:";
        cin>> element;
        tree.insert(element);

        cout<< "Do you want to continue inserting : y for yes and n for no: ";

        cin>>option;
    }while(option == 'y');


    tree.print(tree.root);

    return 0;
}


/*
Outline:
    Base Case mein: root node mein insert hoga
    Different cases:
        User entered a element, now, we'll show him all the elements with atleast (one child is empty), 
        and ask him which node he want to insert on and which child should be the inserted element.
        if that child already exists, abort the operation.

        If he selects a node, then we'll traverse to that node, and insert the element in the desired child location.


*/