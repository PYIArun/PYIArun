# -*- coding: utf-8 -*-
"""
Created on Thu Mar 21 15:26:17 2024

@author: 
"""

# logistic regression for multi-class classification using built-in one-vs-rest
from sklearn.datasets import make_classification
from sklearn.linear_model import LogisticRegression
from sklearn import datasets
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import LabelEncoder
import pandas as pd
# define dataset

data=pd.read_csv("C:/Users/91931/Desktop/MLprograms/loistic_regression/Dry_Bean_Dataset.csv")
x=data.iloc[:,:-1]
y = data.iloc[:,16]
# Initialize LabelEncoder
label_encoder = LabelEncoder()

# Fit and transform the data
y = label_encoder.fit_transform(y)

# Print the encoded data
print(y)

Scaler=StandardScaler()
X=Scaler.fit_transform(x)

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=0)

# define model
model = LogisticRegression(multi_class='ovr')
# fit model
model.fit(x_train, y_train)
# make predictions
yhat = model.predict(x_test)
scr = model.score( x_test,y_test)
print(scr)

from sklearn.multiclass import OneVsRestClassifier
# define model
model = LogisticRegression()
# define the ovr strategy
ovr = OneVsRestClassifier(model)
# fit model
ovr.fit(x_train, y_train)
# make predictions
yhat = ovr.predict(x_test)

score = ovr.score(x_test,y_test)
print(score)




# SVM for multi-class classification using one-vs-one
from sklearn.datasets import make_classification

from sklearn.multiclass import OneVsOneClassifier
# define model
model = LogisticRegression()
# define ovo strategy
ovo = OneVsOneClassifier(model)
# fit model
ovo.fit(X, y)
# make predictions
yhat = ovo.predict(X)

score = ovo.score(x_test,y_test)
print(score)

