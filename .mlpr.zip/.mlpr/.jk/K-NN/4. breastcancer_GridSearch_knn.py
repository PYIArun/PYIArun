# -*- coding: utf-8 -*-
"""
Created on Wed Oct 13 22:36:49 2021

@author: BALJEET KAUR
"""

from sklearn import datasets

from sklearn.model_selection import GridSearchCV
from sklearn.neighbors import KNeighborsClassifier
from sklearn import metrics
from sklearn.model_selection import train_test_split
breast_cancer = datasets.load_breast_cancer()

X = breast_cancer.data
y = breast_cancer.target

x_train, x_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 0)
knn = KNeighborsClassifier()

#Sample 1

k_range = list(range(1, 6))
param_grid = dict(n_neighbors=k_range)
grid = GridSearchCV(knn, param_grid, cv=10, scoring='accuracy')
# fitting the model for grid search
grid_search=grid.fit(x_train, y_train)
print(grid_search.best_params_) 

knn = KNeighborsClassifier(n_neighbors=4)

knn.fit(x_train, y_train)

y_test_hat=knn.predict(x_test) 

test_accuracy=metrics.accuracy_score(y_test,y_test_hat)*100

print("Accuracy for our testing dataset with tuning is : {:.2f}%".format(test_accuracy) )




#Sample 2 with more than one parametr to be grid searched

k_range = list(range(1, 6))
weight = ['uniform', 'distance']
ps=[1,2]
param_grid = dict(n_neighbors=k_range,weights=weight,p=ps)
grid = GridSearchCV(estimator, param_grid)hCV(knn, param_grid, cv=10, scoring='accuracy')
# fitting the model for grid search
grid_search=grid.fit(x_train, y_train)
print(grid_search.best_params_) 

print('Best K neighbours:', grid_search.best_estimator_.get_params()['n_neighbors'])
print('Best weight:', grid_search.best_estimator_.get_params()['weights'])
print('Beat P value:',grid_search.best_estimator_.get_params()['p'])
best_k=grid_search.best_estimator_.get_params()['n_neighbors'];
best_w=grid_search.best_estimator_.get_params()['weights'];
best_p=grid_search.best_estimator_.get_params()['p'];

knn = KNeighborsClassifier(n_neighbors=best_k,weights=best_w,p=best_p);

knn.fit(x_train, y_train)

y_test_hat=knn.predict(x_test) 

test_accuracy=metrics.accuracy_score(y_test,y_test_hat)*100

print("Accuracy for our testing dataset with tuning is : {:.2f}%".format(test_accuracy) )
