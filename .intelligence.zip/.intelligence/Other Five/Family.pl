% Define parent relationships
parent(john, alice).
parent(john, bob).
parent(mary, alice).
parent(mary, bob).
parent(alice, carol).
parent(alice, david).
parent(bob, emily).
parent(bob, fred).
parent(david, george).
parent(emily, helen).

% Define predecessor relationship
predecessor(X, Y) :-
    parent(X, Y).
predecessor(X, Y) :-
    parent(X, Z)
    predecessor(Z, Y).
