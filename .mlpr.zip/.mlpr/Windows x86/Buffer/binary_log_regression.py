# -*- coding: utf-8 -*-
"""
Created on Thu Mar 21 07:21:47 2024

@author: 
"""


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import scipy.optimize as opt
from sklearn.preprocessing import StandardScaler


data=pd.read_csv("C:/Users/91931/Desktop/MLprograms/loistic_regression/diabetes.csv")
x = data.iloc[:,:-1]
y = data.iloc[:,8]

Scaler=StandardScaler()
x_scaled=Scaler.fit_transform(x)

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x_scaled, y, test_size=0.25)

(m, n) = x.shape
x_stacked = np.hstack((np.ones((m,1)), x_scaled))
theta = np.zeros((n+1,1))
y_pred=[]
np.dot(x_stacked, theta)
y=np.array(y).reshape(y.shape[0],1)


#hypothesis
def sigmoid(x):
  return 1/(1+np.exp(-x))



def costFunction(theta, X, y):
    J = (-1/m) * np.sum(np.multiply(y, np.log(sigmoid(X @ theta))) 
        + np.multiply((1-y), np.log(1 - sigmoid(X @ theta))))
    return J  

def accuracy(X, y, theta, cutoff):
    pred = [sigmoid(np.dot(X, theta)) >= 0.5]
    acc = np.mean(pred == y)
    print(acc * 100)
    
def gradient(theta, X, y):
    return ((1/m) * X.T @ (sigmoid(X @ theta) - y))
J = costFunction(theta, x_stacked, y)
print(J)

temp = opt.fmin_tnc(func = costFunction, 
                    x0 = theta.flatten(),fprime = gradient, 
                    args = (x_stacked, y.flatten()))
#the output of above function is a tuple whose first element #contains the optimized values of theta
theta_optimized = temp[0]


print(theta_optimized)

accuracy(x_stacked, y.flatten(), theta_optimized, 0.5)
    
Jo = costFunction(theta_optimized, x_stacked, y)
print("cost after optimizing theta",J)
#for j in range(768):
 #   y_pred = [sigmoid(np.dot(x_stacked, theta_optimized)) >= 0.5]
   