#include <iostream>

using namespace std;

// Function to transpose a 2-D matrix
// To: Compute the transpose of the given matrix
// Input:
//   - int matrix[][]: 2-D matrix to be transposed
//   - int rows: Number of rows in the matrix
//   - int cols: Number of columns in the matrix
// Output:
//   - None
// Approach:
//   - Create a new matrix with swapped rows and columns.
//   - Copy the elements from the original matrix to the transposed matrix.

void transpose_matrix(int** matrix, int rows, int cols) {
    int** transposed = new int*[cols];
    for (int i = 0; i < cols; ++i) {
        transposed[i] = new int[rows];
    }

    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            transposed[j][i] = matrix[i][j];
        }
    }

    cout << "Transposed matrix:" << endl;
    for (int i = 0; i < cols; ++i) {
        for (int j = 0; j < rows; ++j) {
            cout << transposed[i][j] << " ";
        }
        cout << endl;
    }

    for (int i = 0; i < cols; ++i) {
        delete[] transposed[i];
    }
    delete[] transposed;
}

int main() {
    int rows, cols;

    // Get the dimensions of the matrix from the user
    cout << "Enter the number of rows and columns: ";
    cin >> rows >> cols;

    int** matrix = new int*[rows];
    for (int i = 0; i < rows; ++i) {
        matrix[i] = new int[cols];
    }

    cout << "Enter the elements of the matrix:" << endl;
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            cin >> matrix[i][j];
        }
    }

    transpose_matrix(matrix, rows, cols);

    for (int i = 0; i < rows; ++i) {
        delete[] matrix[i];
    }
    delete[] matrix;

    return 0;
}
