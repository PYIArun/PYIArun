% Q9. Concatenate two lists
concat([], L, L).

concat([X | T1], L2, [X | T]) :-
    concat(T1, L2, T).


