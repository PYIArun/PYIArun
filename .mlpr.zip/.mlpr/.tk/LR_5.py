# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 21:19:39 2024

@author: kripl
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score, mean_squared_error
from sklearn.linear_model import Ridge, RidgeCV

data = pd.read_csv('Real estate.csv')
data.columns
data.head
y = data['Y house price of unit area'] 
X = data.drop('Y house price of unit area', axis =1)
X = data.drop(['No','X1 transaction date','Y house price of unit area'], axis =1)


# y = np.array(y)
# X = np.array(X)

alphas = 10**np.linspace(10,-2,100)*0.5
alphas
ridge = Ridge() #standardize the variables to be on the same scale
coefs = []

for a in alphas:
    ridge.set_params(alpha = a)
    ridge.fit(X, y)
    coefs.append(ridge.coef_)
    
np.shape(coefs)


ax = plt.gca()
ax.plot(alphas, coefs)
ax.set_xscale('log')
plt.axis('tight')
plt.xlabel('alpha')
plt.ylabel('weights')

X_train, X_test , y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=1) 



#let lamda = 4
ridge2 = Ridge(alpha = 4)
ridge2.fit(X_train, y_train)            
pred2 = ridge2.predict(X_test)          
print(pd.Series(ridge2.coef_, index = X.columns))
print(mean_squared_error(y_test, pred2)) 
print(r2_score(y_test, pred2))        


#let lamda = very big
ridge3 = Ridge(alpha = 10**10)
ridge3.fit(X_train, y_train)            
pred3 = ridge3.predict(X_test)          
print(pd.Series(ridge3.coef_, index = X.columns)) 
print(mean_squared_error(y_test, pred3))
print(r2_score(y_test, pred3))          

#This resulted in a model with only the intercept, very large MSE


#let lambda=0 which is the full least squares 
ridge1 = Ridge(alpha = 0)
ridge1.fit(X_train, y_train)             # Fit a ridge regression on the training data
pred = ridge1.predict(X_test)            # Use this model to predict the test data
print(pd.Series(ridge1.coef_, index = X.columns)) # Print coefficients
print(mean_squared_error(y_test, pred))           # Calculate the test MSE
print(r2_score(y_test, pred))


#to find the best labda we do cross val

ridgecv = RidgeCV(alphas = alphas, scoring = 'neg_mean_squared_error')
ridgecv.fit(X_train, y_train)
ridgecv.alpha_



#Now let us investigate this lambda

ridge4 = Ridge(alpha = ridgecv.alpha_)
ridge4.fit(X_train, y_train)
mean_squared_error(y_test, ridge4.predict(X_test))
print(r2_score(y_test, ridge4.predict(X_test)))

#MSE decreased slightly


#Refit on full dataset
ridge4.fit(X, y)
pd.Series(ridge4.coef_, index = X.columns)


