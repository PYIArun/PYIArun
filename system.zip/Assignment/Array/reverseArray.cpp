// D. Write C++ code for a function that reverses the elements in an array without using any additional data structure.

#include <iostream>
using namespace std;


// Function to reverse an array in place
// To: Reverse the order of elements in an integer array
// Input:
//   - int arr[]: Array of integers to be reversed
//   - int size: Size of the array
// Output:
//   - None
// Approach:
//   - Use two pointers, one starting at the beginning and the other at the end of the array.
//   - Swap the elements at these pointers and move the pointers towards the center until they meet.
void reverseArray(int arr[], int n){

    int left = 0;
    int right = n-1;

    while(left < right){

        swap(arr[left], arr[right]);

        left++;
        right--;

    }


}


// Function to swap two integers by reference
// To: Swap the values of two integers
// Input:
//   - int &a: Reference to the first integer
//   - int &b: Reference to the second integer
// Output:
//   - None
// Approach:
//   - Use a temporary variable to hold the value of the first integer.
//   - Assign the value of the second integer to the first.
//   - Assign the value stored in the temporary variable to the second integer.
void swap(int &a, int &b){

    int temp = a;
    a = b;
    b= temp;

}
int main(){

    cout<<"Enter the size of array: ";
    int n;
    cin>>n;
    int *arr = new int[n];

    cout<< "Enter the elements of array: ";
    for(int i=0 ; i<n; i++){
        cin>> arr[i];
    }

    reverseArray(arr, n);

    
    cout<< "Array after get reversed: ";
    for(int i=0 ; i<n; i++){
        cout<< arr[i]<< " ";
    }
    return 0;
}
