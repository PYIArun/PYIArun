import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import MinMaxScaler, LabelEncoder


df = pd.read_csv('apple_quality.csv')

label_encoder = LabelEncoder()
df['Quality'] = label_encoder.fit_transform(df['Quality'])
df.dropna(inplace=True)

df.drop('A_id', axis=1, inplace=True)

# Define features and target
features = ['Size', 'Weight', 'Sweetness', 'Crunchiness', 'Juiciness', 'Ripeness', 'Acidity']
target = "Quality"

scaler = MinMaxScaler()
df_scaled = df.copy()
df_scaled[features] = scaler.fit_transform(df_scaled[features])


X = df_scaled[features]
y = df_scaled[target]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0)

gnb = GaussianNB()
gnb.fit(X_train, y_train)

y_test_hat = gnb.predict(X_test)
test_accuracy = accuracy_score(y_test, y_test_hat) * 100

print("Accuracy for the testing dataset without tuning: {:.2f}%".format(test_accuracy))

# Calculate correlations
correlations = df_scaled.corr()['Quality'].abs().sort_values(ascending=False)
selected_features = correlations.index[1:]  # Exclude 'Quality'

results_list = []

best_accuracy = 0
best_features = []

for k in range(1, len(selected_features) + 1):
    feature_subset = list(selected_features[:k])
    
    X_subset = df_scaled[feature_subset]
    
    X_train, X_test, y_train, y_test = train_test_split(X_subset, y, test_size=0.3, stratify=y, random_state=0)
    
    gnb = GaussianNB()
    model = gnb.fit(X_train, y_train)
    
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    
    results_list.append({'Features': str(feature_subset), 'Accuracy': accuracy * 100})
    
    if accuracy > best_accuracy:
        best_accuracy = accuracy
        best_features = feature_subset

    #print(f"Features: {feature_subset}, Accuracy: {accuracy * 100:.2f}%")

# Save results to Excel file
results_df = pd.DataFrame(results_list)
results_df.to_excel('appleQualityResults.xlsx', index=False)

print("\nBest Accuracy: {:.2f}%".format(best_accuracy * 100))
print("Best Feature Combination:", best_features)
