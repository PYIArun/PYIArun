#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Nov  7 13:31:55 2023

@author: baljeetkaur
"""

import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import train_test_split




np.random.seed(0)
X = 2 - 3 * np.random.normal(0, 1, 100)
y = X - 2 * (X ** 2) + 0.5 * (X ** 3) + np.random.normal(-20, 20, 100)
plt.scatter(X,y, s=10)
plt.show()


# transforming the data to include another axis
X = X[:, np.newaxis]
y = y[:, np.newaxis]


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2 )
plt.scatter(X_train, y_train, s=10)
plt.scatter(X_test, y_test, s=10,color='r')



#linear regression
model = LinearRegression()   #LOW TRAIN AND TESY
model.fit(X_train, y_train)
y_train_pred = model.predict(X_train)

rmse = mean_squared_error(y_train, y_train_pred)
r2 = r2_score(y_train, y_train_pred)

print(' mean squared error train: ', rmse)
print('R2 score train: ', r2)

y_test_pred = model.predict(X_test)

rmse = (mean_squared_error(y_test, y_test_pred))
r2 = r2_score(y_test, y_test_pred)

print(' mean squared error test: ', rmse)
print('R2 score  test: ', r2)


plt.scatter(X_test, y_test_pred, s=10,color='r')
plt.scatter(X_test, y_test, s=10,color='g')

plt.show()

###################poly
from sklearn.preprocessing import PolynomialFeatures

polynomial_features= PolynomialFeatures(degree=2)

x_train_poly = polynomial_features.fit_transform(X_train)
x_test_poly = polynomial_features.fit_transform(X_test)


model = LinearRegression()
model.fit(x_train_poly, y_train)




y_test_poly_pred = model.predict(x_test_poly)

mse = (mean_squared_error(y_test,y_test_poly_pred))
r2 = r2_score(y_test,y_test_poly_pred)
print(' mean squared error: ', mse)
print('R2 score: ', r2)

plt.scatter(X_test, y_test_poly_pred, s=10,color='r')
plt.scatter(X_test, y_test, s=10,color='g')

plt.show()



###################poly

from sklearn.preprocessing import PolynomialFeatures

polynomial_features= PolynomialFeatures(degree=3)

x_train_poly = polynomial_features.fit_transform(X_train)
x_test_poly = polynomial_features.fit_transform(X_test)


model = LinearRegression()
model.fit(x_train_poly, y_train)
y_test_poly_pred = model.predict(x_test_poly)

mse = (mean_squared_error(y_test,y_test_poly_pred))
r2 = r2_score(y_test,y_test_poly_pred)
print(' mean squared error: ', mse)
print('R2 score: ', r2)

plt.scatter(X_test, y_test_poly_pred, s=10,color='r')
plt.scatter(X_test, y_test, s=10,color='g')

plt.show()


###################poly

from sklearn.preprocessing import PolynomialFeatures

polynomial_features= PolynomialFeatures(degree=6)

x_train_poly = polynomial_features.fit_transform(X_train)
x_test_poly = polynomial_features.fit_transform(X_test)


model = LinearRegression()
model.fit(x_train_poly, y_train)
y_test_poly_pred = model.predict(x_test_poly)

mse = (mean_squared_error(y_test,y_test_poly_pred))
r2 = r2_score(y_test,y_test_poly_pred)
print('mean squared error: ', mse)
print('R2 score: ', r2)

plt.scatter(X_test, y_test_poly_pred, s=10,color='r')
plt.scatter(X_test, y_test, s=10,color='g')

plt.show()

