#include <iostream>
using namespace std;

// Function to traverse and print a 2-D matrix
// To: Print all elements of the given matrix
// Input:
//   - int matrix[][]: 2-D matrix to be traversed
//   - int rows: Number of rows in the matrix
//   - int cols: Number of columns in the matrix
// Output:
//   - None
// Approach:
//   - Use nested loops to iterate through each element of the matrix.
//   - Print each element as it is accessed.

void traverse_matrix(int** matrix, int rows, int cols) {
    cout << "Matrix elements:" << endl;
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            cout << matrix[i][j] << " ";
        }
        cout << endl;
    }
}

int main() {
    int rows, cols;

    cout << "Enter the number of rows and columns: ";
    cin >> rows >> cols;

    int** matrix = new int*[rows];
    for (int i = 0; i < rows; ++i) {
        matrix[i] = new int[cols];
    }

    cout << "Enter the elements of the matrix:" << endl;
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            cin >> matrix[i][j];
        }
    }

    traverse_matrix(matrix, rows, cols);

    for (int i = 0; i < rows; ++i) {
        delete[] matrix[i];
    }
    delete[] matrix;

    return 0;
}
