// B. write code C++ to Implement a function to rotate an array of integers by a 
// specified number of positions. 
// For example, rotate [1, 2, 3, 4, 5] by 2 positions to get [4, 5, 1, 2, 3]. 

#include<iostream>
using namespace std;

// Function to rotate an array of integers by a specified number of positions k.
// To: Rotate an array of integers by a specified number of positions k.
// Input:
//   - int arr[] : Array to be rotated
//   - int m: Size of the Array
//   - int k : Number of positions to rotate the array.
// Output:
//   - None
// Approach:
//   - Normalize the value of k to handle cases where k is larger than the size of the array.
//   - Use a temporary array to store the rotated values.
//   - Copy elements from the original array to the temporary array starting from the kth position.
//   - Copy the remaining elements from the start of the original array to the end of the temporary array.
//   - Copy the contents of the temporary array back to the original array.


void rotatebyK(int arr[], int n, int k){
    k = k%n;

    if (k==0) return;
    

    int *temp = new int[n];

    for(int i=0; i<n; i++){
        temp[(i+k) % n] = arr[i];
    }

    for(int i =0; i<n; i++){
        arr[i] = temp[i];
    }

    delete[] temp;
}


int main()
{   
    cout<< "Enter the size of array: ";
    int n;
    cin>>n;

    int arr[n];
    cout<<"Enter the elements of array: ";
    for(int i =0; i<n; i++){
        cin>>arr[i];
    }

    cout<< "Enter the position to rotate the array: ";
    int k ;
    cin>>k;

    rotatebyK(arr, n, k);

    cout<<"The Rotated Array looks like this: ";
    for(int i =0; i<n; i++){
        cout<< arr[i]<< " ";
    }


    return 0;
}