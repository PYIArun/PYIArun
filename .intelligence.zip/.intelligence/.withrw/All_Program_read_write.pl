% Q1
sum_two:-
    write('Enter the first number: '),
    read(Num1),
    write('Enter the second number: '),
    read(Num2),
    Result is Num1 + Num2,
    write('The sum is: '),
    write(Result).

% Q2 Max of two numbers
max :-
    write('Enter the first number: '),
    read(X),
    write('Enter the second number: '),
    read(Y),
    (X >= Y ->
        Max = X,
        !, % Cut here, so if X is greater than or equal to Y, no need to consider the other branch
        write('The maximum is: '), write(Max)
    ;
        Max = Y,
        write('The maximum is: '), write(Max)
    ),
    fail. % Fail to stop backtracking after finding the maximum.

% Q3 Factorial of a number
compute_factorial(0, 1) :- !.
compute_factorial(Num, Result) :-
    Num > 0,
    New_num is Num - 1,
    compute_factorial(New_num, Result2),
    Result is Num * Result2.

factorial :-
    write('Enter a number to find its factorial: '),
    read(Num),
    (Num >= 0 ->
        compute_factorial(Num, Result),
        write('The factorial of '), write(Num), write(' is: '), write(Result)
    ;
        write('Factorial is not defined for negative numbers.')
    ).


%Q4 Fibonacci sequence
nth_fibonacci(0, 0) :- !.
nth_fibonacci(1, 1) :- !.
nth_fibonacci(N, Result) :-
    N > 1,
    N1 is N - 1,
    N2 is N - 2,
    nth_fibonacci(N1, Result1),
    nth_fibonacci(N2, Result2),
    Result is Result1 + Result2.
fibonacci :-
    write('Enter the value of N to find Nth Fibonacci number: '),
    read(N),
    (N >= 0 ->
        nth_fibonacci(N, Result),
        write('The '), write(N), write('th Fibonacci number is: '), write(Result)
    ;
        write('Fibonacci sequence is not defined for negative numbers.')
    ).

%5
gcd_main :-
    write('Enter the first number: '),
    read(X),
    write('Enter the second number: '),
    read(Y),
    gcd(X, Y, G),
    write('The greatest common divisor of '), write(X), write(' and '), write(Y), write(' is '), write(G), nl.

gcd(X, 0, X) :-
    X > 0.

gcd(X, Y, G) :-
    Y > 0,
    Z is X mod Y,
    gcd(Y, Z, G).

% Q6 Power of a number
power :-
    write('Enter the base number: '),
    read(Num),
    write('Enter the exponent: '),
    read(Pow),
    compute_power(Num, Pow, Ans),
    write('The result of '), write(Num), write(' raised to the power of '), write(Pow), write(' is: '), write(Ans).

compute_power(_, 0, 1) :- !.
compute_power(Num, Pow, Ans) :-
    Pow > 0,
    Pow1 is Pow - 1,
    compute_power(Num, Pow1, Temp),
    Ans is Num * Temp.

% Q7 Multiplication of two no. by addition
multiply(0, _, 0).
multiply(X, Y, Z) :-
    X > 0,
    X1 is X - 1,
    multiply(X1, Y, Z1),
    sum(Z1, Y, Z).
sum(X, Y, Z) :-
    Z is X + Y.

multiply_main :-
    write('Enter the first number: '),
    read(X),
    write('Enter the second number: '),
    read(Y),
    multiply(X, Y, Z),
    write('The product of '), write(X), write(' and '), write(Y), write(' is '), write(Z), nl.



% Q8 Membership check
memb(X, [X|_]):- !.
memb(X, [_|T]) :-
    memb(X, T).
memb_main :-
    write('Enter an element: '),
    read(X),
    write('Enter a list: '),
    read(List),
    (memb(X, List) ->
        write('Yes, '), write(X), write(' is a member of the list.')
    ;
        write('No, '), write(X), write(' is not a member of the list.')
    ).

% Q9 Concatenation of two lists
conc([], L2, L2).
conc([X|L1], L2, [X|L3]) :-
    conc(L1, L2, L3).

conc :-
    write('Enter the first list: '),
    read(List1),
    write('Enter the second list: '),
    read(List2),
    conc(List1, List2, Result),
    write('The concatenated list is: '), write(Result).

% Q10 Reverse a list
revers([], []).
revers([X|RL], R) :-
    reverse(RL, RevXs),
    append(RevXs, [X], R).
reverse_list :-
    write('Enter a list to reverse: '),
    read(List),
    revers(List, Result),
    write('The reversed list is: '), write(Result).

% Q11 Check if a list is a palindrome
palindrome([]).
palindrome([_]).
palindrome([X|Xs]) :-
    append(Middle, [X], Xs),
    palindrome(Middle).
palindrome :-
    write('Enter a list to check if it is a palindrome: '),
    read(List),
    (palindrome(List) ->
        write('Yes, the list is a palindrome.')
    ;
        write('No, the list is not a palindrome.')
    ).

% Q12 Sum of elements in a list
compute_sumlist([], 0).
compute_sumlist([X|Rl], Sum) :-
    compute_sumlist(Rl, Sum1),
    Sum is X + Sum1.
sumlist :-
    write('Enter a list of numbers to find their sum: '),
    read(List),
    compute_sumlist(List, Sum),
    write('The sum of the list elements is: '), write(Sum).


% Q13 Check if the length of a list is even

list_even_len :-
    write('Enter a list to check if its length is even: '),
    read(List),
    (length(List, Len), 0 is Len mod 2 ->
        write('Yes, the length of the list is even.')
    ;
        write('No, the length of the list is odd.')
    ).

% Q14 Find the Nth element of a list
nth_element(_, [], _) :- fail.
nth_element(1, [X|_], X) :- !.
nth_element(N, [_|T], X) :-
    N > 1,
    N1 is N - 1,
    nth_element(N1, T, X1),
    X = X1,!.
nth_element :-
    write('Enter a list: '),
    read(List),
    write('Enter the position of the element to find: '),
    read(N),
    (nth_element(N, List, Element) ->
        write('The '), write(N), write('th element is: '), write(Element)
    ;
        write('Invalid position.')
    ).

%  Q15Find the maximum element in a list
maxlist([X],X).
maxlist([X|L],Max):-
    maxlist(L,Max1),
    Max is max(X,Max1).

maxlist :-
    write('Enter a list to find its maximum element: '),
    read(List),
    (maxlist(List, Max) ->
        write('The maximum element in the list is: '), write(Max)
    ;
        write('The list is empty.')
    ).

%Q16
insert_nth(I, 1, L, [I|L]) :-!.
insert_nth(_, N,_, _) :- N < 1,!,fail.
insert_nth(I, N, [H|T], [H|R]) :-
    N > 1,
    N1 is N - 1,
    insert_nth(I, N1, T, R),!.

insert_nth_main :-
    write('Enter the element to insert: '),
    read(Element),
    write('Enter the position to insert (N): '),
    read(Position),
    write('Enter the list: '),
    read(List),
    insert_nth(Element, Position, List, Result),
    write('Result after insertion: '),
    write(Result).

%Q17
delete_nth(1, [_|T], T).
delete_nth(N, [H|T], [H|R]) :-
    N > 1,
    N1 is N - 1,
    delete_nth(N1, T, R).
delete_nth_main :-
    write('Enter a list: '),
    read(L),
    write('Enter the position (N) to delete: '),
    read(N),
    delete_nth(N, L, R),
    write('Result after deletion: '),
    write(R).

%Q18
merge(_,_,_):-fail.
merge([], L2, L2):-!.
merge(L1, [], L1):-!.
merge([H1|T1], [H2|T2], [H1|R]) :-
    H1 =< H2,!,
    merge(T1, [H2|T2], R).

merge([H1|T1], [H2|T2], [H2|R]) :-
    H1 > H2,!,
    merge([H1|T1], T2, R).

merge_main :-
    write('Enter the first ordered list: '),
    read(L1),
    write('Enter the second ordered list: '),
    read(L2),
    merge(L1, L2, L3),
    write('Merged list: '),
    write(L3).
