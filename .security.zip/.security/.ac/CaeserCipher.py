def encrypt():
    str =   input("Enter the string you want to encrypt: ")
    key = int(input("Enter the key: "))  
    cipherText = ""

    for char in str:
        if char.isalpha():
            if char.isupper():
                cipherText += chr((ord(char) + key - ord('A')) %26 + ord('A'))
            else:
                cipherText += chr((ord(char) + key - ord('a')) %26 + ord('a'))
        else:
            cipherText += char
    print("The cipher text with key= ", key, " is : ", cipherText,"\n\n")

def decrypt():
    str =   input("Enter the encrypted string, you want to decrypt: ")
    key = int(input("Enter the key: "))  
    plainText = ""

    for char in str:
        if char.isalpha():
            if char.isupper():
                plainText += chr((ord(char) - key - ord('A')) %26 + ord('A'))
            else:
                plainText += chr((ord(char) - key - ord('a')) %26 + ord('a'))
        else:
            plainText += char
    print("The plain text with key= ", key, " is : ", plainText,"\n\n")


def main():

    
    while True:        
        
        print("************************")
        print("**********MENU**********")
        print("**1. Encrypt Message****")
        print("**2. Decrypt Message****")
        print("**3. Exit the Program***")
        print("************************")

        option = int(input("Enter the option, you want to perform: "))


        if option==1:
            encrypt()

        elif option==2:
            decrypt()

        elif option==3:
            break

        else:
            print("Invalid Choice! Please Enter a valid option.")

main()