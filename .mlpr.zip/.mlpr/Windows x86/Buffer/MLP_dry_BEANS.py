# -*- coding: utf-8 -*-
"""
Created on Fri Apr  5 11:03:55 2024

@author
"""



#https://www.geeksforgeeks.org/recognizing-handwritten-digits-in-scikit-learn/

# importing the hand written digit dataset
from sklearn import datasets
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import LabelEncoder
# define dataset

data=pd.read_csv("C:/Users/91931/Desktop/MLprograms/loistic_regression/Dry_Bean_Dataset.csv")
x=data.iloc[:,:-1]
y = data.iloc[:,16]
# Initialize LabelEncoder
label_encoder = LabelEncoder()

# Fit and transform the data
y = label_encoder.fit_transform(y)

# Print the encoded data
print(y)

Scaler=StandardScaler()
X=Scaler.fit_transform(x)


# importing the matplotlib libraries pyplot function
import matplotlib.pyplot as plt
# defining the function plot_multi


# converting the 2 dimensional array to one dimensional array


# gives the shape of the data
X.shape

# from sklearn.preprocessing import StandardScaler
# scaler = StandardScaler()
# x=scaler.fit_transform(x)
# printing the one-dimensional array's values


# Very first 1000 photographs and
# labels will be used in training.
x_train = X[:1000]
y_train = y[:1000]

# The leftover dataset will be utilised to
# test the network's performance later on.
x_test = X[1000:]
y_test = y[1000:]

# importing the MLP classifier from sklearn
from sklearn.neural_network import MLPClassifier

# calling the MLP classifier with specific parameters
# mlp = MLPClassifier(hidden_layer_sizes=(15,10),
# 					activation='logistic',
# 					alpha=1e-4, solver='sgd',
#                     max_iter=500,
# 					tol=1e-4, 
# 					learning_rate_init=.005)
mlp = MLPClassifier(hidden_layer_sizes=(15,),
 					activation='relu',
 					alpha=1e-4, solver='adam',
 					tol=1e-4, random_state=1,
 					learning_rate_init=.01,
                    max_iter=1000,
 					verbose=True)
mlp.fit(x_train, y_train)


fig, axes = plt.subplots(1, 1)
axes.plot(mlp.loss_curve_, 'o-')
axes.set_xlabel("number of iteration")
axes.set_ylabel("loss")
plt.show()

predictions_train = mlp.predict(x_train)
predictions = mlp.predict(x_test)
#predictions[:50]

#y_test[:50]

# importing the accuracy_score from the sklearn
from sklearn.metrics import accuracy_score
from sklearn import metrics
# calculating the accuracy with y_test and predictions
print(accuracy_score(y_train, predictions_train))
print(accuracy_score(y_test, predictions))
# print(metrics.confusion_matrix(y_test, predictions))

