# -*- coding: utf-8 -*-
"""
Created on Fri Feb 16 11:20:32 2024

@author: HP
"""


import numpy as np
from numpy import array
from numpy import mean
from numpy import cov
from numpy.linalg import eig


print()
print("***********FOR ASYMMETRIC MATRIX*************")
values1 =[]
products1 = []
for i in range(5):
    
    arr = array(np.random.randint(0, 50, size=(3,3)))
    print(arr)
    eigValues, eigVectors = eig(arr)

    values1.append(eigValues)
    #Checking the Eiger Vectors are orthonormal or not.

    eigVectors[:,1]

    length = len(eigVectors[0])
    length
    products = []
    for i in range(length):
        if i == length-1:
            products.append(eigVectors[:, length-1].dot(eigVectors[:,0]))
            break
        products.append(eigVectors[:, i].dot(eigVectors[:, i+1]))
    products1.append(products)
    print("**********************************************")


print("***********FOR SYMMETRIC MATRIX*************")

values2 =[]
products2 = []
for i in range(5):

    arr = array(np.random.randint(0, 50, size=(3,3)))
    arr_sym = arr + arr.T
    print(arr_sym)
    eigValues, eigVectors = eig(arr_sym)


    values2.append(eigValues)

    #Checking the Eiger Vectors are orthonormal or not.

    eigVectors[:,1]

    length = len(eigVectors[0])
    length
    products = []
    for i in range(length):
        if i == length-1:
            products.append(eigVectors[:, length-1].dot(eigVectors[:,0]))
            break
        products.append(eigVectors[:, i].dot(eigVectors[:, i+1]))
    products2.append(products)
    print("**********************************************")
    

print("***********FOR COVARIANCE MATRIX*************")

values3 =[]
products3 = []
for i in range(5):

    arr = array(np.random.randint(0, 50, size=(3,3)))
    arr_cov = cov(arr)
    print(arr_cov)
    eigValues, eigVectors = eig(arr_sym)

    
    values3.append(eigValues)

    #Checking the Eiger Vectors are orthonormal or not.

    eigVectors[:,1]

    length = len(eigVectors[0])
    length
    products = []
    for i in range(length):
        if i == length-1:
            products.append(eigVectors[:, length-1].dot(eigVectors[:,0]))
            break
        products.append(eigVectors[:, i].dot(eigVectors[:, i+1])) 
    products3.append(products)
    print("**********************************************")
    
    
