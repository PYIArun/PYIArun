parent(pam,bob).
parent(tom,bob).
parent(tom,liz).
parent(bob,ann).
parent(bob,pat).
parent(pat,jim).
female(pam).

grandparent(X,Z):-
    parent(X,Y),
    parent(Y,Z).

predecessor(X,Y):-
    parent(X,Y).

predecessor(X,Z):-
    parent(X,Y),
    predecessor(Y,Z).



