# -*- coding: utf-8 -*-
"""
Created on Tue Apr  9 22:06:06 2024

@author: kripl
"""

import numpy as np
import matplotlib.pyplot as plt

# generate random data-set
np.random.seed(0)
input1=np.array([[0,1],[1,1]]).T;

weights = np.random.rand( 2)
label=np.array([1,0])
predicted=np.array([0,0]);
eeta=0.1




def perceptron_train(count):
    
    for i in range(count):    
        weightedsumarr=weights.dot(input1).T
        
        
        for i in range(2):
            if weightedsumarr[i] >=0:
                predicted[i]=1
            else:
                predicted[i]=0
                
                
        
        
        for i in range(2):
            if label[i] != predicted[i]:
                x=input1[:,i]
                delw0=eeta*(label[i]-predicted[i])*x[0]
                delw1=eeta*(label[i]-predicted[i])*x[1]
                weights[0]=weights[0]+delw0;
                weights[1]=weights[1]+delw1;
               
                
        print(predicted)
        print(label)        
        print(np.mean(predicted==label)*100)        

perceptron_train(10)

